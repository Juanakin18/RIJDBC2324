package uo.ri.cws.application.service.util;

import java.time.LocalDate;
import java.util.List;

import uo.ri.cws.application.business.certificate.CertificateService.CertificateBLDto;
import uo.ri.cws.application.business.mechanic.MechanicService.MechanicBLDto;
import uo.ri.cws.application.business.vehicletype.VehicleTypeService.VehicleTypeBLDto;
import uo.ri.cws.application.persistence.certificate.CertificateGateway.CertificateDALDto;
import uo.ri.cws.application.service.util.sql.AddCertificateSqlUnitOfWork;

public class CertificateUtil {

    private CertificateDALDto dto = new CertificateDALDto();

    public CertificateUtil withId(String arg) {
	dto.id = arg;
	return this;
    }

    public CertificateUtil withDate(LocalDate date) {
	dto.date = date;
	return this;
    }

    public CertificateUtil withMechanicId(String arg) {
	dto.mechanicId = arg;
	return this;
    }

    public CertificateUtil withvehicletype(String arg) {
	dto.vehicleTypeId = arg;
	return this;

    }

    public CertificateUtil register() {
	new AddCertificateSqlUnitOfWork(dto).execute();
	return this;
    }

    public CertificateDALDto get() {

	return this.dto;
    }

    public static boolean matchCertificates(List<CertificateBLDto> generated,
	    List<CertificateBLDto> expected) {
	if (generated.size() != expected.size())
	    return false;
	CertificateBLDto e = null;
	for (CertificateBLDto g : generated) {
	    e = findCertificate(g.mechanic.id, g.vehicleType.id, g.obtainedAt,
		    expected);
	    if (e == null)
		return false;
	}
	return true;
    }

    private static CertificateBLDto findCertificate(String mid, String vtid,
	    LocalDate date, List<CertificateBLDto> expected) {
	for (CertificateBLDto c : expected) {
	    if (c.mechanic.id.equals(mid) && c.vehicleType.id.equals(vtid)
		    && c.obtainedAt.equals(date))
		return c;
	}
	return null;
    }

    public static boolean matchSortedCertificates(
	    List<CertificateBLDto> expected, List<CertificateBLDto> generated) {
	if (generated.size() != expected.size())
	    return false;
	CertificateBLDto e = null, g = null;
	for (int i = 0; i < expected.size(); i++) {
	    e = expected.get(i);
	    g = generated.get(i);
	    if (!match(e, g))
		return false;
	}
	return true;

    }

    private static boolean match(CertificateBLDto e, CertificateBLDto g) {
	return (e.id.equals(g.id) && e.obtainedAt.equals(g.obtainedAt)
		&& match(e.mechanic, g.mechanic)
		&& match(e.vehicleType, g.vehicleType));
    }

    private static boolean match(VehicleTypeBLDto vt1, VehicleTypeBLDto vt2) {

	return (vt1.id.equals(vt2.id) && vt1.name.equals(vt2.name)
		&& vt1.minTrainigHours == vt2.minTrainigHours
		&& Math.abs(vt1.pricePerHour - vt2.pricePerHour) < 0.1);
    }

    private static boolean match(MechanicBLDto m1, MechanicBLDto m2) {
	return (m1.id.equals(m2.id) && m1.dni.equals(m2.dni)
		&& m1.name.equals(m2.name) && m1.surname.equals(m2.surname));
    }
}

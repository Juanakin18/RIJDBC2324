package uo.ri.cws.application.service.reports;

import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.BusinessFactory;
import uo.ri.cws.application.business.course.CourseService;
import uo.ri.cws.application.business.course.CourseService.TrainingForMechanicRow;
import uo.ri.cws.application.business.mechanic.MechanicService.MechanicBLDto;
import uo.ri.cws.application.service.common.TestContext;
import uo.ri.cws.application.service.common.TestContext.Key;
import uo.ri.cws.application.service.util.TrainingUtil;

public class TrainingHoursSteps {

    private CourseService service = BusinessFactory.forCourseService();
    private TestContext ctx;
    private String mechanicId = null;
    private List<TrainingForMechanicRow> trainingHoursForMechanicFound = null;

    public TrainingHoursSteps(TestContext ctx) {
	this.ctx = ctx;
    }

    @When("I try find training hours for null mechanic")
    public void iTryFindTrainingHoursForNullMechanic() {
	tryFindTrainingHoursAndKeepException();
    }

    @When("I find training hours for a non existent mechanic")
    public void iTryFindTrainingHoursForANonExistentMechanic()
	    throws BusinessException {
	mechanicId = "non-existent-mechanic-id";
	service.findTrainingHoursForMechanic(mechanicId);

    }

    @When("I try find training hours for mechanic {string}")
    public void iTryFindTrainingHoursForMechanic(String arg) {
	mechanicId = arg;
	tryFindTrainingHoursAndKeepException();
    }

    @When("Find training hours for the mechanic")
    public void findTrainingHoursForTheMechanic() throws BusinessException {
	MechanicBLDto mechanic = (MechanicBLDto) ctx.get(
		Key.REGISTEREDMECHANIC);
	trainingHoursForMechanicFound = service.findTrainingHoursForMechanic(
		mechanic.id);
    }

    @Then("The following TrainingForMechanicRow are returned")
    public void theFollowingTrainingForMechanicRowAreReturned(
	    DataTable dataTable) {
	List<Map<String, String>> table = dataTable.asMaps();
	TrainingForMechanicRow dto = null;
	List<TrainingForMechanicRow> dtos = new ArrayList<>();

	for (Map<String, String> row : table) {
	    dto = new TrainingForMechanicRow();
	    dto.vehicleTypeName = row.get("vehicletypename");
	    dto.enrolledHours = Integer.parseInt(row.get("enrolledhours"));
	    dto.attendedHours = Double.parseDouble(row.get("attendedhours"));
	    dtos.add(dto);
	}
	TrainingUtil.match(dtos, trainingHoursForMechanicFound);
    }

    private void tryFindTrainingHoursAndKeepException() {
	try {
	    service.findTrainingHoursForMechanic(mechanicId);
	    fail();
	} catch (BusinessException ex) {
	    ctx.setException(ex);
	} catch (IllegalArgumentException ex) {
	    ctx.setException(ex);
	}

    }
}

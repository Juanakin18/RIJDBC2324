package uo.ri.cws.application.service.workorder;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Optional;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.BusinessFactory;
import uo.ri.cws.application.business.workorder.WorkOrderService;
import uo.ri.cws.application.business.workorder.WorkOrderService.WorkOrderBLDto;
import uo.ri.cws.application.service.common.TestContext;
import uo.ri.cws.application.service.common.TestContext.Key;
import uo.ri.cws.application.service.util.WorkOrderUtil;

public class FindWorkorderByIdSteps {

    private TestContext ctx;
    private Optional<WorkOrderBLDto> workorder = null;
    private WorkOrderBLDto saved = null;
    private WorkOrderService service = BusinessFactory.forWorkOrderService();

    public FindWorkorderByIdSteps(TestContext ctx) {
	this.ctx = ctx;
    }

    @When("I try to find workorder by id with null argument")
    public void iTryToFindWorkorderByIdWithNullArgument() {
	tryFindByIdAndKeepException(null);
    }

    @When("I try to find workorder with {string}")
    public void iTryToFindWorkorderWith(String arg) {
	tryFindByIdAndKeepException(arg);
    }

    @When("I find a non existent workorder")
    public void iFindANonExistentWorkorder() throws BusinessException {
	workorder = service.findWorkOrderById("non existent");
	ctx.setUniqueResult(workorder);
    }

    @When("I find the workorder")
    public void iFindTheWorkorder() throws BusinessException {
	saved = (WorkOrderBLDto) ctx.get(Key.WORKORDER);
	workorder = service.findWorkOrderById(saved.id);
    }

    @Then("The workorder is found")
    public void theWorkorderIsFound() {
	assertTrue(workorder.isPresent());
	assertTrue(WorkOrderUtil.match(saved, workorder.get()));
    }

    private void tryFindByIdAndKeepException(String id) {
	try {
	    service.findWorkOrderById(id);
	    fail();
	} catch (BusinessException ex) {
	    ctx.setException(ex);
	} catch (IllegalArgumentException ex) {
	    ctx.setException(ex);
	}

    }

}

package uo.ri.cws.application.service.util.sql;

public class PersistenceXmlScanner {

    public static ConnectionData scan() {
	ConnectionData res = new ConnectionData();
	res.driver = "org.hsqldb.jdbcDriver";
	res.url = "jdbc:hsqldb:hsql://localhost";
	res.user = "sa";
	res.pass = "";
	return res;

    }

}

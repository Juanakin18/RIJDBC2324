package uo.ri.cws.application.service.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;

import org.apache.commons.lang3.RandomStringUtils;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.workorder.WorkOrderService.WorkOrderBLDto;
import uo.ri.cws.application.service.util.sql.AddWorkOrderSqlUnitOfWork;
import uo.ri.cws.application.service.util.sql.FindWorkOrderSqlUnitOfWork;

public class WorkOrderUtil {

    private WorkOrderBLDto dto = createDefaultWorkOrderDto();
    private List<WorkOrderBLDto> dtos = new ArrayList<>();

    public WorkOrderUtil register() {
	new AddWorkOrderSqlUnitOfWork(dto).execute();
	return this;
    }

    public WorkOrderBLDto get() {
	return dto;
    }

    public List<WorkOrderBLDto> gets() {
	return dtos;
    }

    public List<WorkOrderBLDto> getUnfinished() {
	return dtos.stream()
		   .filter(d -> d.status.equals("OPENED")
			   || d.status.equals("ASSIGNED"))
		   .collect(Collectors.toList());
    }

    private LocalDateTime randomDate() {

	String str = "2020-04-08 12:30";
	DateTimeFormatter formatter = DateTimeFormatter.ofPattern(
		"yyyy-MM-dd HH:mm");

	LocalDateTime dateBefore = LocalDateTime.parse(str, formatter);
	LocalDateTime dateAfter = LocalDateTime.now();
	long noOfDaysBetween = ChronoUnit.DAYS.between(dateBefore, dateAfter);
	LocalDateTime randomDate = dateBefore.plusDays(
		ThreadLocalRandom.current().nextLong(noOfDaysBetween + 1));
	return randomDate;
    }

    private WorkOrderBLDto createDefaultWorkOrderDto() {
	WorkOrderBLDto res = new WorkOrderBLDto();

	res.id = UUID.randomUUID().toString();
	res.version = 1L;
	res.date = randomDate();
	res.description = RandomStringUtils.randomAlphabetic(10);
	res.status = "OPENED";
	res.amount = 0.0;

	return res;
    }

    public WorkOrderUtil forMechanic(String mId) {
	dto.mechanicId = mId;
	return this;
    }

    public WorkOrderUtil withState(String status) {
	dto.status = status;
	return this;
    }

    public WorkOrderUtil withAmount(double amount) {
	dto.amount = amount;
	return this;
    }

    public WorkOrderUtil withDate(String date) {
	dto.date = LocalDateTime.parse(date,
		DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
	return this;
    }

    public WorkOrderUtil loadById(String id) throws BusinessException {
	FindWorkOrderSqlUnitOfWork find = new FindWorkOrderSqlUnitOfWork(id);
	find.execute();
	this.dto = find.get();
	return this;
    }

    public WorkOrderUtil withInvoice(String invoiceid) {
	dto.invoiceId = invoiceid;
	return this;
    }

    public WorkOrderUtil forVehicle(String vId) {
	dto.vehicleId = vId;
	return this;
    }

    public WorkOrderUtil withDate(LocalDateTime arg) {
	dto.date = arg;
	return this;
    }

    public static Boolean match(WorkOrderBLDto a, WorkOrderBLDto b) {
//		Timestamp at = a.date.
	Boolean reslt = (a.id.equals(b.id) && (a.amount.equals(b.amount))
		&& (a.status.equals(b.status))
		&& (a.date.withNano(0).isEqual(b.date.withNano(0)))
		&& (a.description.equals(b.description)));
	if (a.mechanicId != null)
	    reslt = reslt && b.mechanicId != null
		    && a.mechanicId.equals(b.mechanicId);
	if (b.vehicleId != null)
	    reslt = reslt && b.vehicleId != null
		    && a.vehicleId.equals(b.vehicleId);
	/*
	 * && (a.mechanicId.equals(b.mechanicId)) &&
	 * a.vehicleId.equals(b.vehicleId) );
	 */
	return reslt;
    }

    public void createUnfinishedWorkOrdersForVehicle(String id) {
	// Create OPEN

	dto = createOPEN();
	dto.vehicleId = id;
	dtos.add(dto);
	this.register();
	dto = createINVOICED();
	dto.vehicleId = id;
	dtos.add(dto);
	this.register();
	dto = createASSIGNED();
	dto.vehicleId = id;
	dtos.add(dto);
	this.register();

    }

    private WorkOrderBLDto createASSIGNED() {
	WorkOrderBLDto res = createDefaultWorkOrderDto();
	res.status = "ASSIGNED";
	return res;
    }

    private WorkOrderBLDto createINVOICED() {
	WorkOrderBLDto res = createDefaultWorkOrderDto();
	res.status = "INVOICED";
	return res;
    }

    private WorkOrderBLDto createOPEN() {
	WorkOrderBLDto res = createDefaultWorkOrderDto();
	res.status = "OPENED";
	return res;
    }

    private WorkOrderBLDto createFINISHED() {
	WorkOrderBLDto res = createDefaultWorkOrderDto();
	res.status = "FINISHED";
	return res;
    }

    public void createFinishedWorkOrderForVehicle(String id) {
	dto = createFINISHED();
	dto.vehicleId = id;
	this.register();
    }

    public static boolean match(List<WorkOrderBLDto> found,
	    List<WorkOrderBLDto> saved) {
	boolean result = true;

	for (WorkOrderBLDto wo : found) {
	    result = result && find(wo, saved);
	}
	return result;
    }

    private static boolean find(WorkOrderBLDto arg,
	    List<WorkOrderBLDto> saved) {
	for (WorkOrderBLDto wo : saved) {
	    if (wo.id.equals(arg.id))
		return true;
	}
	return false;
    }

}

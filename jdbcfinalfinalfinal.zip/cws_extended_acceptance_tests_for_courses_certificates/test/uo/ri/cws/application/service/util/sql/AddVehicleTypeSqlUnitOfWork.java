package uo.ri.cws.application.service.util.sql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import uo.ri.cws.application.persistence.vehicleType.VehicleTypeGateway.VehicleTypeDALDto;

public class AddVehicleTypeSqlUnitOfWork {

    private VehicleTypeDALDto dto;
    private ConnectionData connectionData;
    private PreparedStatement insertIntoVehicleType;

    public AddVehicleTypeSqlUnitOfWork(VehicleTypeDALDto dto) {
	this.connectionData = PersistenceXmlScanner.scan();
	this.dto = dto;
    }

    public void execute() {
	JdbcTransaction trx = new JdbcTransaction(connectionData);
	trx.execute((con) -> {
	    prepareStatements(con);
	    insertVehicleType();
	});
    }

    private static final String INSERT_INTO_TVEHICLETYPES = "INSERT INTO TVEHICLETYPES"
	    + " ( ID, MINTRAININGHOURS, NAME, PRICEPERHOUR, VERSION )"
	    + " VALUES ( ?, ?, ?, ?, ?)";

    private void insertVehicleType() throws SQLException {
	PreparedStatement st = insertIntoVehicleType;
	int i = 1;
	st.setString(i++, dto.id);
	st.setInt(i++, dto.minTrainigHours);
	st.setString(i++, dto.name);
	st.setDouble(i++, dto.pricePerHour);
	st.setLong(i++, dto.version);
	st.executeUpdate();

    }

    private void prepareStatements(Connection con) throws SQLException {
	insertIntoVehicleType = con.prepareStatement(INSERT_INTO_TVEHICLETYPES);
    }

}

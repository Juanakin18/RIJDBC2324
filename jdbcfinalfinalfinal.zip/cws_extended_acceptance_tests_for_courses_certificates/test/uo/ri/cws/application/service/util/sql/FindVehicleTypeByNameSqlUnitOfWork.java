package uo.ri.cws.application.service.util.sql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import uo.ri.cws.application.business.vehicletype.VehicleTypeService.VehicleTypeBLDto;

public class FindVehicleTypeByNameSqlUnitOfWork {

    private String name;
    private VehicleTypeBLDto result = new VehicleTypeBLDto();

    private ConnectionData connectionData;
    private PreparedStatement findVehicleType;

    public FindVehicleTypeByNameSqlUnitOfWork(String arg) {
	this.connectionData = PersistenceXmlScanner.scan();
	this.name = arg;
    }

    public void execute() {
	JdbcTransaction trx = new JdbcTransaction(connectionData);
	trx.execute((con) -> {
	    prepareStatements(con);
	    findVehicleType();
	});
    }

    public VehicleTypeBLDto get() {
	return result;
    }

    private static final String FIND_BY_NAME = "SELECT * FROM TVEHICLETYPES "
	    + " WHERE NAME = ?";

    private void findVehicleType() throws SQLException {
	PreparedStatement st = findVehicleType;

	int i = 1;
	st.setString(i++, name);

	ResultSet rs = st.executeQuery();

	if (rs.next()) {
	    result.id = rs.getString("id");
	    result.version = rs.getLong("version");
	    result.name = rs.getString("name");
	    result.minTrainigHours = rs.getInt("mintraininghours");
	    result.pricePerHour = Double.parseDouble(
		    rs.getString("priceperhour"));
	}
    }

    private void prepareStatements(Connection con) throws SQLException {
	findVehicleType = con.prepareStatement(FIND_BY_NAME);
    }

}

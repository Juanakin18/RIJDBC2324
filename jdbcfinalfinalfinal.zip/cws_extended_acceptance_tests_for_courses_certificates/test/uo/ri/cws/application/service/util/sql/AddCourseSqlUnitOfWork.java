package uo.ri.cws.application.service.util.sql;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import uo.ri.cws.application.business.course.CourseService.CourseBLDto;

public class AddCourseSqlUnitOfWork {

//	private CourseDALDto dto;
    private CourseBLDto dto;
    private ConnectionData connectionData;
    private PreparedStatement insertIntoCourse;

    public AddCourseSqlUnitOfWork(/* CourseDALDto */ CourseBLDto dto) {
	this.connectionData = PersistenceXmlScanner.scan();
	this.dto = dto;
    }

    public void execute() {
	JdbcTransaction trx = new JdbcTransaction(connectionData);
	trx.execute((con) -> {
	    prepareStatements(con);
	    insertCourse();
	});
    }

    private static final String INSERT_INTO_TCOURSES = "INSERT INTO TCOURSES"
	    + " ( ID, CODE, NAME, DESCRIPTION, STARTDATE, ENDDATE, HOURS, VERSION)"
	    + " VALUES ( ?, ?, ?, ?, ?, ?, ?, ?)";

    private void insertCourse() throws SQLException {
	PreparedStatement st = insertIntoCourse;
	int i = 1;
	st.setString(i++, dto.id);
	st.setString(i++, dto.code);
	st.setString(i++, dto.name);
	st.setString(i++, dto.description);
	st.setDate(i++, Date.valueOf(dto.startDate));
	st.setDate(i++, Date.valueOf(dto.endDate));
	st.setInt(i++, dto.hours);
	st.setLong(i++, dto.version);

	st.executeUpdate();
    }

    private void prepareStatements(Connection con) throws SQLException {
	insertIntoCourse = con.prepareStatement(INSERT_INTO_TCOURSES);
    }

}

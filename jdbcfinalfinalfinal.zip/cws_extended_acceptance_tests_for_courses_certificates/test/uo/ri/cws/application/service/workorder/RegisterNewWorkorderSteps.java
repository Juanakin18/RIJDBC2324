package uo.ri.cws.application.service.workorder;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.BusinessFactory;
import uo.ri.cws.application.business.vehicle.VehicleService.VehicleBLDto;
import uo.ri.cws.application.business.workorder.WorkOrderService;
import uo.ri.cws.application.business.workorder.WorkOrderService.WorkOrderBLDto;
import uo.ri.cws.application.service.common.TestContext;
import uo.ri.cws.application.service.common.TestContext.Key;
import uo.ri.cws.application.service.util.WorkOrderUtil;
import uo.ri.cws.application.service.util.sql.FindWorkOrderSqlUnitOfWork;

public class RegisterNewWorkorderSteps {

    private TestContext ctx;

    private WorkOrderService service = BusinessFactory.forWorkOrderService();
    private WorkOrderBLDto dto = new WorkOrderUtil().get();

    public RegisterNewWorkorderSteps(TestContext ctx) {
	this.ctx = ctx;
    }

    @When("I try to add a new workorder with null argument")
    public void iTryToAddANewWorkorderWithNullArgument() {
	this.tryRegisterAndKeepException(dto);
    }

    @When("I try to add a new workorder with null vehicle id")
    public void iTryToAddANewWorkorderWithNullVehicleId() {
	dto.vehicleId = null;
	this.tryRegisterAndKeepException(dto);
    }

    @When("I try to add a new workorder with null description")
    public void iTryToAddANewWorkorderWithNullDescription() {
	dto.description = null;
	this.tryRegisterAndKeepException(dto);
    }

    @When("I try to add a workorder for a non existent vehicle")
    public void iTryToAddAWorkorderForANonExistentVehicle() {
	dto.vehicleId = "non-existent-id";
	this.tryRegisterAndKeepException(dto);
    }

    @When("I try to add a new workorder with vehicle {string}")
    public void iTryToAddANewMechanicWithVehicle(String arg) {
	dto.vehicleId = arg;
	this.tryRegisterAndKeepException(dto);
    }

    @When("I try to add a new workorder with description {string}")
    public void iTryToAddANewMechanicWithDescription(String arg) {
	dto.description = arg;
	this.tryRegisterAndKeepException(dto);
    }

    @When("I add a workorder for the vehicle")
    public void iAddAWorkorderForTheVehicle() throws BusinessException {
	dto.vehicleId = ((VehicleBLDto) ctx.get(Key.VEHICLE)).id;
	dto = service.registerNew(dto);
    }

    @Then("The workorder is registered")
    public void theWorkorderIsRegistered() {
	FindWorkOrderSqlUnitOfWork unit = new FindWorkOrderSqlUnitOfWork(
		dto.id);
	unit.execute();

	WorkOrderBLDto wo = unit.get();
	assertTrue(WorkOrderUtil.match(wo, dto));
    }

    private void tryRegisterAndKeepException(WorkOrderBLDto dto) {
	try {
	    service.registerNew(dto);
	    fail();
	} catch (BusinessException ex) {
	    ctx.setException(ex);
	} catch (IllegalArgumentException ex) {
	    ctx.setException(ex);
	}

    }

}

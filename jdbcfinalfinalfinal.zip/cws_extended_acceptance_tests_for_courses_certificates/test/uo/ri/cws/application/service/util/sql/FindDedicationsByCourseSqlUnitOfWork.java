package uo.ri.cws.application.service.util.sql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import uo.ri.cws.application.persistence.dedication.DedicationGateway.DedicationDALDto;

public class FindDedicationsByCourseSqlUnitOfWork {

    private String courseId;

    private ConnectionData connectionData;
    private PreparedStatement findVehicle;

    private List<DedicationDALDto> result = new ArrayList<>();

    public FindDedicationsByCourseSqlUnitOfWork(String id) {
	this.connectionData = PersistenceXmlScanner.scan();
	this.courseId = id;
    }

    public void execute() {
	JdbcTransaction trx = new JdbcTransaction(connectionData);
	trx.execute((con) -> {
	    prepareStatements(con);
	    find();
	});
    }

    public List<DedicationDALDto> get() {
	return result;
    }

    private static final String FIND_BY_ID = "SELECT * FROM TDEDICATIONS "
	    + " WHERE COURSE_ID = ?";

    private void find() throws SQLException {
	PreparedStatement st = findVehicle;

	int i = 1;
	st.setString(i++, courseId);

	ResultSet rs = st.executeQuery();

	while (rs.next()) {
	    DedicationDALDto res = new DedicationDALDto();
	    res.id = rs.getString("id");
	    res.courseId = rs.getString("course_id");
	    res.vehicleTypeId = rs.getString("vehicletype_id");
	    res.percentage = rs.getInt("percentage");
	    res.version = rs.getLong("version");
	    this.result.add(res);
	}
    }

    private void prepareStatements(Connection con) throws SQLException {
	findVehicle = con.prepareStatement(FIND_BY_ID);
    }

}

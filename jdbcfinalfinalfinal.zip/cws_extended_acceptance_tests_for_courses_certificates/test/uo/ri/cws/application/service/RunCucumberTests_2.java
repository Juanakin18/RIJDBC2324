package uo.ri.cws.application.service;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.junit.CucumberOptions.SnippetType;
import uo.ri.conf.BusinessFactoryAdapter;
import uo.ri.conf.Factory;

@RunWith(Cucumber.class)
@CucumberOptions(features = {

	"test/uo/ri/cws/application/service/mechanic",
	"test/uo/ri/cws/application/service/invoice",
	"test/uo/ri/cws/application/service/certificate/Generate.feature",
	"test/uo/ri/cws/application/service/reports/AllTrainingHours.feature",
	"test/uo/ri/cws/application/service/workorder/RegisterNew.feature",
	"test/uo/ri/cws/application/service/workorder/Update.feature",
	"test/uo/ri/cws/application/service/workorder/Delete.feature",
	"test/uo/ri/cws/application/service/workorder/AssignWorkorder2Mechanic.feature", }, plugin = {
		"pretty",
		"html:target/cucumber-results.html" }, snippets = SnippetType.CAMELCASE)
public class RunCucumberTests_2 {

    static {
	Factory.service = new BusinessFactoryAdapter();
    }

}

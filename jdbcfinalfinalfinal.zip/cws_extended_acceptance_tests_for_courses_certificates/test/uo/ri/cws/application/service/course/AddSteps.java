package uo.ri.cws.application.service.course;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.BusinessFactory;
import uo.ri.cws.application.business.course.CourseService;
import uo.ri.cws.application.business.course.CourseService.CourseBLDto;
import uo.ri.cws.application.persistence.dedication.DedicationGateway.DedicationDALDto;
import uo.ri.cws.application.persistence.vehicleType.VehicleTypeGateway.VehicleTypeDALDto;
import uo.ri.cws.application.service.common.TestContext;
import uo.ri.cws.application.service.common.TestContext.Key;
import uo.ri.cws.application.service.util.CourseUtil;
import uo.ri.cws.application.service.util.DedicationUtil;

public class AddSteps {

    private CourseService service = BusinessFactory.forCourseService();
    private TestContext ctx;

    private CourseBLDto registeredCourse;
    private CourseBLDto nonExistentCourse;

    public AddSteps(TestContext ctx) {
	this.ctx = ctx;
    }

    @Given("a non existent course")
    public void aCourseRandomlyGenerated() {
	// Create three random vehicle types
	List<VehicleTypeDALDto> vts = (List<VehicleTypeDALDto>) ctx.get(
		Key.VEHICLETYPES);
	nonExistentCourse = new CourseUtil().get();
	nonExistentCourse.percentages = new DedicationUtil().generatePercentages(
		vts).getMap();
    }

    @Given("an unfinished course")
    public void anUnfinishedCourse() {

	List<VehicleTypeDALDto> vts = (List<VehicleTypeDALDto>) ctx.get(
		Key.VEHICLETYPES);

	Map<String, Integer> percentages = new DedicationUtil().generatePercentages(
		vts).getMap();
	CourseBLDto m = new CourseUtil().withStartDate(
		LocalDate.now().minusMonths(1))
					.withEndDate(
						LocalDate.now().plusMonths(1))
					.withPercentages(percentages)
					.register()
					.get();
	ctx.put(Key.REGISTEREDCOURSE, m);

    }

    @Given("a finished registered course")
    public void aFinishedRegisteredCourse() {
	List<VehicleTypeDALDto> vts = (List<VehicleTypeDALDto>) ctx.get(
		Key.VEHICLETYPES);

	Map<String, Integer> percentages = new DedicationUtil().generatePercentages(
		vts).getMap();
	CourseBLDto m = new CourseUtil().withStartDate(
		LocalDate.now().minusMonths(10))
					.withEndDate(
						LocalDate.now().minusMonths(3))
					.withPercentages(percentages)
					.register()
					.get();
	ctx.put(Key.REGISTEREDCOURSE, m);
    }

    @Given("a future course")
    public void aFutureCourse() {
	List<VehicleTypeDALDto> vts = (List<VehicleTypeDALDto>) ctx.get(
		Key.VEHICLETYPES);

	Map<String, Integer> percentages = new DedicationUtil().generatePercentages(
		vts).getMap();
	CourseBLDto m = new CourseUtil().withStartDate(
		LocalDate.now().plusMonths(1))
					.withEndDate(
						LocalDate.now().plusMonths(3))
					.withPercentages(percentages)
					.register()
					.get();
	ctx.put(Key.REGISTEREDCOURSE, m);
    }

    @Given("the following registered courses")
    public void theFollowingRegisteredCourses(DataTable dataTable) {
	List<VehicleTypeDALDto> vts = (List<VehicleTypeDALDto>) ctx.get(
		Key.VEHICLETYPES);
	List<CourseBLDto> courses = new ArrayList<>();

	List<Map<String, String>> table = dataTable.asMaps();
	for (Map<String, String> row : table) {
	    courses.add(processRow(row));
	}

	ctx.put(Key.REGISTEREDCOURSES, courses); // for find

    }

    private CourseBLDto processRow(Map<String, String> row) {
	String state = row.get("state");
	LocalDate sd = null, ed = null;
	switch (state) {
	case "future":
	    sd = LocalDate.now().plusMonths(1);
	    ed = sd.plusMonths(3);
	    break;
	case "finished":
	    sd = LocalDate.now().minusMonths(10);
	    ed = sd.plusMonths(3);
	    break;
	case "active":
	    sd = LocalDate.now().minusMonths(1);
	    ed = sd.plusMonths(3);
	}
	String start = row.get("startDate");
	CourseBLDto m = new CourseUtil().withId(row.get("id"))
					.withCode(row.get("code"))
					.withName(row.get("name"))
					.withDescription(row.get("description"))
					.withHours(Integer.parseInt(
						row.get("hours")))
					.withStartDate(sd)
					.withEndDate(ed)
					.register()
					.get();
	return m;
    }

    private int suma(Map<String, Integer> percentages) {
	int total = 0;
	for (Map.Entry<String, Integer> entry : percentages.entrySet()) {
	    total += entry.getValue();
	}
	return total;
    }

    @Given("a registered course")
    public void aCourse() {
	List<VehicleTypeDALDto> vts = (List<VehicleTypeDALDto>) ctx.get(
		Key.VEHICLETYPES);

	registeredCourse = new CourseUtil().register().get();
	registeredCourse.percentages = new DedicationUtil().forCourse(
		registeredCourse.id)
							   .generatePercentages(
								   vts)
							   .registerRandomPercentages()
							   .getMap();
	ctx.put(Key.REGISTEREDCOURSE, registeredCourse); // for deleting and
							 // updating
    }

    @Given("two registered courses")
    public void twoRegisteredCourses() {
	List<VehicleTypeDALDto> vts = (List<VehicleTypeDALDto>) ctx.get(
		Key.VEHICLETYPES);

	registeredCourse = new CourseUtil().register().get();

	registeredCourse.percentages = new DedicationUtil().forCourse(
		registeredCourse.id)
							   .generatePercentages(
								   vts)
							   .registerRandomPercentages()
							   .getMap();

	ctx.put(Key.REGISTEREDCOURSE, registeredCourse); // for deleting and
							 // updating
	registeredCourse = new CourseUtil().register().get();
//		registeredCourse.percentages = new DedicationUtil().forCourse(registeredCourse.id).generatePercentages(vts)
//				.register().getMap();
	registeredCourse.percentages = new DedicationUtil().forCourse(
		registeredCourse.id)
							   .generatePercentages(
								   vts)
							   .registerRandomPercentages()
							   .getMap();
	ctx.put(Key.SECONDREGISTEREDCOURSE, registeredCourse); // for updating
    }

    @When("I add the course")
    public void iAddTheCourse() throws BusinessException {
	registeredCourse = service.registerNew(nonExistentCourse);
	ctx.put(Key.REGISTEREDCOURSE, registeredCourse); // for deleting and
							 // updating
    }

    @When("I try to add a new course with null argument")
    public void iTryToAddANewCourseWithNullArgument() {
	this.nonExistentCourse = null;
	tryAddAndKeepException();
    }

    @When("I try to add a new course with null code")
    public void iTryToAddANewCourseWithNullCode() {
	nonExistentCourse.code = null;
	tryAddAndKeepException();

    }

    @When("I try to add a new course with null name")
    public void iTryToAddANewCourseWithNullName() {
	nonExistentCourse.name = null;
	tryAddAndKeepException();
    }

    @When("I try to add a new course with null description")
    public void iTryToAddANewCourseWithNullDescription() {
	nonExistentCourse.description = null;
	tryAddAndKeepException();

    }

    @When("I try to add a new course with null startDate")
    public void iTryToAddANewCourseWithNullStartDate() {
	nonExistentCourse.startDate = null;
	tryAddAndKeepException();

    }

    @When("I try to add a new course with null endDate")
    public void iTryToAddANewCourseWithNullEndDate() {
	nonExistentCourse.endDate = null;
	tryAddAndKeepException();

    }

    @When("I try to add a new course with null percentages")
    public void iTryToAddANewCourseWithNullPercentages() {
	nonExistentCourse.percentages = null;
	tryAddAndKeepException();

    }

    @When("I try to add a new course with {string}, {string}, {string}")
    public void iTryToAddANewCourseWith(String code, String name,
	    String description) {
	nonExistentCourse.code = code;
	nonExistentCourse.name = name;
	nonExistentCourse.description = description;
	tryAddAndKeepException();

    }

    @When("I try to add a course with number of hours equals zero")
    public void iTryToAddACourseWithNumberOfHoursEqualsZero() {
	nonExistentCourse.hours = 0;
	tryAddAndKeepException();
    }

    @When("I try to add a course with number of hours less than zero")
    public void iTryToAddACourseWithNumberOfHoursLessThanZero() {
	nonExistentCourse.hours = -10;
	tryAddAndKeepException();
    }

    @When("I try to add a new course with same name")
    public void iTryToAddANewCourseWithSameName() {
	nonExistentCourse.name = registeredCourse.name;
	tryAddAndKeepException();
    }

    private void tryAddAndKeepException() {
	try {
	    service.registerNew(nonExistentCourse);
	    fail();
	} catch (BusinessException ex) {
	    ctx.setException(ex);
	} catch (IllegalArgumentException ex) {
	    ctx.setException(ex);
	}

    }

    @When("I try to add a course detailing percentages that add up less than one hundred")
    public void iTryToAddACourseDetailingPercentagesThatAddUpLessThanOneHundred() {
	Map<String, Integer> percents = nonExistentCourse.percentages;
	Map.Entry<String, Integer> actualValue = percents.entrySet()
							 .stream()
							 .findFirst()
							 .get();
	percents.remove(actualValue.getKey());
	percents.put(actualValue.getKey(), actualValue.getValue() - 1);

	nonExistentCourse.percentages = percents;
	tryAddAndKeepException();
    }

    @When("I try to add a course detailing percentages that add up more than one hundred")
    public void iTryToAddACourseDetailingPercentagesThatAddUpMoreThanOneHundred() {
	Map<String, Integer> percents = nonExistentCourse.percentages;
	Map.Entry<String, Integer> actualValue = percents.entrySet()
							 .stream()
							 .findFirst()
							 .get();
	percents.remove(actualValue.getKey());
	percents.put(actualValue.getKey(), actualValue.getValue() + 1);

	nonExistentCourse.percentages = percents;
	tryAddAndKeepException();
    }

    @When("I try to add a new course with same code")
    public void iTryToAddANewCourseWithSameCode() {
	nonExistentCourse.code = registeredCourse.code;
	tryAddAndKeepException();
    }

    @When("I try to add a course involving a non existing vehicle type")
    public void iTryToAddACourseInvolvingANonExistingVehicleType() {
	Map<String, Integer> percents = nonExistentCourse.percentages;
	Map.Entry<String, Integer> actualValue = percents.entrySet()
							 .stream()
							 .findFirst()
							 .get();
	percents.remove(actualValue.getKey());
	percents.put("non-existent-vehicle-type", actualValue.getValue());

	nonExistentCourse.percentages = percents;
	tryAddAndKeepException();

    }

    @When("I try to add a course with a past start date")
    public void iTryToAddACourseWithAPastStartDate() {
	nonExistentCourse.startDate = LocalDate.now().minusMonths(1);

	tryAddAndKeepException();
    }

    @When("I try to add a course with a past end date")
    public void iTryToAddACourseWithAPastEndDate() {
	nonExistentCourse.endDate = LocalDate.now().minusMonths(1);
	tryAddAndKeepException();

    }

    @When("I try to add a course with a start date later than end date")
    public void iTryToAddACourseWithAStartDateLaterThanEndDate() {
	nonExistentCourse.endDate = nonExistentCourse.startDate.minusMonths(1);
	tryAddAndKeepException();
    }

    @Then("the course is in the system")
    public void theCourseResultsAddedToTheSystem() {
	/* course is created or updated */
	CourseBLDto existent = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);
	CourseBLDto found = new CourseUtil().find(existent.id).get();
	List<DedicationDALDto> dedicationsFound = new DedicationUtil().findByCourse(
		existent.id).get();

	assertTrue(found != null);
	assertTrue(dedicationsFound != null);
	CourseUtil.matchCourse(existent, found);
	CourseUtil.matchDedications(existent.percentages, dedicationsFound);

    }

}

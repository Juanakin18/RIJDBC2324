package uo.ri.cws.application.service.util.sql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;
import java.util.UUID;

import uo.ri.cws.application.persistence.dedication.DedicationGateway.DedicationDALDto;

public class AddDedicationSqlUnitOfWork {

    private Map<String, Integer> percents;
    private DedicationDALDto dto = null;
    private ConnectionData connectionData;
    private PreparedStatement insertDedications;

    public AddDedicationSqlUnitOfWork(DedicationDALDto dto,
	    Map<String, Integer> percentages) {
	this.connectionData = PersistenceXmlScanner.scan();
	this.percents = percentages;
	this.dto = dto;
    }

    public AddDedicationSqlUnitOfWork(DedicationDALDto dto) {
	this.connectionData = PersistenceXmlScanner.scan();
	this.dto = dto;
    }

    public void execute() {
	JdbcTransaction trx = new JdbcTransaction(connectionData);
	trx.execute((con) -> {
	    prepareStatements(con);
	    insertDedication();
	});
    }

    private static final String INSERT_INTO_TDEDICATIONS = "INSERT INTO TDEDICATIONS"
	    + " ( ID, VERSION, PERCENTAGE, COURSE_ID, VEHICLETYPE_ID )"
	    + " VALUES ( ?, ?, ?, ?, ? )";

    private void insertDedication() throws SQLException {
	PreparedStatement st = insertDedications;
	int i = 1;
	st.setString(i++, UUID.randomUUID().toString());
	st.setLong(i++, 1L);
	st.setInt(i++, dto.percentage);
	st.setString(i++, dto.courseId);
	st.setString(i++, dto.vehicleTypeId);

	st.executeUpdate();

    }

    private void prepareStatements(Connection con) throws SQLException {
	insertDedications = con.prepareStatement(INSERT_INTO_TDEDICATIONS);

    }

}

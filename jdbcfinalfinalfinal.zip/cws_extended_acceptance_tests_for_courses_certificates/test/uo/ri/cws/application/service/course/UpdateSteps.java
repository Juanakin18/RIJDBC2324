package uo.ri.cws.application.service.course;

import static org.junit.Assert.fail;

import java.time.LocalDate;
import java.util.Map;
import java.util.Map.Entry;

import io.cucumber.java.en.When;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.BusinessFactory;
import uo.ri.cws.application.business.course.CourseService;
import uo.ri.cws.application.business.course.CourseService.CourseBLDto;
import uo.ri.cws.application.service.common.TestContext;
import uo.ri.cws.application.service.common.TestContext.Key;

public class UpdateSteps {

    private CourseService service = BusinessFactory.forCourseService();
    private TestContext ctx;

    private CourseBLDto course;

    public UpdateSteps(TestContext ctx) {
	this.ctx = ctx;

    }

    @When("I update the course")
    public void iUpdateTheCourse() throws BusinessException {
	course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);
	course.code = "updated-code";
	course.name = "updated-name";
	course.description = "updated-description";
	course.startDate = course.startDate.plusMonths(1);
	course.endDate = course.endDate.plusMonths(1);
	course.hours += 10;
	Map<String, Integer> percents = course.percentages;
	swapDedications(percents);
	course.percentages = percents;

	service.updateCourse(course);
	ctx.put(Key.REGISTEREDCOURSE, course);
    }

    private void swapDedications(Map<String, Integer> percents) {
	Map.Entry<String, Integer> value1 = percents.entrySet()
						    .stream()
						    .findFirst()
						    .get();
	percents.remove(value1.getKey());
	int temp = value1.getValue();
	Map.Entry<String, Integer> value2 = percents.entrySet()
						    .stream()
						    .findFirst()
						    .get();
	percents.remove(value2.getKey());
	value1.setValue(value2.getValue());
	value2.setValue(temp);
	percents.put(value1.getKey(), value1.getValue());
	percents.put(value2.getKey(), value2.getValue());
    }

    @When("I try to update a course with an invalid version")
    public void iTryToUpdateACourseWithAnInvalidVersion() {
	course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);
	course.version += 3;
	tryUpdateAndKeepException();
    }

    @When("I try to update a course with null argument")
    public void iTryToUpdateACourseWithNullArgument() {
	course = null;
	tryUpdateAndKeepException();

    }

    @When("I try to update a course with null code")
    public void iTryToUpdateACourseWithNullCode() {
	course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);
	course.code = null;
	tryUpdateAndKeepException();

    }

    @When("I try to update a course with null name")
    public void iTryToUpdateACourseWithNullName() {
	course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);
	course.name = null;
	tryUpdateAndKeepException();
    }

    @When("I try to update a course with null description")
    public void iTryToUpdateACourseWithNullDescription() {
	course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);
	course.description = null;
	tryUpdateAndKeepException();
    }

    @When("I try to update a course with null startDate")
    public void iTryToUpdateACourseWithNullStartDate() {
	course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);
	course.startDate = null;
	tryUpdateAndKeepException();
    }

    @When("I try to update a course with null endDate")
    public void iTryToUpdateACourseWithNullEndDate() {
	course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);
	course.endDate = null;
	tryUpdateAndKeepException();
    }

    @When("I try to update a course with null percentages")
    public void iTryToUpdateACourseWithNullPercentages() {
	course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);
	course.percentages = null;
	tryUpdateAndKeepException();
    }

    @When("I try to update a course with {string}, {string}, {string}")
    public void iTryToAddANewCourseWith(String code, String name,
	    String description) {
	course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);
	course.code = code;
	course.name = name;
	course.description = description;
	tryUpdateAndKeepException();

    }

    @When("I try to update a non existent course")
    public void iTryToUpdateANonExistentCourse() {
	course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);
	course.id = "non-existent-id";
	tryUpdateAndKeepException();
    }

    @When("I try to update a course with repeated name")
    public void iTryToUpdateACourseWithRepeatedName() {
	course = (CourseBLDto) ctx.get(Key.SECONDREGISTEREDCOURSE);
	String updateName = course.name;
	course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);
	course.name = updateName;
	tryUpdateAndKeepException();
    }

    @When("I try to update a course with same code")
    public void iTryToUpdateACourseWithSameCode() {
	course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);
	String updateCode = course.code;
	course = (CourseBLDto) ctx.get(Key.SECONDREGISTEREDCOURSE);
	course.code = updateCode;
	tryUpdateAndKeepException();
    }

    @When("I try to update a course involving a non existing vehicle type")
    public void iTryToUpdateACourseInvolvingANonExistingVehicleType() {
	course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);

	Map<String, Integer> percents = course.percentages;
	Entry<String, Integer> entry = percents.entrySet()
					       .stream()
					       .findFirst()
					       .get();
	percents.remove(entry.getKey());
	percents.put("non-existent-vehicle-type", entry.getValue());
	course.percentages = percents;
	tryUpdateAndKeepException();

    }

    @When("I try to update a course detailing percentages that sum up more than one hundred")
    public void iTryToUpdateACourseDetailingPercentagesThatUpdateUpMoreThanOneHundred() {
	course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);

	Map<String, Integer> percents = course.percentages;
	Entry<String, Integer> entry = percents.entrySet()
					       .stream()
					       .findFirst()
					       .get();
	percents.remove(entry.getKey());
	percents.put(entry.getKey(), 100);
	course.percentages = percents;
	tryUpdateAndKeepException();
    }

    @When("I try to update a course detailing percentages that update up less than one hundred")
    public void iTryToUpdateACourseDetailingPercentagesThatUpdateUpLessThanOneHundred() {
	course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);

	Map<String, Integer> percents = course.percentages;
	Entry<String, Integer> entry = percents.entrySet()
					       .stream()
					       .findFirst()
					       .get();
	percents.remove(entry.getKey());
	percents.put(entry.getKey(), entry.getValue() - 1);
	course.percentages = percents;
	tryUpdateAndKeepException();
    }

    @When("I try to update a course with number of hours less than zero")
    public void iTryToUpdateACourseWithNumberOfHoursLessThanZero() {
	course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);
	course.hours = -1;
	tryUpdateAndKeepException();
    }

    @When("I try to update a course with number of hours equals zero")
    public void iTryToUpdateACourseWithNumberOfHoursEqualsZero() {
	course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);
	course.hours = 0;
	tryUpdateAndKeepException();
    }

    @When("I try to update a course with a start date later than end date")
    public void iTryToUpdateACourseWithAStartDateLaterThanEndDate() {
	course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);
	LocalDate temp = course.startDate;
	course.startDate = course.endDate;
	course.endDate = temp;
	tryUpdateAndKeepException();
    }

    @When("I try to update a course with a past end date")
    public void iTryToUpdateACourseWithAPastEndDate() {
	course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);
	course.endDate = LocalDate.now().minusMonths(1);
	tryUpdateAndKeepException();
    }

    @When("I try to update a course with a past start date")
    public void iTryToUpdateACourseWithAPastStartDate() {
	course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);
	course.startDate = LocalDate.now().minusMonths(1);
	tryUpdateAndKeepException();
    }

    private void tryUpdateAndKeepException() {
	try {
	    service.updateCourse(course);
	    fail();
	} catch (BusinessException ex) {
	    ctx.setException(ex);
	} catch (IllegalArgumentException ex) {
	    ctx.setException(ex);
	}

    }

}

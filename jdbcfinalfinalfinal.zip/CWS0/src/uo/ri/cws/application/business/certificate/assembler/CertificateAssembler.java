package uo.ri.cws.application.business.certificate.assembler;

import uo.ri.cws.application.business.certificate.CertificateService.CertificateBLDto;
import uo.ri.cws.application.persistence.certificate.CertificateGateway.CertificateDALDto;

public class CertificateAssembler {

	public static CertificateBLDto toBLDto(CertificateDALDto dto) {
		CertificateBLDto bldto = new CertificateBLDto();
		bldto.id = dto.id;
		bldto.obtainedAt = dto.date;
		bldto.version = dto.version;
		return bldto;
	}

}

package uo.ri.cws.application.business;

import uo.ri.cws.application.business.certificate.CertificateService;
import uo.ri.cws.application.business.certificate.crud.CertificateServiceImpl;
import uo.ri.cws.application.business.course.CourseService;
import uo.ri.cws.application.business.course.crud.CourseServiceImpl;
import uo.ri.cws.application.business.enrollment.EnrollmentService;
import uo.ri.cws.application.business.invoice.InvoiceService;
import uo.ri.cws.application.business.invoice.create.InvoiceServiceImpl;
/*import uo.ri.cws.application.business.client.ClientService;
import uo.ri.cws.application.business.invoice.InvoiceService;
import uo.ri.cws.application.business.invoice.create.InvoiceServiceImpl;*/
import uo.ri.cws.application.business.mechanic.MechanicService;
import uo.ri.cws.application.business.mechanic.crud.MechanicServiceImpl;
import uo.ri.cws.application.business.vehicle.VehicleService;
import uo.ri.cws.application.business.vehicletype.VehicleTypeService;
import uo.ri.cws.application.business.workorder.WorkOrderService;
import uo.ri.cws.application.business.workorder.crud.WorkOrderServiceImpl;

public class BusinessFactory {

	
	public static MechanicService forMechanicService() {
		return new MechanicServiceImpl();
	}

	
	public static InvoiceService forInvoicingService() {
		return new InvoiceServiceImpl();
	}

	public static VehicleTypeService forVehicleTypeService() {
		return null;
	}


	public static VehicleService forVehicleService() {
		return null;
	}


	public static CertificateService forCertificateService() {
		return new CertificateServiceImpl();
	}


	public static CourseService forCourseService() {
		return new CourseServiceImpl();
	}


	public static EnrollmentService forEnrollmentService() {
		return null;
	}


	public static WorkOrderService forWorkOrderService() {
		return new WorkOrderServiceImpl();
	}

	/*
	public static ClientService forClientService() {
		throw new RuntimeException("Not yet implemented");
	}*/

}

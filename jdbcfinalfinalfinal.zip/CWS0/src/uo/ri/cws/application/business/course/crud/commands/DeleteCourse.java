package uo.ri.cws.application.business.course.crud.commands;

import assertion.Argument;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.course.CourseGateway;
import uo.ri.cws.application.persistence.dedication.DedicationGateway;
import uo.ri.cws.application.persistence.dedication.DedicationGateway.DedicationDALDto;
import uo.ri.cws.application.persistence.enrollment.EnrollmentGateway;

public class DeleteCourse implements Command<Void> {

	 /**
     * A course can only be deleted if it still has no attendance registered.
     * Delete a course also implies remove all its dedications in cascade.
     *
     * Note: A course and its dedications form an aggregate.
     *
     * @param id
     * @throws 
     * 		IllegalArgumentException, if id is empty
     * 		BusinessException if: - there is no course with the specified id,
     *                           or - the course already has enrollments
     *                           registered.
     */
	private String id;
	private CourseGateway gtw = PersistenceFactory.forCourse();
	private DedicationGateway dgtw = PersistenceFactory.forDedication();
	private EnrollmentGateway egtw = PersistenceFactory.forEnrollment();
	public DeleteCourse(String id) {
		Argument.isNotNull(id);
		Argument.isNotEmpty(id);
		this.id = id;
	}

	@Override
	public Void execute() throws BusinessException {
		checkExists();
		checkNotEnrollments();
		delete();
		return null;
	}

	private void delete() {
		for(DedicationDALDto ded : dgtw.findByCourse(id)) {
			dgtw.remove(ded.id);
		}
		gtw.remove(id);
	}

	private void checkNotEnrollments() throws BusinessException {
		if(egtw.findByCourse(id).size()>0)
			throw new BusinessException("Tiene a gente asistiendo");
	}

	private void checkExists() throws BusinessException {
		if(gtw.findById(id).isEmpty())
			throw new BusinessException("No existe ese curso");
	}

}

package uo.ri.cws.application.business.vehicletype.assembler;

import java.util.Optional;

import uo.ri.cws.application.business.vehicletype.VehicleTypeService.VehicleTypeBLDto;
import uo.ri.cws.application.persistence.vehicleType.VehicleTypeGateway.VehicleTypeDALDto;

public class VehicleTypeAssembler {

	public static Optional<VehicleTypeBLDto> toBLDto(Optional<VehicleTypeDALDto> arg) {
		Optional<VehicleTypeBLDto> result = arg.isEmpty() ? Optional.ofNullable(null)
				: Optional.ofNullable(toVehicleTypeBLDDto(arg.get()));
		return result;
	}

	private static VehicleTypeBLDto toVehicleTypeBLDDto(VehicleTypeDALDto vehicleTypeDALDto) {
		VehicleTypeBLDto dto = new VehicleTypeBLDto();
		dto.id = vehicleTypeDALDto.id;
		dto.minTrainigHours = vehicleTypeDALDto.minTrainigHours;
		dto.name = vehicleTypeDALDto.name;
		dto.pricePerHour = vehicleTypeDALDto.pricePerHour;
		dto.version = vehicleTypeDALDto.version;
		return dto;
	}

}

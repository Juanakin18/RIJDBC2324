package uo.ri.cws.application.persistence.dedication;

import java.util.List;

import uo.ri.cws.application.persistence.Gateway;

public interface DedicationGateway extends Gateway<uo.ri.cws.application.persistence.dedication.DedicationGateway.DedicationDALDto> {

	public List<DedicationDALDto> findByCourse(String courseId);
	public class DedicationDALDto{
		public String id;
		public Long version;
		
		public int percentage;
		public String vehicleTypeId;
		public String courseId;
		
	}
	public List<DedicationDALDto> findByVehicleType(String type);
}

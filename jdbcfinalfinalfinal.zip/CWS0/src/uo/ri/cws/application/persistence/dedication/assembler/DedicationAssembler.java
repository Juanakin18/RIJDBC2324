package uo.ri.cws.application.persistence.dedication.assembler;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.persistence.dedication.DedicationGateway.DedicationDALDto;

public class DedicationAssembler {

	public static Optional<DedicationDALDto> toDALDto(ResultSet rs) throws SQLException {
		if (rs.next()) {
		    return Optional.of(resultSetToDALDto(rs));
		} else
		    return Optional.ofNullable(null);
	}

	private static DedicationDALDto resultSetToDALDto(ResultSet rs) throws SQLException {
		DedicationDALDto value = new DedicationDALDto();
		value.id = rs.getString("id");
		value.version = rs.getLong("version");

		value.courseId = rs.getString("course_id");
		value.vehicleTypeId = rs.getString("vehicletype_id");
		value.percentage = rs.getInt("percentage");
		return value;
	}

	public static List<DedicationDALDto> toDALDtoList(ResultSet rs) throws SQLException {
		List<DedicationDALDto> res = new ArrayList<>();
		while (rs.next()) {
		    res.add(resultSetToDALDto(rs));
		}

		return res;
	}

}

package uo.ri.cws.application.persistence.certificate.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import jdbc.Jdbc;
import uo.ri.cws.application.persistence.PersistenceException;
import uo.ri.cws.application.persistence.certificate.CertificateGateway;
import uo.ri.cws.application.persistence.certificate.assembler.CertificateAssembler;
import uo.ri.cws.application.persistence.util.Conf;

public class CertificateGatewayImpl implements CertificateGateway {

	@Override
	public void add(CertificateDALDto t) {
		Connection c = null;
		PreparedStatement pst = null;

		try {
			c = Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TCERTIFICATES_ADD"));
			pst.setString(1, t.id);
			pst.setString(4, t.mechanicId);
			pst.setDate(2, java.sql.Date.valueOf(t.date));
			pst.setString(5, t.vehicleTypeId);
			pst.setLong(3, 1L);

			pst.executeUpdate();

		} catch (SQLException e) {
			throw new PersistenceException(e);
		} finally {
			if (pst != null) try { pst.close(); } catch(SQLException e) { /* ignore */ }
		}

	}

	@Override
	public void remove(String id) {
		PreparedStatement pst = null;
		Connection c = Jdbc.getCurrentConnection();
		try {
			pst = c.prepareStatement(Conf.getInstance().getProperty("TCERTIFICATES_DELETE"));
			pst.setString(1, id);
			pst.executeUpdate();
		}catch(SQLException e) {
			throw new PersistenceException();
		}
	}

	@Override
	public void update(CertificateDALDto t) {
		Connection c = null;
		PreparedStatement pst = null;

		try {
			c = Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TCERTIFICATES_UPDATE"));
			pst.setString(1, t.id);
			pst.setString(4, t.mechanicId);
			pst.setDate(2, java.sql.Date.valueOf(t.date));
			pst.setString(5, t.vehicleTypeId);
			pst.setLong(3, t.version++);

			pst.executeUpdate();

		} catch (SQLException e) {
			throw new PersistenceException(e);
		} finally {
			if (pst != null) try { pst.close(); } catch(SQLException e) { /* ignore */ }
		}

	}

	@Override
	public Optional<CertificateDALDto> findById(String id) {
		PreparedStatement pst = null;
		Connection c = null;
		ResultSet rs = null;
		try {
			c=Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TCERTIFICATES_FINDBYID"));
			pst.setString(1, id);
			rs = pst.executeQuery();
			
			return CertificateAssembler.toDALDto(rs);
		}catch(SQLException e) {
			throw new PersistenceException(e);
		}finally {
			Jdbc.close(rs,pst);
		}
	}

	@Override
	public List<CertificateDALDto> findAll() {
		PreparedStatement pst = null;
		Connection c = null;
		ResultSet rs = null;
		try {
			c=Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TCERTIFICATES_FINDALL"));
			rs = pst.executeQuery();
			
			return CertificateAssembler.toDALDtoList(rs);
		}catch(SQLException e) {
			throw new PersistenceException(e);
		}finally {
			Jdbc.close(rs,pst);
		}
	}

	@Override
	public List<CertificateDALDto> findByVehicleType(String vehicleType) {
		PreparedStatement pst = null;
		Connection c = null;
		ResultSet rs = null;
		try {
			c=Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TCERTIFICATES_FINDBYVEHICLETYPE"));
			pst.setString(1, vehicleType);
			rs = pst.executeQuery();
			
			return CertificateAssembler.toDALDtoList(rs);
		}catch(SQLException e) {
			throw new PersistenceException(e);
		}finally {
			Jdbc.close(rs,pst);
		}
	}

	@Override
	public List<CertificateDALDto> findByMechanic(String mechanic) {
		PreparedStatement pst = null;
		Connection c = null;
		ResultSet rs = null;
		try {
			c=Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TCERTIFICATES_FINDBYMECHANIC"));
			pst.setString(1, mechanic);
			rs = pst.executeQuery();
			
			return CertificateAssembler.toDALDtoList(rs);
		}catch(SQLException e) {
			throw new PersistenceException(e);
		}finally {
			Jdbc.close(rs,pst);
		}
	}

}

package uo.ri.cws.application.ui.manager.training.enrollment.action;

import console.Console;
import menu.Action;
import uo.ri.cws.application.business.BusinessFactory;
import uo.ri.cws.application.business.enrollment.EnrollmentService;

public class RemoveEnrollmentAction implements Action {

    @Override
    public void execute() throws Exception {
	// Ask the user for data
	String attId = Console.readString("Attendance id");

	// TODO Complete the code with the corresponding service call

	// Show result
	Console.println("Course attendance removed");
    }

}

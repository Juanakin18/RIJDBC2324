package uo.ri.cws.application.ui.manager.training.course.actions;

import console.Console;
import menu.Action;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.BusinessFactory;

public class RemoveCourseAction implements Action {

    @Override
    public void execute() throws BusinessException {

	// Ask the user for data
	String cId = Console.readString("Course id");

	BusinessFactory.forCourseService().deleteCourse(cId);
	// Show result
	Console.println("Course removed");
    }

}

package uo.ri.cws.application.ui.manager.training.enrollment.action;

import console.Console;
import menu.Action;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.BusinessFactory;
import uo.ri.cws.application.business.enrollment.EnrollmentService;
import uo.ri.cws.application.business.enrollment.EnrollmentService.EnrollmentBLDto;

public class RegisterEnrollmentAction implements Action {

    private EnrollmentUserInteractor user = new EnrollmentUserInteractor();

    @Override
    public void execute() throws BusinessException {

	// Ask the user for data
	EnrollmentBLDto att = new EnrollmentBLDto();
	user.fill(att);

	// TODO Complete the code with the corresponding service call

	// Show result
	Console.println("Attendance registered:" + att.id);
    }

}

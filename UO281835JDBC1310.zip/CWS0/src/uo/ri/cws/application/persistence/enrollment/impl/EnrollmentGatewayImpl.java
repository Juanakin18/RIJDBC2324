package uo.ri.cws.application.persistence.enrollment.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import jdbc.Jdbc;
import uo.ri.cws.application.persistence.PersistenceException;
import uo.ri.cws.application.persistence.enrollment.EnrollmentGateway;
import uo.ri.cws.application.persistence.enrollment.assembler.EnrollmentAssembler;
import uo.ri.cws.application.persistence.util.Conf;

public class EnrollmentGatewayImpl implements EnrollmentGateway {

	@Override
	public void add(EnrollmentDALDto t) {
		Connection c = null;
		PreparedStatement pst = null;

		try {
			c = Jdbc.createThreadConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TENROLLMENTS_ADD"));
			pst.setString(1, t.id);
			pst.setInt(2, t.attendance);
			pst.setBoolean(3, t.passed);
			pst.setString(5, t.courseId);
			pst.setString(6, t.mechanicId);
			pst.setLong(4, 1L);

			pst.executeUpdate();

		} catch (SQLException e) {
			throw new PersistenceException(e);
		} finally {
			if (pst != null) try { pst.close(); } catch(SQLException e) { /* ignore */ }
		}


	}

	@Override
	public void remove(String id) {
		PreparedStatement pst = null;
		Connection c = Jdbc.getCurrentConnection();
		try {
			pst = c.prepareStatement(Conf.getInstance().getProperty("TENROLLMENTS_DELETE"));
			pst.setString(1, id);
			pst.executeUpdate();
		}catch(SQLException e) {
			throw new PersistenceException();
		}
	}

	@Override
	public void update(EnrollmentDALDto t) {
		Connection c = null;
		PreparedStatement pst = null;

		try {
			c = Jdbc.createThreadConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TENROLLMENTS_UPDATE"));
			pst.setString(6, t.id);
			pst.setInt(1, t.attendance);
			pst.setBoolean(2, t.passed);
			pst.setString(4, t.courseId);
			pst.setString(5, t.mechanicId);
			pst.setLong(3, t.version);

			pst.executeUpdate();

		} catch (SQLException e) {
			throw new PersistenceException(e);
		} finally {
			if (pst != null) try { pst.close(); } catch(SQLException e) { /* ignore */ }
		}
	}

	@Override
	public Optional<EnrollmentDALDto> findById(String id) {
		PreparedStatement pst = null;
		Connection c = Jdbc.getCurrentConnection();
		ResultSet rs = null;
		try {
			c=Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TENROLLMENTS_FINDBYID"));
			pst.setString(1, id);
			rs = pst.executeQuery();
			
			return EnrollmentAssembler.toDALDto(rs);
		}catch(SQLException e) {
			throw new PersistenceException(e);
		}finally {
			Jdbc.close(rs,pst);
		}
	}

	@Override
	public List<EnrollmentDALDto> findAll() {
		PreparedStatement pst = null;
		Connection c = Jdbc.getCurrentConnection();
		ResultSet rs = null;
		try {
			c=Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TENROLLMENTS_FINDALL"));
			rs = pst.executeQuery();
			
			return EnrollmentAssembler.toDALDtoList(rs);
		}catch(SQLException e) {
			throw new PersistenceException(e);
		}finally {
			Jdbc.close(rs,pst);
		}
	}

	@Override
	public List<EnrollmentDALDto> findByMechanic(String mechanic_id) {
		PreparedStatement pst = null;
		Connection c = Jdbc.getCurrentConnection();
		ResultSet rs = null;
		try {
			c=Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TENROLLMENTS_FINDBYMECHANIC"));
			pst.setString(1, mechanic_id);
			rs = pst.executeQuery();
			
			return EnrollmentAssembler.toDALDtoList(rs);
		}catch(SQLException e) {
			throw new PersistenceException(e);
		}finally {
			Jdbc.close(rs,pst);
		}
	}

	@Override
	public List<EnrollmentDALDto> findByCourse(String course_id) {
		PreparedStatement pst = null;
		Connection c = Jdbc.getCurrentConnection();
		ResultSet rs = null;
		try {
			c=Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TENROLLMENTS_FINDBYCOURSE"));
			pst.setString(1, course_id);
			rs = pst.executeQuery();
			
			return EnrollmentAssembler.toDALDtoList(rs);
		}catch(SQLException e) {
			throw new PersistenceException(e);
		}finally {
			Jdbc.close(rs,pst);
		}
	}

	@Override
	public Optional<EnrollmentDALDto> findByMechanicAndCourse(String mechanic_id, String course_id) {
		PreparedStatement pst = null;
		Connection c = Jdbc.getCurrentConnection();
		ResultSet rs = null;
		try {
			c=Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TENROLLMENTS_FINDBYMECHANICANDCOURSE"));
			pst.setString(1, mechanic_id);
			pst.setString(2, course_id);
			rs = pst.executeQuery();
			
			return EnrollmentAssembler.toDALDto(rs);
		}catch(SQLException e) {
			throw new PersistenceException(e);
		}finally {
			Jdbc.close(rs,pst);
		}
	}

}

package uo.ri.cws.application.business.certificate.crud.commands;

import java.util.List;

import assertion.Argument;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.certificate.CertificateService.CertificateBLDto;
import uo.ri.cws.application.business.util.command.Command;

public class FindCertificatesByVehicleTypeId implements Command< List<CertificateBLDto> > {

	private String vehicleTypeId;
	public FindCertificatesByVehicleTypeId(String vehicleTypeId) {
		Argument.isNotNull(vehicleTypeId);
		Argument.isNotEmpty(vehicleTypeId);
		this.vehicleTypeId = vehicleTypeId;
	}

	@Override
	public  List<CertificateBLDto>  execute() throws BusinessException {
		// TODO Auto-generated method stub
		return null;
	}

}

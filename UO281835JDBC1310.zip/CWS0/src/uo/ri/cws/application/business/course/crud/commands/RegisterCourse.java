package uo.ri.cws.application.business.course.crud.commands;

import assertion.Argument;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.course.CourseService.CourseBLDto;
import uo.ri.cws.application.business.util.command.Command;

public class RegisterCourse implements Command<CourseBLDto> {

	private CourseBLDto dto;
	public RegisterCourse(CourseBLDto dto) {
		Argument.isNotNull(dto);
		Argument.isNotNull(dto.code);
		Argument.isNotEmpty(dto.code);
		Argument.isNotNull(dto.description);
		Argument.isNotEmpty(dto.description);
		Argument.isNotNull(dto.id);
		Argument.isNotEmpty(dto.id);
		Argument.isNotNull(dto.name);
		Argument.isNotEmpty(dto.name);
		Argument.isNotNull(dto.startDate);
		Argument.isNotNull(dto.endDate);
		Argument.isTrue(dto.endDate.isAfter(dto.startDate));
		this.dto = dto;
	}

	@Override
	public CourseBLDto execute() throws BusinessException {
		// TODO Auto-generated method stub
		return null;
	}

}

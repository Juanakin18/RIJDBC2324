package uo.ri.cws.application.business.course.assembler;

public class CourseAssembler {

}

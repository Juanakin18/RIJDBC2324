package uo.ri.cws.application.business.invoice.create.commands;

import java.util.List;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.invoice.InvoiceService.PaymentMeanForInvoicingBLDto;
import uo.ri.cws.application.business.util.command.Command;

public class FindPayMeansByClientDni implements Command<List<PaymentMeanForInvoicingBLDto>> {

	//private PaymentMeanGateway gtw = PersistenceFactory.forPaymentMean();
	//private String dni;
	public FindPayMeansByClientDni(String dni) {
		//this.dni = dni;
	}

	@Override
	public List<PaymentMeanForInvoicingBLDto> execute() throws BusinessException {
		return null;
	} 

}

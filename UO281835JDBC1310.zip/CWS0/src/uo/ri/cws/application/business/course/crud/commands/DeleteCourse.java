package uo.ri.cws.application.business.course.crud.commands;

import assertion.Argument;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.util.command.Command;

public class DeleteCourse implements Command<Void> {

	private String id;
	public DeleteCourse(String id) {
		Argument.isNotNull(id);
		Argument.isNotEmpty(id);
		this.id = id;
	}

	@Override
	public Void execute() throws BusinessException {
		// TODO Auto-generated method stub
		return null;
	}

}

package uo.ri.cws.application.business.course.crud.commands;

import java.util.Optional;

import assertion.Argument;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.course.CourseService.CourseBLDto;
import uo.ri.cws.application.business.util.command.Command;

public class FindCourseById implements Command<Optional<CourseBLDto>> {

	private String id;
	public FindCourseById(String cId) {
		Argument.isNotNull(cId);
		Argument.isNotEmpty(cId);
		this.id = cId;
	}

	@Override
	public Optional<CourseBLDto> execute() throws BusinessException {
		// TODO Auto-generated method stub
		return null;
	}

}

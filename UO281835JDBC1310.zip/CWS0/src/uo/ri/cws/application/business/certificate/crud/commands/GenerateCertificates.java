package uo.ri.cws.application.business.certificate.crud.commands;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.util.command.Command;

public class GenerateCertificates implements Command<Integer> {

	@Override
	public Integer execute() throws BusinessException {
		// TODO Auto-generated method stub
		return null;
	}

}

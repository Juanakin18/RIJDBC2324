package uo.ri.cws.application.business.certificate.crud.commands;

import java.util.List;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.certificate.CertificateService.CertificateBLDto;
import uo.ri.cws.application.business.util.command.Command;

public class FindCertificateRowsByVehicleTypeId implements Command< List<CertificateBLDto> > {

	@Override
	public  List<CertificateBLDto>  execute() throws BusinessException {
		// TODO Auto-generated method stub
		return null;
	}

}

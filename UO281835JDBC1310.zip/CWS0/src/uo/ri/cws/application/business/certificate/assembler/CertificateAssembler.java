package uo.ri.cws.application.business.certificate.assembler;

public class CertificateAssembler {

}

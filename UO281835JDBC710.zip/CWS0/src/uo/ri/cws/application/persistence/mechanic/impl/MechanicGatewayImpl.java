package uo.ri.cws.application.persistence.mechanic.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import jdbc.Jdbc;
import uo.ri.cws.application.persistence.PersistenceException;
import uo.ri.cws.application.persistence.mechanic.MechanicGateway;
import uo.ri.cws.application.persistence.mechanic.assembler.MechanicAssembler;
import uo.ri.cws.application.persistence.util.Conf;

public class MechanicGatewayImpl implements MechanicGateway{

	
	@Override
	public Optional<MechanicDALDto> findByDni(String dni) {
		Optional<MechanicDALDto> result = null;
		Connection c = null;
		PreparedStatement pst = null;
		ResultSet rs = null;

		try {
			c = Jdbc.createThreadConnection();
			
			pst = c.prepareStatement(Conf.getInstance().getProperty("TMECHANICS_FIND_BY_DNI"));
			pst.setString(1, dni);
			rs = pst.executeQuery();
			result = (MechanicAssembler.toMechanicDALDto(rs));
				
		} catch (SQLException e) {
			throw new PersistenceException(e);
		}
		finally {
			if (rs != null) try { rs.close(); } catch(SQLException e) { /* ignore */ }
			if (pst != null) try { pst.close(); } catch(SQLException e) { /* ignore */ }
			if (c != null) try { c.close(); } catch(SQLException e) { /* ignore */ }
			
		}
		if(result ==null)
			return Optional.empty();
		return result;
	}

	@Override
	public void add(MechanicDALDto t) {
		// Process
					Connection c = null;
					PreparedStatement pst = null;
					ResultSet rs = null;

					try {
						c = Jdbc.createThreadConnection();
						
						pst = c.prepareStatement(Conf.getInstance().getProperty("TMECHANICS_ADD"));
						pst.setString(1, t.id);
						pst.setString(2, t.dni);
						pst.setString(3, t.name);
						pst.setString(4, t.surname);
						pst.setLong(5, 1L);
						
						pst.executeUpdate();
						
					} catch (SQLException e) {
						throw new PersistenceException(e);
					}
					finally {
						if (rs != null) try { rs.close(); } catch(SQLException e) { /* ignore */ }
						if (pst != null) try { pst.close(); } catch(SQLException e) { /* ignore */ }
						if (c != null) try { c.close(); } catch(SQLException e) { /* ignore */ }
					}
	}

	@Override
	public void remove(String id) {
		Connection c = null;
		PreparedStatement pst = null;
		ResultSet rs = null;

		try {
			c = Jdbc.createThreadConnection();
			
			pst = c.prepareStatement(Conf.getInstance().getProperty("TMECHANICS_REMOVE"));
			pst.setString(1, id);
			
			pst.executeUpdate();
			
			
		} catch (SQLException e) {
			throw new PersistenceException(e);
		}
		finally {
			if (rs != null) try { rs.close(); } catch(SQLException e) { /* ignore */ }
			if (pst != null) try { pst.close(); } catch(SQLException e) { /* ignore */ }
			if (c != null) try { c.close(); } catch(SQLException e) { /* ignore */ }
		}
		
	}

	@Override
	public void update(MechanicDALDto t) {
		// Process
		PreparedStatement pst = null;
		ResultSet rs = null;
		 Connection c = null;
		
		try {
			c = Jdbc.createThreadConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TMECHANICS_UPDATE"));
			pst.setString(1, t.name);
			pst.setString(2, t.surname);
			pst.setString(3, t.id);
			
			pst.executeUpdate();
			
		} catch (SQLException e) {
			throw new PersistenceException(e);
		}
		finally {
			if (rs != null) try { rs.close(); } catch(SQLException e) { /* ignore */ }
			if (pst != null) try { pst.close(); } catch(SQLException e) { /* ignore */ }
			if (c != null) try { c.close(); } catch(SQLException e) { /* ignore */ }
		}
	}

	@Override
	public Optional<MechanicDALDto> findById(String id) {
		Connection c = null;
		PreparedStatement pst = null;
		ResultSet rs = null;

		try {
			c = Jdbc.createThreadConnection();
			
			pst = c.prepareStatement(Conf.getInstance().getProperty("TMECHANICS_FIND_BY_ID"));
			pst.setString(1, id);
			rs = pst.executeQuery();
			return  (MechanicAssembler.toMechanicDALDto(rs));
				
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
		finally {
			if (rs != null) try { rs.close(); } catch(SQLException e) { /* ignore */ }
			if (pst != null) try { pst.close(); } catch(SQLException e) { /* ignore */ }
			if (c != null) try { c.close(); } catch(SQLException e) { /* ignore */ }
			
		}
		
	}

	@Override
	public List<MechanicDALDto> findAll() {
		Connection c = null;
		PreparedStatement pst = null;
		ResultSet rs = null;

		try {
			c = Jdbc.createThreadConnection();
			
			pst = c.prepareStatement(Conf.getInstance().getProperty("TMECHANICS_FIND_ALL"));
			
			rs = pst.executeQuery();
			return MechanicAssembler.toMechanicDALDtoList(rs);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
		finally {
			if (rs != null) try { rs.close(); } catch(SQLException e) { /* ignore */ }
			if (pst != null) try { pst.close(); } catch(SQLException e) { /* ignore */ }
			if (c != null) try { c.close(); } catch(SQLException e) { /* ignore */ }
			
		}

	}

}

package uo.ri.cws.application.business.mechanic.crud;

import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.mechanic.MechanicService;
import uo.ri.cws.application.business.mechanic.crud.commands.AddMechanic;
import uo.ri.cws.application.business.mechanic.crud.commands.DeleteMechanic;
import uo.ri.cws.application.business.mechanic.crud.commands.FindAllMechanics;
import uo.ri.cws.application.business.mechanic.crud.commands.FindMechanicByDni;
import uo.ri.cws.application.business.mechanic.crud.commands.FindMechanicById;
import uo.ri.cws.application.business.mechanic.crud.commands.UpdateMechanic;

public class MechanicServiceImpl implements MechanicService {

	@Override
	public MechanicBLDto addMechanic(MechanicBLDto mechanic) throws BusinessException {
		new AddMechanic(mechanic).execute();;
		return mechanic;
	}

	@Override
	public void deleteMechanic(String idMechanic) throws BusinessException {
		new DeleteMechanic(idMechanic).execute();
	}

	@Override
	public void updateMechanic(MechanicBLDto mechanic) throws BusinessException {
		 new UpdateMechanic(mechanic).execute();;

	}

	@Override
	public Optional<MechanicBLDto> findMechanicById(String idMechanic) throws BusinessException {
		return new FindMechanicById(idMechanic).execute();
	}

	@Override
	public Optional<MechanicBLDto> findMechanicByDni(String dniMechanic) throws BusinessException {
		return new FindMechanicByDni(dniMechanic).execute();
	}

	@Override
	public List<MechanicBLDto> findAllMechanics() throws BusinessException {
		FindAllMechanics find = new FindAllMechanics();
		return find.execute();
	}

}

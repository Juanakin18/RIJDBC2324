package uo.ri.cws.application.business.invoice.create.commands;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import assertion.Argument;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.invoice.InvoiceService.WorkOrderForInvoicingBLDto;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.business.workorder.assembler.WorkOrderAssembler;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.client.ClientGateway;
import uo.ri.cws.application.persistence.client.ClientGateway.ClientDALDto;
import uo.ri.cws.application.persistence.vehicle.VehicleGateway;
import uo.ri.cws.application.persistence.vehicle.VehicleGateway.VehicleDALDto;
import uo.ri.cws.application.persistence.workorder.WorkOrderGateway;
import uo.ri.cws.application.persistence.workorder.WorkOrderGateway.WorkOrderDALDto;

public class FindNotInvoicedWorkOrders implements Command<List<WorkOrderForInvoicingBLDto>>{

private WorkOrderGateway gtw = PersistenceFactory.forWorkOrder();
	private ClientGateway cgtw = PersistenceFactory.forClient();
	private VehicleGateway vgtw = PersistenceFactory.forVehicle();
		private String dni;
	public FindNotInvoicedWorkOrders(String dni) {
		Argument.isNotNull(dni);
		Argument.isNotEmpty(dni);
		this.dni = dni;
	}

	public List<WorkOrderForInvoicingBLDto> execute() throws BusinessException {

		Optional<ClientDALDto> client = cgtw.findByDni(dni);
		if(client.isEmpty())
			throw new BusinessException("No existe ese cliente");
		String c_id = client.get().id;
		List<VehicleDALDto> vehicles = vgtw.findByClient(c_id);
		List<WorkOrderForInvoicingBLDto> dtos = new ArrayList<>();
		for(VehicleDALDto vehicle : vehicles) {
			List<WorkOrderDALDto> dto = gtw.findByVehicleId(vehicle.id);
			for(WorkOrderForInvoicingBLDto dto1 : WorkOrderAssembler.toInvoicingBLDtoWithDALD(dto)) {
				if(dto1.status.equals("FINISHED"))
					dtos.add(dto1);
			}
		}
		return dtos;

	}

}

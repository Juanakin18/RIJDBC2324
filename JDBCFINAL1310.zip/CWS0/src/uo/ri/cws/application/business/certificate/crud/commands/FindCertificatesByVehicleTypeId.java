package uo.ri.cws.application.business.certificate.crud.commands;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import assertion.Argument;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.certificate.CertificateService.CertificateBLDto;
import uo.ri.cws.application.business.certificate.assembler.CertificateAssembler;
import uo.ri.cws.application.business.mechanic.MechanicService.MechanicBLDto;
import uo.ri.cws.application.business.mechanic.assembler.MechanicAssembler;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.business.vehicletype.VehicleTypeService.VehicleTypeBLDto;
import uo.ri.cws.application.business.vehicletype.assembler.VehicleTypeAssembler;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.certificate.CertificateGateway;
import uo.ri.cws.application.persistence.certificate.CertificateGateway.CertificateDALDto;
import uo.ri.cws.application.persistence.mechanic.MechanicGateway;
import uo.ri.cws.application.persistence.vehicletype.VehicleTypeGateway;

public class FindCertificatesByVehicleTypeId implements Command< List<CertificateBLDto> > {

	private CertificateGateway gtw = PersistenceFactory.forCertificate();
	private MechanicGateway mgtw = PersistenceFactory.forMechanic();
	private VehicleTypeGateway vtgtw = PersistenceFactory.forVehicleType();
	private String vehicleTypeId;
	public FindCertificatesByVehicleTypeId(String vehicleTypeId) {
		Argument.isNotNull(vehicleTypeId);
		Argument.isNotEmpty(vehicleTypeId);
		this.vehicleTypeId = vehicleTypeId;
	}

	@Override
	public  List<CertificateBLDto>  execute() throws BusinessException {
		List<CertificateBLDto> dtos = new ArrayList<CertificateBLDto>();
		for(CertificateDALDto dto : gtw.findByVehicleType(vehicleTypeId)) {
			Optional<MechanicBLDto> mechanic = MechanicAssembler.toBLDto(mgtw.findById(dto.mechanic)) ;
			Optional<VehicleTypeBLDto> vehicleType = VehicleTypeAssembler.toBLDto(vtgtw.findById(dto.vehicleType));
			CertificateBLDto bldto = CertificateAssembler.toBLDto(dto);
			bldto.mechanic = mechanic.get();
			bldto.vehicleType = vehicleType.get();
			dtos.add(bldto);
		}
		return dtos;
	}

}

package uo.ri.cws.application.business;

import uo.ri.cws.application.business.certificate.CertificateService;
import uo.ri.cws.application.business.course.CourseService;
import uo.ri.cws.application.business.enrollment.EnrollmentService;
import uo.ri.cws.application.business.invoice.InvoiceService;
import uo.ri.cws.application.business.invoice.create.InvoiceServiceImpl;
/*import uo.ri.cws.application.business.client.ClientService;
import uo.ri.cws.application.business.invoice.InvoiceService;
import uo.ri.cws.application.business.invoice.create.InvoiceServiceImpl;*/
import uo.ri.cws.application.business.mechanic.MechanicService;
import uo.ri.cws.application.business.mechanic.crud.MechanicServiceImpl;
import uo.ri.cws.application.business.vehicle.VehicleService;
import uo.ri.cws.application.business.vehicletype.VehicleTypeService;

public class BusinessFactory {

	
	public static MechanicService forMechanicService() {
		return new MechanicServiceImpl();
	}

	
	public static InvoiceService forInvoicingService() {
		return new InvoiceServiceImpl();
	}

	public static VehicleTypeService forVehicleTypeService() {
		return null;
	}


	public static VehicleService forVehicleService() {
		return null;
	}


	public static CertificateService forCertificateService() {
		return null;
	}


	public static CourseService forCourseService() {
		return null;
	}


	public static EnrollmentService forEnrollmentService() {
		return null;
	}

	/*
	public static ClientService forClientService() {
		throw new RuntimeException("Not yet implemented");
	}*/

}

package uo.ri.cws.application.business.course.crud.commands;

import java.util.List;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.course.CourseService.CourseBLDto;
import uo.ri.cws.application.business.util.command.Command;

public class FindAllActiveCourses implements Command<List<CourseBLDto>> {

	@Override
	public List<CourseBLDto> execute() throws BusinessException {
		// TODO Auto-generated method stub
		return null;
	}

}

package uo.ri.cws.application.business.workorder.crud.commands;

import java.util.Optional;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.business.workorder.WorkOrderService.WorkOrderBLDto;

public class FindWorkOrderById implements Command<Optional<WorkOrderBLDto>> {

	public FindWorkOrderById(String woId) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Optional<WorkOrderBLDto> execute() throws BusinessException {
		// TODO Auto-generated method stub
		return null;
	}

}

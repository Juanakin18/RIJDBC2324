package uo.ri.cws.application.business.certificate.crud.commands;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.certificate.CertificateGateway;
import uo.ri.cws.application.persistence.certificate.CertificateGateway.CertificateDALDto;
import uo.ri.cws.application.persistence.course.CourseGateway;
import uo.ri.cws.application.persistence.course.CourseGateway.CourseDALDto;
import uo.ri.cws.application.persistence.dedication.DedicationGateway;
import uo.ri.cws.application.persistence.dedication.DedicationGateway.DedicationDALDto;
import uo.ri.cws.application.persistence.enrollment.EnrollmentGateway;
import uo.ri.cws.application.persistence.enrollment.EnrollmentGateway.EnrollmentDALDto;
import uo.ri.cws.application.persistence.mechanic.MechanicGateway;
import uo.ri.cws.application.persistence.mechanic.MechanicGateway.MechanicDALDto;
import uo.ri.cws.application.persistence.vehicletype.VehicleTypeGateway;
import uo.ri.cws.application.persistence.vehicletype.VehicleTypeGateway.VehicleTypeDALDto;

public class GenerateCertificates implements Command<Integer> {

	private CertificateGateway gtw = PersistenceFactory.forCertificate();
	private MechanicGateway mgtw = PersistenceFactory.forMechanic();
	private VehicleTypeGateway vtgtw = PersistenceFactory.forVehicleType();
	private EnrollmentGateway egtw = PersistenceFactory.forEnrollment();
	private CourseGateway cgtw = PersistenceFactory.forCourse();
	private DedicationGateway dgtw = PersistenceFactory.forDedication();
	
	/**
     * Generates certificates according to the rules: - Each vehicle type
     * specifies the number of attended-and-passed training hours needed to get
     * the certificate for that vehicle type
     * 
     * - The mechanic has to accumulate at least that number of hours in one or
     * several courses
     * 
     * - A course specifies the % of training hours devoted to some vehicle
     * types
     * 
     * If the mechanic already has a certification for this vehicle type, the new
     * one will be ignored 
     * @return the number of new certificates generated
     * 
     * @throws BusinessException DOES NOT
     */
	
	@Override
	public Integer execute() throws BusinessException {
		int generatedCertificates = 0;
		for(MechanicDALDto mechanic :  mgtw.findAll()) {
			for(VehicleTypeDALDto type : vtgtw.findAll()) {
				int horas = calcularHorasDeMecanicoYTipo(mechanic, type);
				if(horas > type.minTrainingHours) {
					generateCertificate(mechanic, type);
					generatedCertificates++;
				}
			}
		}
		return generatedCertificates;
	}

	private void generateCertificate(MechanicDALDto mechanic, VehicleTypeDALDto type) {
		CertificateDALDto dto = new CertificateDALDto();
		dto.id = UUID.randomUUID().toString();
		dto.obtainedAt = LocalDate.now();
		dto.version = 1l;
		dto.mechanic = mechanic.id;
		dto.vehicleType = type.id;
		gtw.add(dto);
	}

	private int calcularHorasDeMecanicoYTipo(MechanicDALDto mechanic, VehicleTypeDALDto type) {
		int total =0;
		for(DedicationDALDto dedication : dgtw.findByVehicleType(type.id)) {
			float percentage = dedication.percentage;
			Optional<CourseDALDto> course = cgtw.findById(dedication.course_id);
			CourseDALDto course1 = course.get();
			int horasCurso = course1.hours;
			Optional<EnrollmentDALDto> enrollment = egtw.findByMechanicAndCourse(mechanic.id, course1.id);
			EnrollmentDALDto enrollment1 = enrollment.get();
			int attendance = enrollment1.attendance;
			total+=horasCurso*(percentage*0.01)*attendance;
		}
		return total;
	}

}

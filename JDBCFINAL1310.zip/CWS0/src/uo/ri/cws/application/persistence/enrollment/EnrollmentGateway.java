package uo.ri.cws.application.persistence.enrollment;

import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.persistence.Gateway;

public interface EnrollmentGateway extends Gateway<uo.ri.cws.application.persistence.enrollment.EnrollmentGateway.EnrollmentDALDto>{

	public List<EnrollmentDALDto> findByMechanic(String mechanic_id);
	public List<EnrollmentDALDto> findByCourse(String course_id);
	public Optional<EnrollmentDALDto> findByMechanicAndCourse(String mechanic_id, String course_id);
	public class EnrollmentDALDto {

		public String id;
		public Long version;

		public String mechanicId;
		public String courseId;
		public int attendance; // percentage 0..100
		public boolean passed;


	    }
}

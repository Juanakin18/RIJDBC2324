package uo.ri.cws.application.persistence.dedication.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import jdbc.Jdbc;
import uo.ri.cws.application.persistence.PersistenceException;
import uo.ri.cws.application.persistence.dedication.DedicationGateway;
import uo.ri.cws.application.persistence.dedication.assembler.DedicationAssembler;
import uo.ri.cws.application.persistence.util.Conf;

public class DedicationGatewayImpl implements DedicationGateway {

	@Override
	public void add(DedicationDALDto t) {
		Connection c = null;
		PreparedStatement pst = null;

		try {
			c = Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TDEDICATIONS_ADD"));
			pst.setString(1, t.id);
			pst.setInt(2, t.percentage);
			pst.setString(4, t.course_id);
			pst.setString(5, t.vehicleType_id);
			pst.setLong(3, 1L);

			pst.executeUpdate();

		} catch (SQLException e) {
			throw new PersistenceException(e);
		} finally {
			if (pst != null) try { pst.close(); } catch(SQLException e) { /* ignore */ }
		}

	}

	@Override
	public void remove(String id) {
		PreparedStatement pst = null;
		Connection c = Jdbc.getCurrentConnection();
		try {
			pst = c.prepareStatement(Conf.getInstance().getProperty("TDEDICATIONS_DELETE"));
			pst.setString(1, id);
			pst.executeUpdate();
		}catch(SQLException e) {
			throw new PersistenceException();
		}
	}

	@Override
	public void update(DedicationDALDto t) {
		Connection c = null;
		PreparedStatement pst = null;

		try {
			c = Jdbc.createThreadConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TDEDICATIONS_UPDATE"));
			pst.setString(5, t.id);
			pst.setInt(2, t.percentage);
			pst.setString(3, t.course_id);
			pst.setString(4, t.vehicleType_id);
			pst.setLong(2, t.version);

			pst.executeUpdate();

		} catch (SQLException e) {
			throw new PersistenceException(e);
		} finally {
			if (pst != null) try { pst.close(); } catch(SQLException e) { /* ignore */ }
		}

	}

	@Override
	public Optional<DedicationDALDto> findById(String id) {
		PreparedStatement pst = null;
		Connection c = Jdbc.getCurrentConnection();
		ResultSet rs = null;
		try {
			c=Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TDEDICATIONS_FINDBYID"));
			pst.setString(1, id);
			rs = pst.executeQuery();
			
			return DedicationAssembler.toDALDto(rs);
		}catch(SQLException e) {
			throw new PersistenceException(e);
		}finally {
			Jdbc.close(rs,pst);
		}
	}

	@Override
	public List<DedicationDALDto> findAll() {
		PreparedStatement pst = null;
		Connection c = Jdbc.getCurrentConnection();
		ResultSet rs = null;
		try {
			c=Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TDEDICATIONS_FINDALL"));
			rs = pst.executeQuery();
			
			return DedicationAssembler.toDALDtoList(rs);
		}catch(SQLException e) {
			throw new PersistenceException(e);
		}finally {
			Jdbc.close(rs,pst);
		}
	}

	@Override
	public List<DedicationDALDto> findByCourse(String courseId) {
		PreparedStatement pst = null;
		Connection c = Jdbc.getCurrentConnection();
		ResultSet rs = null;
		try {
			c=Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TDEDICATIONS_FINDBYCOURSE"));
			pst.setString(1, courseId);
			rs = pst.executeQuery();
			
			return DedicationAssembler.toDALDtoList(rs);
		}catch(SQLException e) {
			throw new PersistenceException(e);
		}finally {
			Jdbc.close(rs,pst);
		}
	}

	@Override
	public List<DedicationDALDto> findByVehicleType(String type) {
		PreparedStatement pst = null;
		Connection c = Jdbc.getCurrentConnection();
		ResultSet rs = null;
		try {
			c=Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TDEDICATIONS_FINDBYVEHICLETYPE"));
			pst.setString(1, type);
			rs = pst.executeQuery();
			
			return DedicationAssembler.toDALDtoList(rs);
		}catch(SQLException e) {
			throw new PersistenceException(e);
		}finally {
			Jdbc.close(rs,pst);
		}
	}

}

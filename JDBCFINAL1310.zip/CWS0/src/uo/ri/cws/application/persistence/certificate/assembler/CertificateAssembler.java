package uo.ri.cws.application.persistence.certificate.assembler;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.persistence.certificate.CertificateGateway.CertificateDALDto;


public class CertificateAssembler {

	public static Optional<CertificateDALDto> toDALDto(ResultSet rs) throws SQLException {
		if (rs.next()) {
		    return Optional.of(resultSetToDALDto(rs));
		} else
		    return Optional.ofNullable(null);
	}

	private static CertificateDALDto resultSetToDALDto(ResultSet rs) throws SQLException {
		CertificateDALDto value = new CertificateDALDto();
		value.id = rs.getString("id");
		value.version = rs.getLong("version");

		value.mechanic = rs.getString("mechanic_id");
		value.vehicleType = rs.getString("vehicletype_id");
		value.obtainedAt = rs.getDate("date").toLocalDate();
		return value;
	}

	public static List<CertificateDALDto> toDALDtoList(ResultSet rs) throws SQLException {
		List<CertificateDALDto> res = new ArrayList<>();
		while (rs.next()) {
		    res.add(resultSetToDALDto(rs));
		}

		return res;
	    
	}

}

package uo.ri.cws.application.service.certificate;

import static org.junit.Assert.assertTrue;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.BusinessFactory;
import uo.ri.cws.application.business.certificate.CertificateService;
import uo.ri.cws.application.business.certificate.CertificateService.CertificateBLDto;
import uo.ri.cws.application.persistence.certificate.CertificateGateway.CertificateDALDto;
import uo.ri.cws.application.service.util.CertificateUtil;
import uo.ri.cws.application.service.util.sql.FindCertificatesSqlUnitOfWork;
import uo.ri.cws.application.service.util.sql.FindVehicleTypeByIdSqlUnitOfWork;
import uo.ri.cws.application.service.util.sql.FindVehicleTypeByNameSqlUnitOfWork;

public class GenerateSteps {

    private CertificateService service = BusinessFactory.forCertificateService();
    private int numCertificatesGenerated = 0;

    @When("I generate certificates")
    public void iGenerateCertificates() throws BusinessException {
	numCertificatesGenerated = service.generateCertificates();

    }

    @Then("no certificate is generated")
    public void noCertificateIsGenerated() {
	assertTrue(numCertificatesGenerated == 0);
	FindCertificatesSqlUnitOfWork unit = new FindCertificatesSqlUnitOfWork();
	unit.execute();
	List<CertificateDALDto> generated = unit.get();
	assertTrue(generated.isEmpty());

    }

    @Then("the following certificates are generated")
    public void theFollowingCertificatesAreGenerated(DataTable dataTable)
	    throws BusinessException {
	FindCertificatesSqlUnitOfWork unit = new FindCertificatesSqlUnitOfWork();
	unit.execute();
	List<CertificateDALDto> generatedDAL = unit.get();

	List<CertificateBLDto> generated = generateBLDto(generatedDAL);
	List<CertificateBLDto> expected = new ArrayList<>();
	List<Map<String, String>> table = dataTable.asMaps();
	for (Map<String, String> row : table) {
	    expected.add(processRow(row));
	}
	assertTrue(CertificateUtil.matchCertificates(generated, expected));

    }

    private List<CertificateBLDto> generateBLDto(List<CertificateDALDto> dal)
	    throws BusinessException {
	List<CertificateBLDto> result = new ArrayList<>();
	CertificateBLDto dto = null;

	for (CertificateDALDto one : dal) {
	    dto = new CertificateBLDto();
	    dto.id = one.id;
	    dto.version = one.version;
	    dto.obtainedAt = one.date;
	    dto.mechanic = BusinessFactory.forMechanicService()
					  .findMechanicById(one.mechanicId)
					  .get();

	    FindVehicleTypeByIdSqlUnitOfWork unit = new FindVehicleTypeByIdSqlUnitOfWork(
		    one.vehicleTypeId);
	    unit.execute();
	    dto.vehicleType = unit.get();
	    result.add(dto);
	}
	return result;
    }

    private CertificateBLDto processRow(Map<String, String> row)
	    throws BusinessException {
	String mDni = row.get("mechanicDNI");

	String vtName = row.get("vtname");

	CertificateBLDto result = new CertificateBLDto();
	result.obtainedAt = LocalDate.now();
	result.mechanic = BusinessFactory.forMechanicService()
					 .findMechanicByDni(mDni)
					 .get();

	FindVehicleTypeByNameSqlUnitOfWork unit = new FindVehicleTypeByNameSqlUnitOfWork(
		vtName);
	unit.execute();
	result.vehicleType = unit.get();

	return result;
    }

}

package uo.ri.cws.application.service.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import uo.ri.cws.application.persistence.dedication.DedicationGateway.DedicationDALDto;
import uo.ri.cws.application.persistence.vehicleType.VehicleTypeGateway.VehicleTypeDALDto;
import uo.ri.cws.application.service.util.sql.AddDedicationSqlUnitOfWork;
import uo.ri.cws.application.service.util.sql.AddDedicationsSqlUnitOfWork;
import uo.ri.cws.application.service.util.sql.FindDedicationsByCourseSqlUnitOfWork;

public class DedicationUtil {

    private List<DedicationDALDto> result = null;

    private Map<String, Integer> map = new HashMap<>();
    private DedicationDALDto dto = generateRandomDedication();

    public Map<String, Integer> getMap() {
	return map;
    }

    private DedicationDALDto generateRandomDedication() {
	DedicationDALDto dto = new DedicationDALDto();
	dto.id = UUID.randomUUID().toString();
	dto.version = 1L;
	return dto;
    }

    public List<DedicationDALDto> get() {
	return result;
    }

    public DedicationUtil findByCourse(String id) {
	FindDedicationsByCourseSqlUnitOfWork find = new FindDedicationsByCourseSqlUnitOfWork(
		id);
	find.execute();
	result = find.get();
	return this;
    }

    public DedicationUtil generatePercentages(List<VehicleTypeDALDto> vts) {
	int resto = 100;
	int percent = new Random().nextInt(10, 25);
	map.put(vts.get(0).id, percent);
	resto -= percent;
	percent = new Random().nextInt(20, 45);
	map.put(vts.get(1).id, Integer.valueOf(percent));
	resto -= percent;
	map.put(vts.get(2).id, Integer.valueOf(resto));
	return this;
    }

    public DedicationUtil register() {
	new AddDedicationSqlUnitOfWork(dto).execute();
	return this;
    }

    public DedicationUtil registerRandomPercentages() {
	new AddDedicationsSqlUnitOfWork(dto, map).execute();
	return this;
    }

    public DedicationUtil forCourse(String id) {
	this.dto.courseId = id;
	return this;
    }

    public DedicationUtil forVehicletype(String arg) {
	this.dto.vehicleTypeId = arg;
	return this;

    }

    public DedicationUtil withPercentage(int arg) {
	this.dto.percentage = arg;
	return this;
    }
}
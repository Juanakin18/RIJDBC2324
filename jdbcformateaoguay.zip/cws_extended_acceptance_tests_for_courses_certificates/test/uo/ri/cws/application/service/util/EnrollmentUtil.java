package uo.ri.cws.application.service.util;

import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import uo.ri.cws.application.business.course.CourseService.CourseBLDto;
import uo.ri.cws.application.business.enrollment.EnrollmentService.EnrollmentBLDto;
import uo.ri.cws.application.business.mechanic.MechanicService.MechanicBLDto;
import uo.ri.cws.application.service.util.sql.AddEnrollmentSqlUnitOfWork;

public class EnrollmentUtil {

    private EnrollmentBLDto dto = createDefaultEnrollmentDto();

    public EnrollmentUtil register() {
	new AddEnrollmentSqlUnitOfWork(dto).execute();
	return this;
    }

    private EnrollmentBLDto createDefaultEnrollmentDto() {
	EnrollmentBLDto dto = new EnrollmentBLDto();
	dto.id = UUID.randomUUID().toString();
	dto.version = 1L;
	dto.mechanicId = UUID.randomUUID().toString();
	dto.courseId = UUID.randomUUID().toString();
	dto.passed = false;
	dto.attendance = 0;
	return dto;
    }

    public EnrollmentBLDto get() {
	return dto;
    }

    public EnrollmentUtil withMechanic(String arg) {
	dto.mechanicId = arg;
	return this;
    }

    public EnrollmentUtil withCourse(String arg) {
	dto.courseId = arg;
	return this;

    }

    public EnrollmentUtil withId(String arg) {
	dto.courseId = arg;
	return this;

    }

    public EnrollmentUtil withPassed(String arg) {
	dto.passed = (arg.equals("1"));
	return this;
    }

    public EnrollmentUtil withAttendance(String arg) {
	dto.attendance = Integer.parseInt(arg);
	return this;
    }

    public EnrollmentUtil withAttendance(Integer att) {
	dto.attendance = att;
	return this;
    }

    public static boolean matchEnrollment(EnrollmentBLDto e1,
	    EnrollmentBLDto e2) {
	boolean result = false;
	result = (e1.id.equals(e2.id) && e1.attendance == e2.attendance
		&& e1.courseId.equals(e2.courseId)
		&& e1.mechanicId.equals(e2.mechanicId));
	MechanicBLDto m1 = e1.mechanic, m2 = e2.mechanic;
	result = (m1.id.equals(m2.id) && m1.dni.equals(m2.dni)
		&& m1.name.equals(m2.name) && m1.surname.equals(m2.surname));
	CourseBLDto c1 = e1.course, c2 = e2.course;
	result = (c1.id.equals(c2.id) && c1.code.equals(c2.code)
		&& c1.description.equals(c2.description)
		&& c1.name.equals(c2.name) && c1.hours == c2.hours);
	Map<String, Integer> map1 = c1.percentages, map2 = c2.percentages;
	result = map1.keySet().equals(map2.keySet());
	Map<String, Boolean> equalValues = areEqualKeyValues(map1, map2);
	result = equalValues.values().stream().allMatch(e -> e == true);
	return result;
    }

    private static Map<String, Boolean> areEqualKeyValues(
	    Map<String, Integer> first, Map<String, Integer> second) {
	return first.entrySet()
		    .stream()
		    .collect(Collectors.toMap(e -> e.getKey(),
			    e -> e.getValue().equals(second.get(e.getKey()))));
    }
}

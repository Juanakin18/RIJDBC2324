package uo.ri.cws.application.service.util.sql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import uo.ri.cws.application.business.enrollment.EnrollmentService.EnrollmentBLDto;

public class AddEnrollmentSqlUnitOfWork {

    private EnrollmentBLDto dto;
    private ConnectionData connectionData;
    private PreparedStatement insertIntoEnrollments;

    public AddEnrollmentSqlUnitOfWork(EnrollmentBLDto dto) {
	this.connectionData = PersistenceXmlScanner.scan();
	this.dto = dto;
    }

    public void execute() {
	JdbcTransaction trx = new JdbcTransaction(connectionData);
	trx.execute((con) -> {
	    prepareStatements(con);
	    insertEnrollment();
	});
    }

    private static final String INSERT_INTO_TENROLLMENTS = "INSERT INTO TENROLLMENTS"
	    + " ( ID, MECHANIC_ID, COURSE_ID, PASSED, ATTENDANCE, VERSION )"
	    + " VALUES ( ?, ?, ?, ?, ?, ?)";

    private void insertEnrollment() throws SQLException {
	PreparedStatement st = insertIntoEnrollments;
	int i = 1;
	st.setString(i++, dto.id);
	st.setString(i++, dto.mechanicId);
	st.setString(i++, dto.courseId);
	st.setBoolean(i++, dto.passed);
	st.setInt(i++, dto.attendance);
	st.setLong(i++, dto.version);

	st.executeUpdate();
    }

    private void prepareStatements(Connection con) throws SQLException {
	insertIntoEnrollments = con.prepareStatement(INSERT_INTO_TENROLLMENTS);

    }

}

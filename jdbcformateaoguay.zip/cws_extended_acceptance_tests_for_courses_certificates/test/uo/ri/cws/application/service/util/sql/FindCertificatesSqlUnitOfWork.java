package uo.ri.cws.application.service.util.sql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import uo.ri.cws.application.persistence.certificate.CertificateGateway.CertificateDALDto;

public class FindCertificatesSqlUnitOfWork {
    private static final String FIND_BY_ID = "SELECT * FROM TCERTIFICATES";

    private List<CertificateDALDto> result = new ArrayList<>();

    private ConnectionData connectionData;
    private PreparedStatement find;

    public FindCertificatesSqlUnitOfWork() {
	this.connectionData = PersistenceXmlScanner.scan();
    }

    public void execute() {
	JdbcTransaction trx = new JdbcTransaction(connectionData);
	trx.execute((con) -> {
	    prepareStatements(con);
	    findCertificates();
	});
    }

    private void findCertificates() throws SQLException {
	PreparedStatement st = find;
	CertificateDALDto dto = null;
	ResultSet rs = st.executeQuery();

	while (rs.next()) {
	    dto = new CertificateDALDto();
	    dto.id = rs.getString("id");
	    dto.version = rs.getLong("version");
	    dto.date = rs.getDate("date").toLocalDate();
	    dto.mechanicId = rs.getString("mechanic_id");
	    dto.vehicleTypeId = rs.getString("vehicletype_id");
	    this.result.add(dto);
	}
    }

    private void prepareStatements(Connection con) throws SQLException {
	find = con.prepareStatement(FIND_BY_ID);
    }

    public List<CertificateDALDto> get() {
	return result;
    }
}

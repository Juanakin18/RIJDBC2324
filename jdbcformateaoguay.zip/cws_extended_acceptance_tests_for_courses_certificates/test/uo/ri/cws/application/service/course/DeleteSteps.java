package uo.ri.cws.application.service.course;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.BusinessFactory;
import uo.ri.cws.application.business.course.CourseService;
import uo.ri.cws.application.business.course.CourseService.CourseBLDto;
import uo.ri.cws.application.business.mechanic.MechanicService.MechanicBLDto;
import uo.ri.cws.application.service.common.TestContext;
import uo.ri.cws.application.service.common.TestContext.Key;
import uo.ri.cws.application.service.util.DedicationUtil;
import uo.ri.cws.application.service.util.EnrollmentUtil;

public class DeleteSteps {

    private CourseService service = BusinessFactory.forCourseService();
    private TestContext ctx;

    private CourseBLDto course;
    private MechanicBLDto mechanic;
    private String courseId;

    public DeleteSteps(TestContext ctx) {
	this.ctx = ctx;

    }

    @When("I delete the course")
    public void iDeleteTheCourse() throws BusinessException {
	course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);
	service.deleteCourse(course.id);
    }

    @Then("the course is deleted")
    public void theCourseIsDeleted() throws BusinessException {
	assertTrue(service.findCourseById(course.id).isEmpty());
    }

    @Then("the dedications are deleted")
    public void theDedicationsAreDeleted() {
	DedicationUtil util = new DedicationUtil();
	assertTrue(util.findByCourse(course.id).get().isEmpty());
    }

    @When("I try to delete a non existent course")
    public void iTryToDeleteANonExistentCourse() throws BusinessException {
	courseId = "non-existent-courseId";

	tryDeleteAndKeepException();

    }

    @Given("the mechanic is enrolled in the course")
    public void theMechanicIsEnrolledInTheCourse() {
	course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);
	mechanic = (MechanicBLDto) ctx.get(Key.REGISTEREDMECHANIC);
	new EnrollmentUtil().withMechanic(mechanic.id)
			    .withCourse(course.id)
			    .register();
    }

    @When("I try to delete the course")
    public void iTryToDeleteTheCourse() {
	course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);
	courseId = course.id;
	tryDeleteAndKeepException();
    }

    private void tryDeleteAndKeepException() {
	try {
	    service.deleteCourse(courseId);
	    fail();
	} catch (BusinessException ex) {
	    ctx.setException(ex);
	} catch (IllegalArgumentException ex) {
	    ctx.setException(ex);
	}

    }

}

package uo.ri.cws.application.service.dedications;

import java.util.List;
import java.util.Map;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import uo.ri.cws.application.service.util.DedicationUtil;

public class DedicationsSteps {

    @Given("the following dedications")
    public void theFollowingDedications(DataTable dataTable) {
	List<Map<String, String>> table = dataTable.asMaps();
	for (Map<String, String> row : table) {
	    processRow(row);
	}

    }

    private void processRow(Map<String, String> row) {
	new DedicationUtil().forCourse(row.get("course"))
			    .forVehicletype(row.get("vehicletype"))
			    .withPercentage(
				    Integer.parseInt(row.get("percent")))
			    .register();
    }
}

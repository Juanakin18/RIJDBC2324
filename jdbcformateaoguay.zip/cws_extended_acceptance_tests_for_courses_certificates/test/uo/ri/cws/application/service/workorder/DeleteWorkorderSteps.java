package uo.ri.cws.application.service.workorder;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.BusinessFactory;
import uo.ri.cws.application.business.workorder.WorkOrderService;
import uo.ri.cws.application.business.workorder.WorkOrderService.WorkOrderBLDto;
import uo.ri.cws.application.service.common.TestContext;
import uo.ri.cws.application.service.common.TestContext.Key;
import uo.ri.cws.application.service.util.InterventionUtil;
import uo.ri.cws.application.service.util.WorkOrderUtil;
import uo.ri.cws.application.service.util.sql.FindWorkOrderSqlUnitOfWork;

public class DeleteWorkorderSteps {

    private TestContext ctx;

    private WorkOrderService service = BusinessFactory.forWorkOrderService();
    private WorkOrderBLDto dto = new WorkOrderUtil().get();
    private String id = null;

    public DeleteWorkorderSteps(TestContext ctx) {
	this.ctx = ctx;
    }

    @When("I try to delete a workorder with null argument")
    public void iTryToDeleteAWorkorderWithNullArgument() {
	tryDeleteAndKeepException(id);
    }

    @When("I try to delete a workorder with {string}")
    public void iTryToDeleteAWorkorderWith(String arg) {
	tryDeleteAndKeepException(arg);
    }

    @Given("some interventions")
    public void someInterventions() {
	dto = (WorkOrderBLDto) ctx.get(Key.WORKORDER);
	new InterventionUtil().withWorkorder(dto.id).register().get();
    }

    @When("I try to delete the workorder")
    public void iTryToDeleteTheWorkorder() {
	tryDeleteAndKeepException(dto.id);
    }

    @When("I delete the workorder")
    public void iDeleteTheWorkorder() throws BusinessException {
	dto = (WorkOrderBLDto) ctx.get(Key.WORKORDER);
	service.deleteWorkOrder(dto.id);
    }

    @Then("The workorder is deleted")
    public void theWorkorderIsDeleted() {
	FindWorkOrderSqlUnitOfWork unit = new FindWorkOrderSqlUnitOfWork(
		dto.id);
	unit.execute();
	assertTrue(unit.get() == null);
    }

    private void tryDeleteAndKeepException(String id) {
	try {
	    service.deleteWorkOrder(id);
	    fail();
	} catch (BusinessException ex) {
	    ctx.setException(ex);
	} catch (IllegalArgumentException ex) {
	    ctx.setException(ex);
	}

    }

}

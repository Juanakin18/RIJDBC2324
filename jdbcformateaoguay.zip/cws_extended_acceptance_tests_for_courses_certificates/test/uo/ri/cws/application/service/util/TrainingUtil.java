package uo.ri.cws.application.service.util;

import static org.junit.Assert.assertTrue;

import java.util.List;

import uo.ri.cws.application.business.course.CourseService.TrainingForMechanicRow;
import uo.ri.cws.application.business.course.CourseService.TrainingHoursRow;

public class TrainingUtil {

    public static void match(List<TrainingForMechanicRow> list1,
	    List<TrainingForMechanicRow> list2) {
	assertTrue(list1.size() == list2.size());
	for (TrainingForMechanicRow row : list1) {
	    assertTrue(matchAny(row, list2));
	}
    }

    private static boolean matchAny(TrainingForMechanicRow row,
	    List<TrainingForMechanicRow> list) {
	for (TrainingForMechanicRow t : list) {
	    if ((Math.abs(t.attendedHours - row.attendedHours) < 0.01)
		    && (t.enrolledHours == row.enrolledHours)
		    && (t.vehicleTypeName.equals(t.vehicleTypeName)))
		return true;
	}
	return false;
    }

    public static void matchTraining(List<TrainingHoursRow> list1,
	    List<TrainingHoursRow> list2) {
	TrainingHoursRow t = null;
	for (TrainingHoursRow thr : list1) {
	    t = find(list2, thr);
	    assertTrue(t != null);
	}

    }

    private static TrainingHoursRow find(List<TrainingHoursRow> l,
	    TrainingHoursRow thr) {

	for (TrainingHoursRow t : l) {
	    if (t.vehicleTypeName.equals(thr.vehicleTypeName)
		    && t.mechanicFullName.equals(thr.mechanicFullName)
		    && t.enrolledHours == thr.enrolledHours)
		return t;
	}
	return null;
    }

}

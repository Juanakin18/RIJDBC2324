package uo.ri.cws.application.service.util.sql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;

import uo.ri.cws.application.business.intervention.InterventionService.InterventionBLDto;

public class AddInterventionSqlUnitOfWork {

    private InterventionBLDto record;
    private ConnectionData connectionData;

    private PreparedStatement insertIntervention;

    public AddInterventionSqlUnitOfWork(InterventionBLDto dto) {
	this.connectionData = PersistenceXmlScanner.scan();
	this.record = dto;
    }

    public void execute() {
	JdbcTransaction trx = new JdbcTransaction(connectionData);
	trx.execute((con) -> {
	    prepareStatements(con);
	    insertIntervention();
	});
    }

    private static final String INSERT_INTO_TINTERVENTIONS = "INSERT INTO TINTERVENTIONS"
	    + " ( ID, VERSION, MINUTES, DATE, WORKORDER_ID)"
	    + " VALUES ( ?, ?, ?, ?, ?)";

    private void insertIntervention() throws SQLException {

	PreparedStatement st = insertIntervention;
	int i = 1;

	st.setString(i++, record.id);
	st.setLong(i++, record.version);
	st.setLong(i++, record.minutes);
	st.setTimestamp(i++, Timestamp.valueOf(record.date));
	st.setString(i, record.workorderId);
	st.executeUpdate();

    }

    private void prepareStatements(Connection con) throws SQLException {
	insertIntervention = con.prepareStatement(INSERT_INTO_TINTERVENTIONS);

    }
}

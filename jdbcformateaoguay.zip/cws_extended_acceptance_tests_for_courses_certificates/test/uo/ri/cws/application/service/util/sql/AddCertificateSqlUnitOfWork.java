package uo.ri.cws.application.service.util.sql;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import uo.ri.cws.application.persistence.certificate.CertificateGateway.CertificateDALDto;

public class AddCertificateSqlUnitOfWork {

    private ConnectionData connectionData;
    private CertificateDALDto dto = null;
    private PreparedStatement insertIntoCertificates;

    public AddCertificateSqlUnitOfWork(CertificateDALDto dto) {
	this.connectionData = PersistenceXmlScanner.scan();
	this.dto = dto;
    }

    public void execute() {
	JdbcTransaction trx = new JdbcTransaction(connectionData);
	trx.execute((con) -> {
	    prepareStatements(con);
	    insertCertificate();

	});
    }

    private static final String INSERT_INTO_TCERTIFICATES = "INSERT INTO TCERTIFICATES"
	    + " ( ID, VERSION, DATE, MECHANIC_ID, VEHICLETYPE_ID)"
	    + " VALUES ( ?, ?, ?, ?, ? )";

    private void prepareStatements(Connection con) throws SQLException {
	insertIntoCertificates = con.prepareStatement(
		INSERT_INTO_TCERTIFICATES);
    }

    private void insertCertificate() throws SQLException {
	PreparedStatement st = insertIntoCertificates;
	int i = 1;
	st.setString(i++, dto.id);
	st.setLong(i++, 1L);
	st.setDate(i++, Date.valueOf(dto.date));
	st.setString(i++, dto.mechanicId);
	st.setString(i++, dto.vehicleTypeId);

	st.executeUpdate();

    }
}

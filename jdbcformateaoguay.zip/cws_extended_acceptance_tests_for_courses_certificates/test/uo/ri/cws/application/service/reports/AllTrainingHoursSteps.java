package uo.ri.cws.application.service.reports;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.BusinessFactory;
import uo.ri.cws.application.business.course.CourseService;
import uo.ri.cws.application.business.course.CourseService.TrainingHoursRow;
import uo.ri.cws.application.service.util.TrainingUtil;

public class AllTrainingHoursSteps {

    private CourseService service = BusinessFactory.forCourseService();
    private List<TrainingHoursRow> trainingHoursFound = null;

    @When("Find all training hours")
    public void findAllTrainingHours() throws BusinessException {
	trainingHoursFound = service.findAllTrainingHours();
    }

    @Then("The following TrainingHoursRow are returned")
    public void theFollowingTrainingHoursRowAreReturned(
	    io.cucumber.datatable.DataTable dataTable) {
	List<Map<String, String>> table = dataTable.asMaps();
	TrainingHoursRow dto = null;
	List<TrainingHoursRow> dtos = new ArrayList<>();

	for (Map<String, String> row : table) {
	    dto = new TrainingHoursRow();
	    dto.vehicleTypeName = row.get("vehicletypename");
	    dto.enrolledHours = Integer.parseInt(row.get("enrolledhours"));
	    dto.mechanicFullName = row.get("mechanicfullname");
	    dtos.add(dto);
	}
	TrainingUtil.matchTraining(dtos, trainingHoursFound);
    }

}

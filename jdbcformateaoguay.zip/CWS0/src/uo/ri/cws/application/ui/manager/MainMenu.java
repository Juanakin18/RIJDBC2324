package uo.ri.cws.application.ui.manager;

import menu.BaseMenu;
import menu.NotYetImplementedAction;
import uo.ri.cws.application.ui.manager.training.TrainingMenu;

public class MainMenu extends BaseMenu {

	public MainMenu() {
		menuOptions = new Object[][] { { "Manager", null },
				{ "Mechanics management", MechanicMenu.class },
				{ "Training management", TrainingMenu.class },
				{ "Spare parts management", NotYetImplementedAction.class },
				{ "Vehicle types management", NotYetImplementedAction.class },
				{ "Contracts management", NotYetImplementedAction.class },
				{ "Payroll management", NotYetImplementedAction.class }

		};
	}

	public static void main(String[] args) {
		new MainMenu().execute();
	}

}

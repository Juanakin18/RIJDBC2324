package uo.ri.cws.application.ui.manager.action;

import java.util.Optional;

import console.Console;
import menu.Action;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.BusinessFactory;
import uo.ri.cws.application.business.mechanic.MechanicService.MechanicBLDto;

public class UpdateMechanicAction implements Action {

	@Override
	public void execute() throws BusinessException {

		// Get info
		String id = Console.readString("Type mechahic id to update");
		String name = Console.readString("Name");
		String surname = Console.readString("Surname");

		Optional<MechanicBLDto> dto1 = BusinessFactory.forMechanicService()
				.findMechanicById(id);

		if (dto1.isPresent()) {
			MechanicBLDto dto = dto1.get();
			dto.name = name;
			dto.surname = surname;
			dto.version++;

			BusinessFactory.forMechanicService().updateMechanic(dto);
		} else {
			Console.print("No existe");
		}

		// Print result
		Console.println("Mechanic updated");
	}

}

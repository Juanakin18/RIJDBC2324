package uo.ri.cws.application.business.mechanic.crud.commands;

import java.util.List;

import assertion.Argument;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.mechanic.MechanicGateway;
import uo.ri.cws.application.persistence.workorder.WorkOrderGateway;
import uo.ri.cws.application.persistence.workorder.WorkOrderGateway.WorkOrderDALDto;

public class DeleteMechanic implements Command<Void> {

	private String idMechanic;
	private MechanicGateway mg = PersistenceFactory.forMechanic();
	private WorkOrderGateway wogtw = PersistenceFactory.forWorkOrder();

	public DeleteMechanic(String idMechanic) {
		Argument.isNotNull(idMechanic);
		Argument.isNotEmpty(idMechanic);
		this.idMechanic = idMechanic;
	}

	public Void execute() throws BusinessException {
		if (!existMechanic(idMechanic))
			throw new BusinessException("Mechanic doesn't Exist");
		checkHasWorkOrders();
		mg.remove(idMechanic);
		return null;
	}

	private void checkHasWorkOrders() throws BusinessException {
		List<WorkOrderDALDto> workOrders = wogtw.findByMechanic(idMechanic);
		if (workOrders.size() > 0)
			throw new BusinessException("Tiene workorders asignadas");
	}

	private boolean existMechanic(String dni) {

		return mg.findById(dni).isPresent();
	}
}

package uo.ri.cws.application.business.workorder.crud.commands;

import java.util.Optional;

import assertion.Argument;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.mechanic.MechanicGateway;
import uo.ri.cws.application.persistence.mechanic.MechanicGateway.MechanicDALDto;
import uo.ri.cws.application.persistence.workorder.WorkOrderGateway;
import uo.ri.cws.application.persistence.workorder.WorkOrderGateway.WorkOrderDALDto;

public class AssignToMechanic implements Command<Void> {

	private WorkOrderGateway wogt = PersistenceFactory.forWorkOrder();
	private MechanicGateway mgt = PersistenceFactory.forMechanic();
	private String woId;
	private String mechanicId;

	public AssignToMechanic(String woId, String mechanicId) {
		Argument.isNotNull(mechanicId);
		Argument.isNotEmpty(mechanicId);
		Argument.isNotNull(woId);
		Argument.isNotEmpty(woId);
		this.woId = woId;
		this.mechanicId = mechanicId;

	}

	@Override
	public Void execute() throws BusinessException {
		MechanicDALDto mdto = getMechanic();
		WorkOrderDALDto dto = getWorkOrder();
		dto.mechanicId = mdto.dni;
		dto.version++;
		wogt.update(dto);
		return null;
	}

	private WorkOrderDALDto getWorkOrder() throws BusinessException {
		Optional<WorkOrderDALDto> dto = wogt.findById(woId);
		if (dto.isEmpty())
			throw new BusinessException("No existe esa workorder");
		return dto.get();
	}

	private MechanicDALDto getMechanic() throws BusinessException {
		Optional<MechanicDALDto> dto = mgt.findById(mechanicId);
		if (dto.isEmpty())
			throw new BusinessException("No existe ese mec�nico");
		return dto.get();
	}

}

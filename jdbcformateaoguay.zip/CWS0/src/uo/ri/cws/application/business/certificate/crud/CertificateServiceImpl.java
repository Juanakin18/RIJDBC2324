package uo.ri.cws.application.business.certificate.crud;

import java.util.List;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.certificate.CertificateService;
import uo.ri.cws.application.business.certificate.crud.commands.FindCertificateRowsByVehicleTypeId;
import uo.ri.cws.application.business.certificate.crud.commands.FindCertificatesByVehicleTypeId;
import uo.ri.cws.application.business.certificate.crud.commands.GenerateCertificates;
import uo.ri.cws.application.business.util.command.CommandExecutor;

public class CertificateServiceImpl implements CertificateService {

	private CommandExecutor executor = new CommandExecutor();

	@Override
	public int generateCertificates() throws BusinessException {
		return executor.execute(new GenerateCertificates());
	}

	@Override
	public List<CertificateBLDto> findCertificatesByVehicleTypeId(
			String vehicleTypeId) throws BusinessException {
		return executor
				.execute(new FindCertificatesByVehicleTypeId(vehicleTypeId));
	}

	@Override
	public List<CertificateBLDto> findCertificatesByVehicleTypeId()
			throws BusinessException {
		return executor.execute(new FindCertificateRowsByVehicleTypeId());
	}

}

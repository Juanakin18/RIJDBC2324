package uo.ri.cws.application.business.course.assembler;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.business.course.CourseService.CourseBLDto;
import uo.ri.cws.application.persistence.course.CourseGateway.CourseDALDto;

public class CourseAssembler {

	public static CourseDALDto toDALDto(CourseBLDto dto) {
		CourseDALDto daldto = new CourseDALDto();
		daldto.id = dto.id;
		daldto.version = dto.version;
		daldto.description = dto.description;
		daldto.endDate = dto.endDate;
		daldto.startDate = dto.startDate;
		daldto.name = dto.name;
		daldto.code = dto.code;
		daldto.hours = dto.hours;
		return daldto;
	}

	public static List<CourseBLDto> toBLDtoList(List<CourseDALDto> findAll) {
		List<CourseBLDto> dtos = new ArrayList<CourseBLDto>();
		for (CourseDALDto daldto : findAll) {
			dtos.add(toBLDto(daldto));
		}
		return dtos;
	}

	private static CourseBLDto toBLDto(CourseDALDto dto) {
		CourseBLDto daldto = new CourseBLDto();
		daldto.id = dto.id;
		daldto.version = dto.version;
		daldto.description = dto.description;
		daldto.endDate = dto.endDate;
		daldto.startDate = dto.startDate;
		daldto.name = dto.name;
		daldto.code = dto.code;
		daldto.hours = dto.hours;
		return daldto;
	}

	public static Optional<CourseBLDto> toBLDto(
			Optional<CourseDALDto> findById) {
		if (findById.isEmpty())
			return Optional.empty();
		return Optional.of(toBLDto(findById.get()));
	}

}

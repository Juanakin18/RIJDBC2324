package uo.ri.cws.application.business.invoice.create.commands;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import assertion.Argument;
import math.Round;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.invoice.InvoiceService.InvoiceBLDto;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.invoice.InvoiceGateway;
import uo.ri.cws.application.persistence.invoice.InvoiceGateway.InvoiceDALDto;
import uo.ri.cws.application.persistence.workorder.WorkOrderGateway;
import uo.ri.cws.application.persistence.workorder.WorkOrderGateway.WorkOrderDALDto;

public class CreateInvoice implements Command<InvoiceBLDto> {

	private WorkOrderGateway wg = PersistenceFactory.forWorkOrder();
	private InvoiceGateway ig = PersistenceFactory.forInvoice();
	private List<String> workOrderIds;

	public CreateInvoice(List<String> workOrderIds) {
		Argument.isNotNull(workOrderIds);
		Argument.isTrue(workOrderIds.size() > 0);
		for (String id : workOrderIds) {
			Argument.isNotNull(id);
			Argument.isNotEmpty(id);
		}
		this.workOrderIds = workOrderIds;
	}

	public InvoiceBLDto execute() throws BusinessException {
		InvoiceBLDto dto = null;
		try {

			if (!checkWorkOrdersExist(workOrderIds))
				throw new BusinessException("Workorder does not exist");
			if (!checkWorkOrdersFinished(workOrderIds))
				throw new BusinessException("Workorder is not finished yet");

			long numberInvoice = generateInvoiceNumber();
			LocalDate dateInvoice = LocalDate.now();
			double amount = calculateTotalInvoice(workOrderIds); // vat not
																	// included
			double vat = vatPercentage(amount, dateInvoice);
			double total = amount * (1 + vat / 100); // vat included
			total = Round.twoCents(total);

			String idInvoice = createInvoice(numberInvoice, dateInvoice, vat,
					total);
			linkWorkordersToInvoice(idInvoice, workOrderIds);
			markWorkOrderAsInvoiced(workOrderIds);
			updateVersion(workOrderIds);

			dto = new InvoiceBLDto();
			dto.id = idInvoice;
			dto.version = 1;
			dto.number = numberInvoice;
			dto.date = dateInvoice;
			dto.total = amount;
			dto.vat = vat;
		} catch (SQLException e) {
			throw new BusinessException(e);
		}

		return dto;
	}

	private void updateVersion(List<String> workOrderIds) throws SQLException {
		for (WorkOrderDALDto dto : wg.findByIds(workOrderIds)) {
			dto.version++;
			wg.update(dto);
		}
	}

	/*
	 * checks whether every work order id is FINISHED
	 */
	private boolean checkWorkOrdersFinished(List<String> workOrderIDS)
			throws SQLException, BusinessException {

		for (WorkOrderDALDto dto : wg.findByIds(workOrderIDS)) {
			if (!dto.status.equals("FINISHED"))
				return false;
		}
		return true;
	}

	/*
	 * Generates next invoice number (not to be confused with the inner id)
	 */
	private Long generateInvoiceNumber() throws SQLException {
		return ig.getNextInvoiceNumber();

	}

	/*
	 * Compute total amount of the invoice (as the total of individual work
	 * orders' amount
	 */
	private double calculateTotalInvoice(List<String> workOrderIDS)
			throws BusinessException, SQLException {

		double totalInvoice = 0.0;
		for (String workOrderID : workOrderIDS) {
			totalInvoice += getWorkOrderTotal(workOrderID);
		}
		return totalInvoice;
	}

	/*
	 * Set the invoice number field in work order table to the invoice number
	 * generated
	 */
	private void linkWorkordersToInvoice(String invoiceId,
			List<String> workOrderIDS) throws SQLException {

		for (WorkOrderDALDto dto : wg.findByIds(workOrderIDS)) {
			dto.invoiceId = invoiceId;
			dto.version++;
			wg.update(dto);
		}
	}

	/*
	 * Sets status to INVOICED for every workorder
	 */
	private void markWorkOrderAsInvoiced(List<String> ids) throws SQLException {

		for (WorkOrderDALDto dto : wg.findByIds(ids)) {
			dto.version++;
			dto.status = "INVOICED";
			wg.update(dto);
		}
	}

	/*
	 * checks whether every work order exist
	 */
	private boolean checkWorkOrdersExist(List<String> workOrderIDS)
			throws SQLException, BusinessException {
		for (String id : workOrderIDS) {
			Optional<WorkOrderDALDto> dto = wg.findById(id);
			if (dto.isEmpty())
				return false;
		}

		return true;

	}

	/*
	 * checks whether every work order id is FINISHED
	 */
	private Double getWorkOrderTotal(String workOrderID)
			throws SQLException, BusinessException {
		Optional<WorkOrderDALDto> dto = wg.findById(workOrderID);
		if (dto.isEmpty())
			throw new BusinessException(
					"Workorder " + workOrderID + " doesn't exist");
		else
			return dto.get().amount;
	}

	/*
	 * returns vat percentage
	 */
	private double vatPercentage(double totalInvoice, LocalDate dateInvoice) {
		return LocalDate.parse("2012-07-01").isBefore(dateInvoice) ? 21.0
				: 18.0;

	}

	/*
	 * Creates the invoice in the database; returns the id
	 */
	private String createInvoice(long numberInvoice, LocalDate dateInvoice,
			double vat, double total) throws SQLException {

		InvoiceDALDto dto = new InvoiceDALDto();
		dto.amount = total;
		dto.number = numberInvoice;
		dto.date = dateInvoice;
		dto.vat = vat;
		dto.id = UUID.randomUUID().toString();
		dto.version = 1L;
		dto.status = "NOT_YET_PAID";
		ig.add(dto);

		return dto.id;
	}

}

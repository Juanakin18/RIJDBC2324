package uo.ri.cws.application.business.workorder.crud;

import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.util.command.CommandExecutor;
import uo.ri.cws.application.business.workorder.WorkOrderService;
import uo.ri.cws.application.business.workorder.crud.commands.AddWorkOrder;
import uo.ri.cws.application.business.workorder.crud.commands.AssignToMechanic;
import uo.ri.cws.application.business.workorder.crud.commands.DeleteWorkOrder;
import uo.ri.cws.application.business.workorder.crud.commands.FindUnfinishedWorkOrders;
import uo.ri.cws.application.business.workorder.crud.commands.FindWorkOrderById;
import uo.ri.cws.application.business.workorder.crud.commands.FindWorkOrdersByPlateNumber;
import uo.ri.cws.application.business.workorder.crud.commands.FindWorkOrdersByVehicle;
import uo.ri.cws.application.business.workorder.crud.commands.UpdateWorkOrder;

public class WorkOrderServiceImpl implements WorkOrderService {

	private CommandExecutor exe = new CommandExecutor();

	@Override
	public WorkOrderBLDto registerNew(WorkOrderBLDto dto)
			throws BusinessException {
		return exe.execute(new AddWorkOrder(dto)).get();
	}

	@Override
	public void updateWorkOrder(WorkOrderBLDto dto) throws BusinessException {
		exe.execute(new UpdateWorkOrder(dto));
	}

	@Override
	public void deleteWorkOrder(String id) throws BusinessException {
		exe.execute(new DeleteWorkOrder(id));

	}

	@Override
	public Optional<WorkOrderBLDto> findWorkOrderById(String woId)
			throws BusinessException {

		return exe.execute(new FindWorkOrderById(woId));
	}

	@Override
	public List<WorkOrderBLDto> findUnfinishedWorkOrders()
			throws BusinessException {
		return exe.execute(new FindUnfinishedWorkOrders());
	}

	@Override
	public List<WorkOrderBLDto> findWorkOrdersByVehicleId(String id)
			throws BusinessException {
		return exe.execute(new FindWorkOrdersByVehicle(id));
	}

	@Override
	public List<WorkOrderBLDto> findWorkOrdersByPlateNumber(String plate)
			throws BusinessException {
		return exe.execute(new FindWorkOrdersByPlateNumber(plate));
	}

	@Override
	public void assignWorkOrderToMechanic(String woId, String mechanicId)
			throws BusinessException {
		exe.execute(new AssignToMechanic(woId, mechanicId));
	}

}

package uo.ri.cws.application.business.mechanic.crud.commands;

import java.util.UUID;

import assertion.Argument;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.mechanic.MechanicService.MechanicBLDto;
import uo.ri.cws.application.business.mechanic.assembler.MechanicAssembler;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.mechanic.MechanicGateway;

public class AddMechanic implements Command<MechanicBLDto> {

	private MechanicBLDto mechanic;
	private MechanicGateway mg = PersistenceFactory.forMechanic();

	public AddMechanic(MechanicBLDto mechanic) {
		Argument.isNotNull(mechanic);
		Argument.isNotNull(mechanic.dni);
		Argument.isNotEmpty(mechanic.dni);
		Argument.isNotNull(mechanic.name);
		Argument.isNotEmpty(mechanic.name);
		Argument.isNotNull(mechanic.surname);
		Argument.isNotEmpty(mechanic.surname);
		this.mechanic = mechanic;
	}

	public MechanicBLDto execute() throws BusinessException {
		if (existMechanic(mechanic.dni))
			throw new BusinessException("Mechanic Already Exists");
		mechanic.id = UUID.randomUUID().toString();
		mg.add(MechanicAssembler.toDALDto(mechanic));
		return mechanic;

	}

	private boolean existMechanic(String dni) {

		return mg.findByDni(dni).isPresent();
	}
}

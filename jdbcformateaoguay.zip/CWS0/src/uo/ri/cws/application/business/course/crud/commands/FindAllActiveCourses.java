package uo.ri.cws.application.business.course.crud.commands;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.course.CourseService.CourseBLDto;
import uo.ri.cws.application.business.course.assembler.CourseAssembler;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.course.CourseGateway;
import uo.ri.cws.application.persistence.dedication.DedicationGateway;
import uo.ri.cws.application.persistence.dedication.DedicationGateway.DedicationDALDto;

public class FindAllActiveCourses implements Command<List<CourseBLDto>> {

	private CourseGateway cgtw = PersistenceFactory.forCourse();

	private DedicationGateway dgtw = PersistenceFactory.forDedication();

	@Override
	public List<CourseBLDto> execute() throws BusinessException {
		List<CourseBLDto> dtos = new ArrayList<>();
		for (CourseBLDto dto : CourseAssembler
				.toBLDtoList(cgtw.findBeforeEndDate(LocalDate.now()))) {
			for (DedicationDALDto ddto : dgtw.findByCourse(dto.id)) {
				dto.percentages.put(ddto.vehicleTypeId, ddto.percentage);
			}
			dtos.add(dto);
		}
		return dtos;
	}

}

package uo.ri.cws.application.business.mechanic.crud.commands;

import assertion.Argument;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.mechanic.MechanicService.MechanicBLDto;
import uo.ri.cws.application.business.mechanic.assembler.MechanicAssembler;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.mechanic.MechanicGateway;

public class UpdateMechanic implements Command<Void> {

	private MechanicBLDto mechanic;
	private MechanicGateway mg = PersistenceFactory.forMechanic();

	public UpdateMechanic(MechanicBLDto mechanic) {
		Argument.isNotNull(mechanic);
		Argument.isNotNull(mechanic.id);
		Argument.isNotEmpty(mechanic.id);
		Argument.isNotNull(mechanic.name);
		Argument.isNotEmpty(mechanic.name);
		Argument.isNotNull(mechanic.surname);
		Argument.isNotEmpty(mechanic.surname);
		this.mechanic = mechanic;

	}

	public Void execute() throws BusinessException {
		if (!existMechanic(mechanic.id))
			throw new BusinessException("Mechanic doesn't Exist");
		mechanic.version++;
		mg.update(MechanicAssembler.toDALDto(mechanic));
		return null;
	}

	private boolean existMechanic(String id) {

		return mg.findById(id).isPresent();
	}

}

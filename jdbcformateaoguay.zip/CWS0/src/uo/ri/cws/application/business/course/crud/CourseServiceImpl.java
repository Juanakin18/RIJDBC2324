package uo.ri.cws.application.business.course.crud;

import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.course.CourseService;
import uo.ri.cws.application.business.course.crud.commands.DeleteCourse;
import uo.ri.cws.application.business.course.crud.commands.FindAllActiveCourses;
import uo.ri.cws.application.business.course.crud.commands.FindAllCourses;
import uo.ri.cws.application.business.course.crud.commands.FindCourseById;
import uo.ri.cws.application.business.course.crud.commands.RegisterCourse;
import uo.ri.cws.application.business.course.crud.commands.UpdateCourse;
import uo.ri.cws.application.business.util.command.CommandExecutor;

public class CourseServiceImpl implements CourseService {

	private CommandExecutor executor = new CommandExecutor();

	@Override
	public CourseBLDto registerNew(CourseBLDto dto) throws BusinessException {
		return executor.execute(new RegisterCourse(dto));
	}

	@Override
	public void updateCourse(CourseBLDto dto) throws BusinessException {
		executor.execute(new UpdateCourse(dto));
	}

	@Override
	public void deleteCourse(String id) throws BusinessException {
		executor.execute(new DeleteCourse(id));
	}

	@Override
	public List<CourseBLDto> findAllCourses() throws BusinessException {
		return executor.execute(new FindAllCourses());
	}

	@Override
	public Optional<CourseBLDto> findCourseById(String cId)
			throws BusinessException {
		return executor.execute(new FindCourseById(cId));
	}

	@Override
	public List<CourseBLDto> findAllActiveCourses() throws BusinessException {
		return executor.execute(new FindAllActiveCourses());
	}

	@Override
	public List<TrainingForMechanicRow> findTrainingHoursForMechanic(
			String mechanicId) throws BusinessException {
		// No me toca
		return null;
	}

	@Override
	public List<TrainingHoursRow> findAllTrainingHours()
			throws BusinessException {
		// No me toca
		return null;
	}

}

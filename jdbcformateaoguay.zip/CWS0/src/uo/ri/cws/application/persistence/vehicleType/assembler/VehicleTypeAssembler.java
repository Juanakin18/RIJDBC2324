package uo.ri.cws.application.persistence.vehicleType.assembler;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.persistence.vehicleType.VehicleTypeGateway.VehicleTypeDALDto;

public class VehicleTypeAssembler {

	public static Optional<VehicleTypeDALDto> toDALDto(ResultSet rs)
			throws SQLException {
		if (rs.next()) {
			return Optional.of(resultSetToDALDto(rs));
		} else
			return Optional.ofNullable(null);
	}

	private static VehicleTypeDALDto resultSetToDALDto(ResultSet rs)
			throws SQLException {
		VehicleTypeDALDto value = new VehicleTypeDALDto();
		value.id = rs.getString("id");
		value.version = rs.getLong("version");

		value.minTrainigHours = rs.getInt("mintraininghours");
		value.name = rs.getString("name");
		value.pricePerHour = rs.getDouble("priceperhour");
		return value;
	}

	public static List<VehicleTypeDALDto> toDALDtoList(ResultSet rs)
			throws SQLException {
		List<VehicleTypeDALDto> res = new ArrayList<>();
		while (rs.next()) {
			res.add(resultSetToDALDto(rs));
		}

		return res;
	}

}

package uo.ri.cws.application.persistence.client.assembler;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.business.client.ClientService.ClientBLDto;
import uo.ri.cws.application.persistence.client.ClientGateway.ClientDALDto;

public class ClientAssembler {
	public static Optional<ClientDALDto> toClientDALDto(ResultSet rs)
			throws SQLException {
		if (rs.next()) {
			return Optional.of(resultSetToClientDALDto(rs));
		} else
			return Optional.ofNullable(null);
	}

	private static ClientDALDto resultSetToClientDALDto(ResultSet rs)
			throws SQLException {
		ClientDALDto record = new ClientDALDto();
		record.id = rs.getString("id");
		record.version = rs.getLong("version");

		record.dni = rs.getString("dni");
		record.name = rs.getString("name");
		record.surname = rs.getString("surname");
		record.phone = rs.getString("phone");
		record.email = rs.getString("email");
		record.street = rs.getString("street");
		record.city = rs.getString("City");
		record.zipcode = rs.getString("Zipcode");
		return record;
	}

	public static List<ClientDALDto> toDALDtoList(ResultSet pst)
			throws SQLException {
		List<ClientDALDto> result = new ArrayList<ClientDALDto>();
		while (pst.next()) {
			result.add(toClientDALDto(pst).get());
		}

		return result;
	}

	public static List<ClientDALDto> toDALDtoList(List<ClientBLDto> dto1) {
		List<ClientDALDto> result = new ArrayList<ClientDALDto>();
		for (ClientBLDto dto2 : dto1) {
			result.add(toDALDto(dto2));
		}
		return result;
	}

	public static List<ClientBLDto> toBLDtoList(List<ClientDALDto> dto1) {
		List<ClientBLDto> result = new ArrayList<ClientBLDto>();
		for (ClientDALDto dto2 : dto1) {
			result.add(toBLDto(dto2));
		}
		return result;
	}

	public static ClientDALDto toDALDto(ClientBLDto dto1) {
		ClientDALDto dto = new ClientDALDto();
		dto.id = dto1.id;
		dto.dni = dto1.dni;
		dto.email = dto1.email;
		dto.name = dto1.name;
		dto.phone = dto1.phone;
		dto.surname = dto1.surname;
		dto.version = dto1.version;
		dto.city = dto1.addressCity;
		dto.street = dto1.addressStreet;
		dto.zipcode = dto1.addressZipcode;
		return dto;
	}

	public static ClientBLDto toBLDto(ClientDALDto dto1) {
		ClientBLDto dto = new ClientBLDto();
		dto.id = dto1.id;
		dto.dni = dto1.dni;
		dto.email = dto1.email;
		dto.name = dto1.name;
		dto.phone = dto1.phone;
		dto.surname = dto1.surname;
		dto.version = dto1.version;
		dto.addressCity = dto1.city;
		dto.addressStreet = dto1.street;
		dto.addressZipcode = dto1.zipcode;
		return dto;
	}
}

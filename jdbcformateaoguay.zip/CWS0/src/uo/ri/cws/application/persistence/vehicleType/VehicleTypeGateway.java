package uo.ri.cws.application.persistence.vehicleType;

import java.util.Optional;

import uo.ri.cws.application.persistence.Gateway;

public interface VehicleTypeGateway extends
		Gateway<uo.ri.cws.application.persistence.vehicleType.VehicleTypeGateway.VehicleTypeDALDto> {

	public Optional<VehicleTypeDALDto> findByName(String name);

	public static class VehicleTypeDALDto {

		public String id;
		public long version;

		public String name;
		public double pricePerHour;
		public int minTrainigHours;

	}
}

package uo.ri.cws.application.persistence.enrollment.assembler;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.persistence.enrollment.EnrollmentGateway.EnrollmentDALDto;

public class EnrollmentAssembler {

	public static Optional<EnrollmentDALDto> toDALDto(ResultSet rs)
			throws SQLException {
		if (rs.next()) {
			return Optional.of(resultSetToDALDto(rs));
		} else
			return Optional.ofNullable(null);
	}

	public static List<EnrollmentDALDto> toDALDtoList(ResultSet rs)
			throws SQLException {
		List<EnrollmentDALDto> res = new ArrayList<>();
		while (rs.next()) {
			res.add(resultSetToDALDto(rs));
		}

		return res;
	}

	private static EnrollmentDALDto resultSetToDALDto(ResultSet rs)
			throws SQLException {
		EnrollmentDALDto value = new EnrollmentDALDto();
		value.id = rs.getString("id");
		value.version = rs.getLong("version");

		value.courseId = rs.getString("course_id");
		value.mechanicId = rs.getString("mechanic_id");
		value.attendance = rs.getInt("attendance");
		value.passed = rs.getBoolean("passed");
		return value;
	}

}

package uo.ri.cws.application.persistence.course;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.persistence.Gateway;

public interface CourseGateway extends
		Gateway<uo.ri.cws.application.persistence.course.CourseGateway.CourseDALDto> {

	public Optional<CourseDALDto> findByCode(String code);

	public Optional<CourseDALDto> findByName(String name);

	public List<CourseDALDto> findBeforeEndDate(LocalDate date);

	public class CourseDALDto {
		public String id;
		public Long version;

		public String code;
		public String name;
		public String description;
		public LocalDate startDate;
		public LocalDate endDate;
		public int hours;

	}
}

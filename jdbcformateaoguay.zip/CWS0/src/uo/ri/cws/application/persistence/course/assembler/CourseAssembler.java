package uo.ri.cws.application.persistence.course.assembler;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.persistence.course.CourseGateway.CourseDALDto;

public class CourseAssembler {

	public static Optional<CourseDALDto> toDALDto(ResultSet rs)
			throws SQLException {
		if (rs.next()) {
			return Optional.of(resultSetToDALDto(rs));
		} else
			return Optional.ofNullable(null);

	}

	private static CourseDALDto resultSetToDALDto(ResultSet rs)
			throws SQLException {
		CourseDALDto value = new CourseDALDto();
		value.id = rs.getString("id");
		value.version = rs.getLong("version");

		value.description = rs.getString("description");
		value.name = rs.getString("name");
		value.code = rs.getString("code");
		value.endDate = rs.getDate("enddate").toLocalDate();
		value.startDate = rs.getDate("startdate").toLocalDate();
		value.hours = rs.getInt("hours");
		return value;
	}

	public static List<CourseDALDto> toDALDtoList(ResultSet rs)
			throws SQLException {
		List<CourseDALDto> res = new ArrayList<>();
		while (rs.next()) {
			res.add(resultSetToDALDto(rs));
		}

		return res;
	}
}

package uo.ri.cws.application.service.enrollment;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.List;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.BusinessFactory;
import uo.ri.cws.application.business.course.CourseService.CourseBLDto;
import uo.ri.cws.application.business.enrollment.EnrollmentService;
import uo.ri.cws.application.business.enrollment.EnrollmentService.EnrollmentBLDto;
import uo.ri.cws.application.service.common.TestContext;
import uo.ri.cws.application.service.common.TestContext.Key;

public class FindEnrollmentByCourseSteps {

    private TestContext ctx;
    private EnrollmentService service = BusinessFactory.forEnrollmentService();
    private String id = null;
    private List<EnrollmentBLDto> result = null;

    public FindEnrollmentByCourseSteps(TestContext ctx) {
	this.ctx = ctx;
    }

    @When("I try to enrollment with null arg")
    public void iTryToEnrollmentWithNullArg() {
	tryFindAndKeepException();
    }

    @When("I try to enrollment with {string}")
    public void iTryToEnrollmentWith(String arg) {
	id = arg;
	tryFindAndKeepException();
    }

    @When("I find enrollment for a non existent course")
    public void iFindEnrollmentForANonExistentCourse()
	    throws BusinessException {
	id = "non-existent";
	result = service.findEnrollmentByCourseId(id);
    }

    @When("I search enrollment for course {int}")
    public void iSearchEnrollmentForCourse(Integer arg)
	    throws BusinessException {
	id = arg.toString();
	result = service.findEnrollmentByCourseId(id);
    }

    @When("I find enrollment for the registered course")
    public void iFindEnrollmentForTheRegisteredCourse()
	    throws BusinessException {
	id = ((CourseBLDto) ctx.get(Key.REGISTEREDCOURSE)).id;
	result = service.findEnrollmentByCourseId(id);
    }

    @Then("the attendance is returned with {string}, {string}, {string}")
    public void theAttendanceIsReturnedWith(String mid, String pas,
	    String att) {
	String[] mids = mid.split(",");
	String[] atts = att.split(",");
	String[] pass = pas.split(",");
	String mechanic;
	int attendance;
	boolean passed;

	for (int index = 0; index < mids.length; index++) {
	    mechanic = mids[index];
	    attendance = Integer.parseInt(atts[index]);
	    passed = pass[index].equals("1");
	    assertTrue(find(result, mechanic, attendance, passed));
	}

    }

    private Boolean find(List<EnrollmentBLDto> l, String m, int a, boolean p) {
	for (EnrollmentBLDto e : l) {
	    if (e.mechanicId.equals(m) && e.passed == p && e.attendance == a)
		return true;
	}
	return false;
    }

    private void tryFindAndKeepException() {
	try {
	    service.findEnrollmentByCourseId(id);
	    fail();
	} catch (BusinessException ex) {
	    ctx.setException(ex);
	} catch (IllegalArgumentException ex) {
	    ctx.setException(ex);
	}

    }
}

package uo.ri.cws.application.service.util;

import java.time.LocalDateTime;
import java.util.UUID;

import uo.ri.cws.application.business.intervention.InterventionService.InterventionBLDto;
import uo.ri.cws.application.service.util.sql.AddInterventionSqlUnitOfWork;

public class InterventionUtil {

    private InterventionBLDto dto = randomDto();

    private InterventionBLDto randomDto() {
	InterventionBLDto dto = new InterventionBLDto();
	dto.id = UUID.randomUUID().toString();
	dto.version = 1L;
	dto.date = LocalDateTime.now();
	dto.minutes = 10;
	return dto;
    }

    public InterventionUtil register() {
	new AddInterventionSqlUnitOfWork(dto).execute();
	return this;
    }

    public InterventionBLDto get() {
	return this.dto;
    }

    public InterventionUtil withWorkorder(String arg) {
	dto.workorderId = arg;
	return this;
    }

}

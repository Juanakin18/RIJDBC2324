package uo.ri.cws.application.service.certificate;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.BusinessFactory;
import uo.ri.cws.application.business.certificate.CertificateService;
import uo.ri.cws.application.business.certificate.CertificateService.CertificateBLDto;
import uo.ri.cws.application.business.mechanic.MechanicService.MechanicBLDto;
import uo.ri.cws.application.business.vehicletype.VehicleTypeService.VehicleTypeBLDto;
import uo.ri.cws.application.service.common.TestContext;
import uo.ri.cws.application.service.util.CertificateUtil;
import uo.ri.cws.application.service.util.sql.FindVehicleTypeByIdSqlUnitOfWork;

public class FindByVehicleTypeSteps {

	private CertificateService service = BusinessFactory.forCertificateService();
	private TestContext ctx;
	private String certificateId = null;
	private List<CertificateBLDto> certificatesReturned;

	public FindByVehicleTypeSteps(TestContext ctx) {
		this.ctx = ctx;
	}

	@When("I try to find certificates by vehicle type id with null argument")
	public void iTryToFindCertificatesByVehicleTypeIdWithNullArgument() {
		this.certificateId = null;
		tryFindAndKeepException();
	}

	@When("I try to find certificates by vehicle type with {string}")
	public void iTryToFindCertificatesByVehicleTypeWith(String arg) {
		this.certificateId = arg;
		tryFindAndKeepException();
	}

	@When("I find certificates by vehicle type with a non existent id")
	public void iFindCertificatesByVehicleTypeWithANonExistentId() throws BusinessException {
		this.certificateId = "non-existent-id";
		service.findCertificatesByVehicleTypeId(this.certificateId);
	}

	@When("I find certificates by vehicle type with {string}")
	public void iFindCertificatesByVehicleTypeWith(String arg) throws BusinessException {
		this.certificateId = arg;
		certificatesReturned = service.findCertificatesByVehicleTypeId(arg);
	}

	@Given("the following certificates")
	public void theFollowingCertificates(DataTable dataTable) throws BusinessException {
		CertificateBLDto c = null;
		List<Map<String, String>> table = dataTable.asMaps();
		for (Map<String, String> row : table) {
			c = processRow(row);

			new CertificateUtil().withId(c.id).withDate(c.obtainedAt).withMechanicId(c.mechanic.id)
					.withvehicletype(c.vehicleType.id).register();

		}

	}

	private LocalDate toLocalDate(String arg) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate date = LocalDate.parse(arg, formatter);
		return date;
	}

	private CertificateBLDto processRow(Map<String, String> row) throws BusinessException {

		String certid = row.get("certid");
		LocalDate date = toLocalDate(row.get("date"));
		MechanicBLDto m = BusinessFactory.forMechanicService().findMechanicById(row.get("mechid")).get();
		FindVehicleTypeByIdSqlUnitOfWork unit = new FindVehicleTypeByIdSqlUnitOfWork(row.get("vtid"));
		unit.execute();
		VehicleTypeBLDto vt = unit.get();

		CertificateBLDto c = new CertificateBLDto();
		c.id = certid;
		c.obtainedAt = date;
		c.mechanic = m;
		c.vehicleType = vt;
		return c;
	}

	@Then("the following certificates are found")
	public void theFollowingCertificatesAreFound(io.cucumber.datatable.DataTable dataTable) throws BusinessException {
		List<CertificateBLDto> expected = new ArrayList<>();

		List<Map<String, String>> table = dataTable.asMaps();
		for (Map<String, String> row : table) {
			expected.add(processRow(row));
		}

		assertTrue(CertificateUtil.matchCertificates(expected, this.certificatesReturned));

	}

	@When("I find all certificates")
	public void iFindAllCertificates() throws BusinessException {
		certificatesReturned = service.findCertificatesByVehicleTypeId();
	}

	@Then("the following sorted certificates are found")
	public void theFollowingSortedCertificatesAreFound(DataTable dataTable) throws BusinessException {
		List<CertificateBLDto> expected = new ArrayList<>();

		List<Map<String, String>> table = dataTable.asMaps();
		for (Map<String, String> row : table) {
			expected.add(processRow(row));
		}
		
		assertTrue(CertificateUtil.matchSortedCertificates(expected, this.certificatesReturned));

		
	}

	private void tryFindAndKeepException() {
		try {
			service.findCertificatesByVehicleTypeId(this.certificateId);
			fail();
		} catch (BusinessException ex) {
			ctx.setException(ex);
		} catch (IllegalArgumentException ex) {
			ctx.setException(ex);
		}

	}
}

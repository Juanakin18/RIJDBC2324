package uo.ri.cws.application.service.enrollment;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.List;
import java.util.Map;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.BusinessFactory;
import uo.ri.cws.application.business.course.CourseService.CourseBLDto;
import uo.ri.cws.application.business.enrollment.EnrollmentService;
import uo.ri.cws.application.business.enrollment.EnrollmentService.EnrollmentBLDto;
import uo.ri.cws.application.business.mechanic.MechanicService.MechanicBLDto;
import uo.ri.cws.application.persistence.enrollment.EnrollmentGateway.EnrollmentDALDto;
import uo.ri.cws.application.service.common.TestContext;
import uo.ri.cws.application.service.common.TestContext.Key;
import uo.ri.cws.application.service.util.EnrollmentUtil;
import uo.ri.cws.application.service.util.sql.FindEnrollmentSqlUnitOfWork;

public class AddEnrollmentSteps {

    private TestContext ctx;
    private EnrollmentService service = BusinessFactory.forEnrollmentService();
    private EnrollmentBLDto dto = null;

    public AddEnrollmentSteps(TestContext ctx) {
	this.ctx = ctx;
    }

    @Given("the following attendance")
    public void theFollowingAttendance(DataTable dataTable) {
	List<Map<String, String>> table = dataTable.asMaps();
	for (Map<String, String> row : table) {
	    new EnrollmentUtil().withId(row.get("id"))
				.withMechanic(row.get("mechid"))
				.withCourse(row.get("courseid"))
				.withPassed(row.get("passed"))
				.withAttendance(row.get("attendance"))
				.register();
	}

    }

    @When("I try to register null enrollment")
    public void iTryToRegisterNullEnrollment() {
	tryAddAndKeepException();
    }

    @When("I try to register enrollment with null mechanic id")
    public void iTryToRegisterEnrollmentWithNullMechanicId() {
	dto = new EnrollmentUtil().withMechanic(null).get();
	tryAddAndKeepException();

    }

    @When("I try to register enrollment with null course id")
    public void iTryToRegisterEnrollmentWithNullCourseId() {
	dto = new EnrollmentUtil().withCourse(null).get();
	tryAddAndKeepException();
    }

    @When("I try to register enrollment with mechanic {string}")
    public void iTryToRegisterEnrollmentWithMechanic(String arg) {
	dto = new EnrollmentUtil().withMechanic(arg).get();
	tryAddAndKeepException();

    }

    @When("I try to register enrollment with course {string}")
    public void iTryToRegisterEnrollmentWithCourse(String arg) {
	dto = new EnrollmentUtil().withCourse(arg).get();
	tryAddAndKeepException();
    }

    @When("I try to register enrollment for a non existent mechanic")
    public void iTryToRegisterEnrollmentForANonExistentMechanic() {
	CourseBLDto course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);
	dto = new EnrollmentUtil().withCourse(course.id).get();
	tryAddAndKeepException();
    }

    @When("I try to register enrollment for a non existent course")
    public void iTryToRegisterEnrollmentForANonExistentCourse() {
	MechanicBLDto m = (MechanicBLDto) ctx.get(Key.REGISTEREDMECHANIC);
	dto = new EnrollmentUtil().withMechanic(m.id).get();
	tryAddAndKeepException();
    }

    @When("I try to register enrollment passed with attendance under threshold")
    public void iTryToRegisterEnrollmentPassedWithAttendanceUnderThreshold() {
	CourseBLDto course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);
	MechanicBLDto m = (MechanicBLDto) ctx.get(Key.REGISTEREDMECHANIC);
	dto = new EnrollmentUtil().withCourse(course.id)
				  .withMechanic(m.id)
				  .withAttendance("50")
				  .withPassed("1")
				  .get();
	tryAddAndKeepException();

    }

    @Given("enrollment for the mechanic to the registered course")
    public void enrollmentForTheMechanicToTheRegisteredCourse()
	    throws BusinessException {
	CourseBLDto course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);
	MechanicBLDto m = (MechanicBLDto) ctx.get(Key.REGISTEREDMECHANIC);
	dto = new EnrollmentUtil().withCourse(course.id)
				  .withMechanic(m.id)
				  .withAttendance("95")
				  .withPassed("1")
				  .get();
    }

    @When("I try to register enrollment for the mechanic to the registered course again")
    public void iTryToRegisterEnrollmentForTheMechanicToTheRegisteredCourseAgain()
	    throws BusinessException {

	tryAddAndKeepException();
    }

    @When("I try to register enrollment for the mechanic to the course")
    public void iTryToRegisterEnrollmentForTheMechanicToTheCourse()
	    throws BusinessException {
	CourseBLDto course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);
	MechanicBLDto m = (MechanicBLDto) ctx.get(Key.REGISTEREDMECHANIC);
	dto = new EnrollmentUtil().withCourse(course.id)
				  .withMechanic(m.id)
				  .withAttendance("95")
				  .withPassed("1")
				  .get();
	tryAddAndKeepException();
    }

    @When("I try to register enrollment for the mechanic to the course with {int}")
    public void iTryToRegisterEnrollmentForTheMechanicToTheCourseWith(
	    Integer att) {
	CourseBLDto course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);
	MechanicBLDto m = (MechanicBLDto) ctx.get(Key.REGISTEREDMECHANIC);
	dto = new EnrollmentUtil().withCourse(course.id)
				  .withMechanic(m.id)
				  .withAttendance(att)
				  .withPassed("1")
				  .get();
	tryAddAndKeepException();

    }

    @Given("enrollment registered for the mechanic to the registered course")
    public void enrollmentRegisteredForTheMechanicToTheRegisteredCourse() {
	CourseBLDto course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);
	MechanicBLDto m = (MechanicBLDto) ctx.get(Key.REGISTEREDMECHANIC);
	dto = new EnrollmentUtil().withCourse(course.id)
				  .withMechanic(m.id)
				  .withAttendance(100)
				  .withPassed("1")
				  .register()
				  .get();
	ctx.put(Key.REGISTEREDATTENDANCEID, dto.id);

    }

    @When("I register the attendance")
    public void iRegisterTheAttendance() throws BusinessException {
	dto = service.registerNew(dto);
	ctx.put(Key.REGISTEREDATTENDANCE, dto);
    }

    @Then("the attendance is registered")
    public void theAttendanceIsRegistered() {
	EnrollmentBLDto enrollment = (EnrollmentBLDto) ctx.get(
		Key.REGISTEREDATTENDANCE);
	enrollment.mechanic = (MechanicBLDto) ctx.get(Key.REGISTEREDMECHANIC);
	enrollment.course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);
	FindEnrollmentSqlUnitOfWork unit = new FindEnrollmentSqlUnitOfWork(
		enrollment.id);
	unit.execute();
	EnrollmentDALDto dal = unit.get();
	EnrollmentBLDto found = new EnrollmentBLDto();
	found.id = dal.id;
	found.attendance = dal.attendance;
	found.mechanicId = dal.mechanicId;
	found.courseId = dal.courseId;
	found.mechanic = (MechanicBLDto) ctx.get(Key.REGISTEREDMECHANIC);
	found.course = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);
	assertTrue(EnrollmentUtil.matchEnrollment(found, enrollment));
    }

    private void tryAddAndKeepException() {
	try {
	    service.registerNew(this.dto);
	    fail();
	} catch (BusinessException ex) {
	    ctx.setException(ex);
	} catch (IllegalArgumentException ex) {
	    ctx.setException(ex);
	}

    }
}

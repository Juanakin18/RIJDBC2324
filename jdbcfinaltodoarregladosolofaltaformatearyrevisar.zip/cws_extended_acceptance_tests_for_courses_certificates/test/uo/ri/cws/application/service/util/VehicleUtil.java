package uo.ri.cws.application.service.util;

import java.util.UUID;

import org.apache.commons.lang3.RandomStringUtils;

import uo.ri.cws.application.business.vehicle.VehicleService.VehicleBLDto;
import uo.ri.cws.application.persistence.vehicle.VehicleGateway.VehicleDALDto;
import uo.ri.cws.application.service.util.sql.AddVehicleSqlUnitOfWork;
import uo.ri.cws.application.service.util.sql.FindVehicleSqlUnitOfWork;

public class VehicleUtil {

    private VehicleBLDto dto = createDefaultVehicle();

    public VehicleUtil randomPlate() {
	dto.plateNumber = RandomStringUtils.randomAlphanumeric(7);
	return this;
    }

    public VehicleUtil register() {
	new AddVehicleSqlUnitOfWork(dto).execute();
	return this;
    }

    public VehicleUtil findByPlate(String plate) {
	FindVehicleSqlUnitOfWork finder = new FindVehicleSqlUnitOfWork(plate);
	finder.execute();
	this.dto = new VehicleBLDto();
	VehicleDALDto record = finder.get();
	dto.id = record.id;
	dto.clientId = record.clientId;
	dto.make = record.make;
	dto.model = record.model;
	dto.plateNumber = record.plateNumber;
	dto.vehicleTypeId = record.vehicleTypeId;
	dto.version = record.version;
	return this;
    }

    public VehicleBLDto get() {
	return dto;
    }

    private VehicleBLDto createDefaultVehicle() {
	VehicleBLDto res = new VehicleBLDto();
	res.id = UUID.randomUUID().toString();
	res.version = 1L;
	res.plateNumber = RandomStringUtils.randomAlphanumeric(9);
	res.make = RandomStringUtils.randomAlphabetic(4);
	res.model = RandomStringUtils.randomAlphabetic(4);
	res.clientId = RandomStringUtils.randomAlphabetic(4);

	return res;
    }

    public VehicleUtil withOwner(String id) {
	dto.clientId = id;
	return this;
    }

    public VehicleUtil withPlate(String string) {
	dto.plateNumber = string;
	return this;
    }

    public VehicleUtil withVehicleType(String arg) {
	dto.vehicleTypeId = arg;
	return this;
    }

}

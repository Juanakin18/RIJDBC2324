package uo.ri.cws.application.service.enrollment;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.BusinessFactory;
import uo.ri.cws.application.business.enrollment.EnrollmentService;
import uo.ri.cws.application.persistence.enrollment.EnrollmentGateway.EnrollmentDALDto;
import uo.ri.cws.application.service.common.TestContext;
import uo.ri.cws.application.service.common.TestContext.Key;
import uo.ri.cws.application.service.util.sql.FindEnrollmentSqlUnitOfWork;

public class DeleteEnrollmentSteps {

    private TestContext ctx;
    private EnrollmentService service = BusinessFactory.forEnrollmentService();
    private String id = null;

    public DeleteEnrollmentSteps(TestContext ctx) {
	this.ctx = ctx;
    }

    @When("I try to delete null enrollment")
    public void iTryToDeleteNullEnrollment() {
	tryDeleteAndKeepException();
    }

    @When("I try to delete enrollment with {string}")
    public void iTryToDeleteEnrollmentWith(String arg) {
	this.id = arg;
	tryDeleteAndKeepException();
    }

    @When("I try to delete non existent enrollment")
    public void iTryToDeleteNonExistentEnrollment() {
	this.id = "non-existent-enrollment";
	tryDeleteAndKeepException();

    }

    @When("I delete the enrollment")
    public void iDeleteTheEnrollment() throws BusinessException {
	id = (String) ctx.get(Key.REGISTEREDATTENDANCEID);
	service.deleteEnrollment(id);
    }

    @Then("the enrollment is deleted")
    public void theEnrollmentIsDeleted() {
	EnrollmentDALDto del = new FindEnrollmentSqlUnitOfWork(id).get();
	assertTrue(del == null);
    }

    private void tryDeleteAndKeepException() {
	try {
	    service.deleteEnrollment(id);
	    fail();
	} catch (BusinessException ex) {
	    ctx.setException(ex);
	} catch (IllegalArgumentException ex) {
	    ctx.setException(ex);
	}

    }
}

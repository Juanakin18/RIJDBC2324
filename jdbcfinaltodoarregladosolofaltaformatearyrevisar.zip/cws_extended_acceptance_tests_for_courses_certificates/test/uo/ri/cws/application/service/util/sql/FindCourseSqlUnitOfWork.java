package uo.ri.cws.application.service.util.sql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import uo.ri.cws.application.business.course.CourseService.CourseBLDto;

public class FindCourseSqlUnitOfWork {
    private /* CourseDALDto */ CourseBLDto result = null;
    private String id = null;

    private ConnectionData connectionData;
    private PreparedStatement findCourse;

    public FindCourseSqlUnitOfWork(String id) {
	this.connectionData = PersistenceXmlScanner.scan();
	this.id = id;
    }

    public void execute() {
	JdbcTransaction trx = new JdbcTransaction(connectionData);
	trx.execute((con) -> {
	    prepareStatements(con);
	    findCourse();
	});

    }

    public CourseBLDto get() {
	return result;
    }

    private static final String FIND_BY_ID = "SELECT * FROM TCOURSES "
	    + " WHERE id = ?";

    private void findCourse() throws SQLException {
	PreparedStatement st = findCourse;

	int i = 1;
	st.setString(i++, id);

	ResultSet rs = st.executeQuery();

	if (rs.next()) {
	    result = new CourseBLDto();// CourseDALDto();
	    result.id = rs.getString("id");
	    result.version = rs.getLong("version");
	    result.code = rs.getString("code");
	    result.name = rs.getString("name");
	    result.description = rs.getString("description");
	    result.hours = rs.getInt("hours");
	    result.startDate = rs.getDate("startDate").toLocalDate();
	    result.endDate = rs.getDate("endDate").toLocalDate();

	}
    }

    private void prepareStatements(Connection con) throws SQLException {
	findCourse = con.prepareStatement(FIND_BY_ID);
    }

}

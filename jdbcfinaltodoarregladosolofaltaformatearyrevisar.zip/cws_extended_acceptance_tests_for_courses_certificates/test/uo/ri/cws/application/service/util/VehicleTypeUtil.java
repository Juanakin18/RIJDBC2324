package uo.ri.cws.application.service.util;

import java.util.Random;
import java.util.UUID;

import org.apache.commons.lang3.RandomStringUtils;

import uo.ri.cws.application.persistence.vehicleType.VehicleTypeGateway.VehicleTypeDALDto;
import uo.ri.cws.application.service.util.sql.AddVehicleTypeSqlUnitOfWork;

public class VehicleTypeUtil {

    private VehicleTypeDALDto dto = createDefaultVehicleType();

    private VehicleTypeDALDto createDefaultVehicleType() {
	VehicleTypeDALDto res = new VehicleTypeDALDto();
	res.id = UUID.randomUUID().toString();
	res.version = 1L;
	res.name = RandomStringUtils.randomAlphanumeric(9);
	res.pricePerHour = new Random().nextInt(25, 50);
	res.minTrainigHours = new Random().nextInt(10, 20);

	return res;
    }

    public VehicleTypeUtil register() {
	new AddVehicleTypeSqlUnitOfWork(dto).execute();
	return this;
    }

    public VehicleTypeDALDto get() {
	return dto;
    }

    public VehicleTypeUtil withId(String arg) {
	this.dto.id = arg;
	return this;
    }

    public VehicleTypeUtil withName(String arg) {
	this.dto.name = arg;
	return this;
    }

    public VehicleTypeUtil withPricePerHour(String arg) {
	this.dto.pricePerHour = Integer.parseInt(arg);
	return this;
    }

    public VehicleTypeUtil withMinTrainingHours(String arg) {
	this.dto.minTrainigHours = Integer.parseInt(arg);
	return this;
    }

    public VehicleTypeUtil withMinTrainingHours(Integer arg) {
	this.dto.minTrainigHours = arg;
	return this;
    }
}

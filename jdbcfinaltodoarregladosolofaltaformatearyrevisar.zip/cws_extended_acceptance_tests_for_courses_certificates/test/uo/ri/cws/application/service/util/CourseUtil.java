package uo.ri.cws.application.service.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import uo.ri.cws.application.business.course.CourseService.CourseBLDto;
import uo.ri.cws.application.persistence.dedication.DedicationGateway.DedicationDALDto;
import uo.ri.cws.application.service.util.sql.AddCourseSqlUnitOfWork;
import uo.ri.cws.application.service.util.sql.FindCourseSqlUnitOfWork;

public class CourseUtil {

    private CourseBLDto dto = /* new CourseDALDto();// */
	    createDefaultCourseDto();

    private CourseBLDto createDefaultCourseDto() {
	CourseBLDto course = new CourseBLDto();

	course.id = UUID.randomUUID().toString();
	course.code = UUID.randomUUID().toString();
	course.name = UUID.randomUUID().toString();
	course.description = UUID.randomUUID().toString();
	course.startDate = LocalDate.now().plusDays(1);
	course.endDate = course.startDate.plusMonths(1);
	course.hours = 10;
	course.version = 1L;
	return course;
    }

    public CourseBLDto get() {
	CourseBLDto result = new CourseBLDto();
	result.id = dto.id;
	result.code = dto.code;
	result.name = dto.name;
	result.description = dto.description;
	result.hours = dto.hours;
	result.version = dto.version;
	result.startDate = dto.startDate;
	result.endDate = dto.endDate;
	return result;
    }

    public CourseUtil register() {
	new AddCourseSqlUnitOfWork(dto).execute();
	return this;
    }

    public CourseUtil find(String id) {
	FindCourseSqlUnitOfWork find = new FindCourseSqlUnitOfWork(id);
	find.execute();
	dto = find.get();
	return this;
    }

    public CourseUtil withCode(String arg) {
	dto.code = arg;
	return this;
    }

    public CourseUtil withName(String arg) {
	dto.name = arg;
	return this;
    }

    public CourseUtil withDescription(String arg) {
	dto.description = arg;
	return this;
    }

    public CourseUtil withStartDate(LocalDate arg) {
	dto.startDate = arg;
	return this;
    }

    public CourseUtil withEndDate(LocalDate arg) {
	dto.endDate = arg;
	return this;
    }

//	public CourseUtil withHours(int arg) {
//		dto.hours = arg;
//		return this;
//	}

    public CourseUtil withVersion(Long version) {
	dto.version = version;
	return this;
    }

    public CourseUtil withId(String id) {
	dto.id = id;
	return this;
    }

    public static void matchDedications(Map<String, Integer> percentages,
	    List<DedicationDALDto> dedicationsFound) {
	assertEquals(percentages.size(), dedicationsFound.size());
	for (DedicationDALDto dedication : dedicationsFound) {
	    assertTrue(percentages.get(
		    dedication.vehicleTypeId) == dedication.percentage);
	}
    }

    public static void matchCourse(CourseBLDto expected, CourseBLDto found) {
	assertFalse(expected == null);
	assertFalse(found == null);
	assertEquals(expected.code, found.code);
	assertEquals(expected.name, found.name);
	assertEquals(expected.description, found.description);
	assertEquals(expected.startDate, found.startDate);
	assertEquals(expected.endDate, found.endDate);
	assertEquals(expected.hours, found.hours);
    }

    public static void matchDedications(Map<String, Integer> map1,
	    Map<String, Integer> map2) {
	assertTrue(map1.size() == map2.size());
	assertTrue(
		map1.entrySet()
		    .stream()
		    .allMatch(e -> e.getValue().equals(map2.get(e.getKey()))));

    }

    public CourseUtil withHours(int arg) {
	this.dto.hours = arg;
	return this;
    }

    public CourseUtil withPercentages(Map<String, Integer> arg) {
	this.dto.percentages = arg;
	return this;
    }

    public static void matchCourses(List<CourseBLDto> list1,
	    List<CourseBLDto> list2) {
	CourseBLDto other;
	for (CourseBLDto one : list1) {
	    other = findInList(list2, one);
	    matchCourse(one, other);
	    matchDedications(one.percentages, other.percentages);
	}

    }

    private static CourseBLDto findInList(List<CourseBLDto> list,
	    CourseBLDto one) {
	for (CourseBLDto c : list) {
	    if (c.id.equals(one.id))
		return c;
	}
	return null;
    }

}

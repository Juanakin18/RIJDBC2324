package uo.ri.cws.application.business.certificate.crud.commands;

import java.time.LocalDate;
import java.util.Optional;
import java.util.UUID;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.certificate.CertificateGateway;
import uo.ri.cws.application.persistence.certificate.CertificateGateway.CertificateDALDto;
import uo.ri.cws.application.persistence.course.CourseGateway;
import uo.ri.cws.application.persistence.course.CourseGateway.CourseDALDto;
import uo.ri.cws.application.persistence.dedication.DedicationGateway;
import uo.ri.cws.application.persistence.dedication.DedicationGateway.DedicationDALDto;
import uo.ri.cws.application.persistence.enrollment.EnrollmentGateway;
import uo.ri.cws.application.persistence.enrollment.EnrollmentGateway.EnrollmentDALDto;
import uo.ri.cws.application.persistence.mechanic.MechanicGateway;
import uo.ri.cws.application.persistence.mechanic.MechanicGateway.MechanicDALDto;
import uo.ri.cws.application.persistence.vehicleType.VehicleTypeGateway;
import uo.ri.cws.application.persistence.vehicleType.VehicleTypeGateway.VehicleTypeDALDto;

public class GenerateCertificates implements Command<Integer> {

	private CertificateGateway gtw = PersistenceFactory.forCertificate();
	private MechanicGateway mgtw = PersistenceFactory.forMechanic();
	private VehicleTypeGateway vtgtw = PersistenceFactory.forVehicleType();
	private EnrollmentGateway egtw = PersistenceFactory.forEnrollment();
	private CourseGateway cgtw = PersistenceFactory.forCourse();
	private DedicationGateway dgtw = PersistenceFactory.forDedication();
	
	/**
     * Generates certificates according to the rules: - Each vehicle type
     * specifies the number of attended-and-passed training hours needed to get
     * the certificate for that vehicle type
     * 
     * - The mechanic has to accumulate at least that number of hours in one or
     * several courses
     * 
     * - A course specifies the % of training hours devoted to some vehicle
     * types
     * 
     * If the mechanic already has a certification for this vehicle type, the new
     * one will be ignored 
     * @return the number of new certificates generated
     * 
     * @throws BusinessException DOES NOT
     */
	
	@Override
	public Integer execute() throws BusinessException {
		int generatedCertificates = 0;
		for(MechanicDALDto mechanic :  mgtw.findAll()) {
			for(VehicleTypeDALDto type : vtgtw.findAll()) {
				int horas = calcularHorasDeMecanicoYTipo(mechanic, type); 
				if(horas > type.minTrainigHours) {
					Optional<CertificateDALDto> dto = 
							gtw.findByVehicleTypeAndMechanic(type.id,
									mechanic.id);
					if(dto.isEmpty()) {
						generateCertificate(mechanic, type);
						generatedCertificates++;
					}else {
						updateCertificate(dto.get(), mechanic, type);
					}
					
				}
			}
		}
		return generatedCertificates;
	}

	private void updateCertificate(CertificateDALDto dto,
			MechanicDALDto mechanic, VehicleTypeDALDto type) {
		dto.date = LocalDate.now();
		dto.version += 1l;
		dto.mechanicId = mechanic.id;
		dto.vehicleTypeId = type.id;
		gtw.update(dto);
	}

	private void generateCertificate(MechanicDALDto mechanic, 
			VehicleTypeDALDto type) {
		CertificateDALDto dto = new CertificateDALDto();
		dto.id = UUID.randomUUID().toString();
		dto.date = LocalDate.now();
		dto.version = 1l;
		dto.mechanicId = mechanic.id;
		dto.vehicleTypeId = type.id;
		gtw.add(dto);
	}

	private int calcularHorasDeMecanicoYTipo(MechanicDALDto mechanic, VehicleTypeDALDto type) {
		int total =0;
		for(EnrollmentDALDto enrollment : egtw.findByMechanic(mechanic.id)) {
			Optional<CourseDALDto> course = cgtw.findById(enrollment.courseId);
			if(course.isPresent()) {
				Optional<DedicationDALDto> ded = dgtw.findByCourseAndVehicleType(course.get().id,type.id);
				if(ded.isPresent()) {
					if(enrollment.passed) {
						double attendance = enrollment.attendance*0.01;
						total+=course.get().hours*(ded.get().percentage*0.01)*attendance;
					}
					
				}
			}
		}
		
		
		return total;
	}

}

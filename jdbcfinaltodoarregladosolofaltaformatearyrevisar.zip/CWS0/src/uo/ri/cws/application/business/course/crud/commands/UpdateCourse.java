package uo.ri.cws.application.business.course.crud.commands;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import assertion.Argument;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.course.CourseService.CourseBLDto;
import uo.ri.cws.application.business.course.assembler.CourseAssembler;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.course.CourseGateway;
import uo.ri.cws.application.persistence.course.CourseGateway.CourseDALDto;
import uo.ri.cws.application.persistence.dedication.DedicationGateway;
import uo.ri.cws.application.persistence.dedication.DedicationGateway.DedicationDALDto;
import uo.ri.cws.application.persistence.vehicleType.VehicleTypeGateway;

public class UpdateCourse implements Command<Void> {

	  /**
     * Updates the course specified by the id with the new data. A course an
     * only be modified if it has not yet started. If the start date is wrong
     * then remove the course and start again... The dedications of the course
     * to the vehicle types are not modified by this operation.
     *
     * @param dto. Must specify all the fields. The id and version fields must
     *             match the current state of the course. All the rest of fields
     *             must be filled, even if there is no change in the data. So it
     *             must pass the same validation as for new courses.
     *
     * @throws
     * 		IllegalArgumentException, if 
     * 			- argument is null, or 
     * 			- any field other than id and version is null, or 
     *          - any field type String is empty 
     * 		BusinessException if: 
     * 			- it does not exist the course with the specified id, or 
     * 			- the current version of the course does not match the version of the dto, or 
     * 			- the course has its start date in the past, or 
     * 			- the new data does not pass the validation specified in @see registerNew
     *
     */
	private CourseBLDto dto;
	private CourseGateway gtw = PersistenceFactory.forCourse();
	private VehicleTypeGateway vgtw = PersistenceFactory.forVehicleType();
	private DedicationGateway dgtw = PersistenceFactory.forDedication();
	public UpdateCourse(CourseBLDto dto) {
		Argument.isNotNull(dto);
		Argument.isNotNull(dto.code);
		Argument.isNotEmpty(dto.code);
		Argument.isNotNull(dto.description);
		Argument.isNotEmpty(dto.description);
		Argument.isNotNull(dto.id);
		Argument.isNotEmpty(dto.id);
		Argument.isNotNull(dto.name);
		Argument.isNotEmpty(dto.name);
		Argument.isNotNull(dto.startDate);
		Argument.isNotNull(dto.endDate);
		Argument.isNotNull(dto.percentages);
		this.dto = dto;
	}

	@Override
	public Void execute() throws BusinessException {
		checkExists();
		checkDates();
		checkHours();
		checkPercentages();
		checkTotalPercentages();		
		updateToDatabase();
		
		return null;
	}
	private void updateToDatabase() {
		dto.version++;
		Map<String, Integer> percentages = dto.percentages;
		List<DedicationDALDto> ddtos = dgtw.findByCourse(dto.id);
		
		int i =0; 
		for(String type : percentages.keySet()) {
				DedicationDALDto ddto = ddtos.get(i);
				ddto.version++;
				ddto.courseId = dto.id;
				ddto.vehicleTypeId = type;
				ddto.percentage = percentages.get(type);
				dgtw.update(ddto);
				i++;
		}
		gtw.update(CourseAssembler.toDALDto(dto));
	}

	private void checkHours() throws BusinessException {
		if(dto.hours<=0)
			throw new BusinessException("Las horas son negativas");
	}

	private void checkTotalPercentages() throws BusinessException {
		Map<String, Integer> percentages = dto.percentages;
		int total =0;
		for(String type : percentages.keySet()) {
			int porcentaje = percentages.get(type);
			if(porcentaje<=0)
				throw new BusinessException("Porcentaje no v�lido");
			total+=porcentaje;
		}
		if(total>100)
			throw new BusinessException("Los porcentajes suman m�s de 100");
		if(total<100)
			throw new BusinessException("Los porcentajes suman menos de 100");
	}


	private void checkDates() throws BusinessException {
		if(dto.startDate.isBefore(LocalDate.now()))
			throw new BusinessException("La fecha es anterior a hoy");
		if(dto.endDate.isBefore(LocalDate.now()))
			throw new BusinessException("La fecha es anterior a hoy");
		if(dto.endDate.isBefore(dto.startDate))
			throw new BusinessException("La fecha final es anterior a la inicial");
	}
	private void checkPercentages() throws BusinessException {
		Map<String, Integer> percentages = dto.percentages;
		if(percentages==null)
			throw new BusinessException();
		for(String type : percentages.keySet()) {
			if(vgtw.findById(type).isEmpty())
				throw new BusinessException("No existe el tipo: "+type);
		}
	}

	private void checkExists() throws BusinessException {
		Optional<CourseDALDto> dto1 = gtw.findById(dto.id);
		Optional<CourseDALDto> dto2 = gtw.findByName(dto.name);
		Optional<CourseDALDto> dto3 = gtw.findById(dto.code);
		if(dto1.isEmpty()) {
			throw new BusinessException("No existe");
		}
		if(dto2.isPresent()) {
			throw new BusinessException("Nombre repetido");
		}
		if(dto3.isPresent()) {
			throw new BusinessException("Codigo repetido");
		}
		if(dto1.get().version!=dto.version)
			throw new BusinessException("La versi�n no coincide");
	}

}

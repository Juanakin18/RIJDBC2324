package uo.ri.cws.application.business.workorder.assembler;

import java.util.ArrayList;
import java.util.List;

import uo.ri.cws.application.business.invoice.InvoiceService.WorkOrderForInvoicingBLDto;
import uo.ri.cws.application.business.workorder.WorkOrderService.WorkOrderBLDto;
import uo.ri.cws.application.persistence.workorder.WorkOrderGateway.WorkOrderDALDto;

public class WorkOrderAssembler {

	public static List<WorkOrderBLDto> toWorkOrderBLDtoList(List<WorkOrderDALDto> findByDni) {
		List<WorkOrderBLDto> dtos = new ArrayList<WorkOrderBLDto>();
		for(WorkOrderDALDto dto : findByDni) {
			dtos.add(toWorkOrderBLDto(dto));
		}
		return dtos;
	}
	
	public static List<WorkOrderDALDto> toWorkOrderDALDtoList(List<WorkOrderBLDto> findByDni) {
		List<WorkOrderDALDto> dtos = new ArrayList<WorkOrderDALDto>();
		for(WorkOrderBLDto dto : findByDni) {
			dtos.add(toWorkOrderDALDto(dto));
		} 
		return dtos;
	}


	public static WorkOrderBLDto toWorkOrderBLDto(WorkOrderDALDto dto) {
		WorkOrderBLDto dto1 = new WorkOrderBLDto();
		dto1.id = dto.id;
		dto1.version = dto.version;
		dto1.vehicleId = dto.vehicleId;
		dto1.description = dto.description;
		dto1.date = dto.date;
		dto1.amount = dto.amount;
		dto1.status = dto.status;
		dto1.mechanicId = dto.mechanicId;
		dto1.invoiceId = dto.invoiceId;
		return dto1;
	}
	public static WorkOrderDALDto toWorkOrderDALDto(WorkOrderBLDto dto) {
		WorkOrderDALDto dto1 = new WorkOrderDALDto();
		dto1.id = dto.id;
		dto1.version = dto.version;
		dto1.vehicleId = dto.vehicleId;
		dto1.description = dto.description;
		dto1.date = dto.date;
		dto1.amount = dto.amount;
		dto1.status = dto.status;
		dto1.mechanicId = dto.mechanicId;
		dto1.invoiceId = dto.invoiceId;
		return dto1;
	}


	public static WorkOrderDALDto toVehicleDALDto(WorkOrderBLDto dto) {
		WorkOrderDALDto dto1 = new WorkOrderDALDto();
		dto1.id = dto.id;
		dto1.version = dto.version;
		dto1.vehicleId = dto.vehicleId;
		dto1.description = dto.description;
		dto1.date = dto.date;
		dto1.amount = dto.amount;
		dto1.status = dto.status;
		dto1.mechanicId = dto.mechanicId;
		dto1.invoiceId = dto.invoiceId;
		return dto1;
	}

	public static List<WorkOrderForInvoicingBLDto> toInvoicingBLDtoWithDALD(List<WorkOrderDALDto> findByVehicleId) {
		List<WorkOrderForInvoicingBLDto> dtos = new ArrayList<WorkOrderForInvoicingBLDto>();
		for(WorkOrderDALDto dto : findByVehicleId) {
			dtos.add(toInvoicingBLDto(dto));
		}
		return dtos;
	}

	private static WorkOrderForInvoicingBLDto toInvoicingBLDto(WorkOrderDALDto dto) {
		WorkOrderForInvoicingBLDto dto1 = new WorkOrderForInvoicingBLDto();
		dto1.id = dto.id;
		dto1.description = dto.description;
		dto1.date = dto.date;
		dto1.total = dto.amount;
		dto1.status = dto.status;
		return dto1;
	}

	public static List<WorkOrderForInvoicingBLDto> toInvoicingBLDto(List<WorkOrderBLDto> list) {
		List<WorkOrderForInvoicingBLDto> dtos = new ArrayList<WorkOrderForInvoicingBLDto>();
		List<WorkOrderDALDto> findByVehicleId = toWorkOrderDALDtoList(list);
		for(WorkOrderDALDto dto : findByVehicleId) {
			dtos.add(toInvoicingBLDto(dto));
		}
		return dtos;
	}
}

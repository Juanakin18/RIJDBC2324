package uo.ri.cws.application.business.client.crud.commands;

import java.util.List;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.client.ClientService.ClientBLDto;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.client.ClientGateway;
import uo.ri.cws.application.persistence.client.assembler.ClientAssembler;

public class FindAllClients implements Command<List<ClientBLDto>> {

	private ClientGateway cgtw = PersistenceFactory.forClient();
	@Override
	public List<ClientBLDto> execute() throws BusinessException {
			return ClientAssembler.toBLDtoList(cgtw.findAll());
	}

} 

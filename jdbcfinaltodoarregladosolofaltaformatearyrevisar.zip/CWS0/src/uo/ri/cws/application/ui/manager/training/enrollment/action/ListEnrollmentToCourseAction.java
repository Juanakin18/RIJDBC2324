package uo.ri.cws.application.ui.manager.training.enrollment.action;

//import java.util.List;

import menu.Action;
/*import uo.ri.cws.application.business.BusinessFactory;
import uo.ri.cws.application.business.enrollment.EnrollmentService;
import uo.ri.cws.application.business.enrollment.EnrollmentService.EnrollmentBLDto;
import uo.ri.cws.application.ui.util.Printer;
*/
public class ListEnrollmentToCourseAction implements Action {

    //private EnrollmentUserInteractor user = new EnrollmentUserInteractor();

    @Override
    public void execute() throws Exception {
	/*String cId = user.askForCourseId();

	// TODO Complete the code with the corresponding service call
	List<EnrollmentBLDto> attendance = null;

	attendance.forEach(att -> Printer.printAttendingMechanic(att));
	*/
    }

}

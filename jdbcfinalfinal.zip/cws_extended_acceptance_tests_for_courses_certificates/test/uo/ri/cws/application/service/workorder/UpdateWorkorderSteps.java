package uo.ri.cws.application.service.workorder;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.BusinessFactory;
import uo.ri.cws.application.business.mechanic.MechanicService.MechanicBLDto;
import uo.ri.cws.application.business.vehicle.VehicleService.VehicleBLDto;
import uo.ri.cws.application.business.workorder.WorkOrderService;
import uo.ri.cws.application.business.workorder.WorkOrderService.WorkOrderBLDto;
import uo.ri.cws.application.service.common.TestContext;
import uo.ri.cws.application.service.common.TestContext.Key;
import uo.ri.cws.application.service.util.WorkOrderUtil;
import uo.ri.cws.application.service.util.sql.FindWorkOrderSqlUnitOfWork;

public class UpdateWorkorderSteps {

    private TestContext ctx;

    private WorkOrderService service = BusinessFactory.forWorkOrderService();
    private WorkOrderBLDto dto = new WorkOrderUtil().get();

    public UpdateWorkorderSteps(TestContext ctx) {
	this.ctx = ctx;
    }

    @When("I try to update a workorder with null argument")
    public void iTryToUpdateAWorkorderWithNullArgument() {
	dto = null;
	this.tryUpdateAndKeepException(dto);
    }

    @When("I try to update a workorder with null vehicle id")
    public void iTryToUpdateAWorkorderWithNullVehicleId() {
	dto.vehicleId = null;
	this.tryUpdateAndKeepException(dto);
    }

    @When("I try to update a workorder with null description")
    public void iTryToUpdateAWorkorderWithNullDescription() {
	dto.description = null;
	this.tryUpdateAndKeepException(dto);
    }

    @When("I try to update a workorder with vehicle {string}")
    public void iTryToUpdateAWorkorderWithVehicle(String arg) {
	dto.vehicleId = arg;
	this.tryUpdateAndKeepException(dto);
    }

    @When("I try to update a workorder with description {string}")
    public void iTryToUpdateAWorkorderWithDescription(String arg) {
	dto.description = arg;
	this.tryUpdateAndKeepException(dto);
    }

    @When("I try to update the workorder")
    public void iTryToUpdateTheWorkorder() {
	tryUpdateAndKeepException(dto);
    }

    @Given("an OPEN workorder registered for the vehicle")
    public void anOPENWorkorderRegisteredForTheVehicle() {
	VehicleBLDto v = (VehicleBLDto) ctx.get(Key.VEHICLE);
	dto = new WorkOrderUtil().forVehicle(v.id)
				 .withState("OPEN")
				 .register()
				 .get();
	ctx.put(Key.WORKORDER, dto);
    }

    @Given("a FINISHED workorder registered for the vehicle")
    public void aFINISHEDWorkorderRegisteredForTheVehicle() {
	VehicleBLDto v = (VehicleBLDto) ctx.get(Key.VEHICLE);
	dto = new WorkOrderUtil().forVehicle(v.id)
				 .withState("FINISHED")
				 .register()
				 .get();
	ctx.put(Key.WORKORDER, dto);

    }

    @Given("a INVOICED workorder registered for the vehicle")
    public void aINVOICEDWorkorderRegisteredForTheVehicle() {
	VehicleBLDto v = (VehicleBLDto) ctx.get(Key.VEHICLE);
	dto = new WorkOrderUtil().forVehicle(v.id)
				 .withState("INVOICED")
				 .register()
				 .get();
	ctx.put(Key.WORKORDER, dto);

    }

    @Given("a not registered workorder for the vehicle")
    public void aNotRegisteredWorkorderForTheVehicle() {
	VehicleBLDto v = (VehicleBLDto) ctx.get(Key.VEHICLE);
	dto = new WorkOrderUtil().forVehicle(v.id).withState("OPEN").get();
    }

    @When("I update the workorder")
    public void iUpdateTheWorkorder() throws BusinessException {
	dto.description = "description-updated";
	service.updateWorkOrder(dto);
    }

    @Then("The workorder is updated")
    public void theWorkorderIsUpdated() {
	FindWorkOrderSqlUnitOfWork unit = new FindWorkOrderSqlUnitOfWork(
		dto.id);
	unit.execute();
	WorkOrderBLDto found = unit.get();
	assertTrue(WorkOrderUtil.match(dto, found));
    }

    @Given("a workorder registered for the vehicle and the mechanic")
    public void aWorkorderRegisteredForTheVehicleAndTheMechanic() {
	VehicleBLDto v = (VehicleBLDto) ctx.get(Key.VEHICLE);
	MechanicBLDto m = (MechanicBLDto) ctx.get(Key.REGISTEREDMECHANIC);
	dto = new WorkOrderUtil().forVehicle(v.id)
				 .forMechanic(m.id)
				 .withState("ASSIGNED")
				 .register()
				 .get();
	ctx.put(Key.WORKORDER, dto);
    }

    private void tryUpdateAndKeepException(WorkOrderBLDto dto) {
	try {
	    service.updateWorkOrder(dto);
	    fail();
	} catch (BusinessException ex) {
	    ctx.setException(ex);
	} catch (IllegalArgumentException ex) {
	    ctx.setException(ex);
	}

    }

}

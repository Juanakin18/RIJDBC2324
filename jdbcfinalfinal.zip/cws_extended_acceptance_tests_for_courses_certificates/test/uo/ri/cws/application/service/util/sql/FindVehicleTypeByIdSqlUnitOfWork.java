package uo.ri.cws.application.service.util.sql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import uo.ri.cws.application.business.vehicletype.VehicleTypeService.VehicleTypeBLDto;

public class FindVehicleTypeByIdSqlUnitOfWork {

    private String id;
    private VehicleTypeBLDto result = new VehicleTypeBLDto();

    private ConnectionData connectionData;
    private PreparedStatement findVehicleType;

    public FindVehicleTypeByIdSqlUnitOfWork(String arg) {
	this.connectionData = PersistenceXmlScanner.scan();
	this.id = arg;
    }

    public void execute() {
	JdbcTransaction trx = new JdbcTransaction(connectionData);
	trx.execute((con) -> {
	    prepareStatements(con);
	    findVehicleType();
	});
    }

    public VehicleTypeBLDto get() {
	return result;
    }

    private static final String FIND_BY_ID = "SELECT * FROM TVEHICLETYPES "
	    + " WHERE id = ?";

    private void findVehicleType() throws SQLException {
	PreparedStatement st = findVehicleType;

	int i = 1;
	st.setString(i++, id);

	ResultSet rs = st.executeQuery();

	if (rs.next()) {
	    result.id = rs.getString("id");
	    result.version = rs.getLong("version");
	    result.name = rs.getString("name");
	    result.minTrainigHours = rs.getInt("MINTRAININGHOURS");
	    result.pricePerHour = Double.parseDouble(
		    rs.getString("pricePerHour"));
	}
    }

    private void prepareStatements(Connection con) throws SQLException {
	findVehicleType = con.prepareStatement(FIND_BY_ID);
    }

}

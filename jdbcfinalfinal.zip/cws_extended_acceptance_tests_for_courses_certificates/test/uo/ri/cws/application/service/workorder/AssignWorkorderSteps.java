package uo.ri.cws.application.service.workorder;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.time.LocalDate;
import java.util.UUID;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.BusinessFactory;
import uo.ri.cws.application.business.certificate.CertificateService.CertificateBLDto;
import uo.ri.cws.application.business.mechanic.MechanicService.MechanicBLDto;
import uo.ri.cws.application.business.vehicle.VehicleService.VehicleBLDto;
import uo.ri.cws.application.business.vehicletype.VehicleTypeService.VehicleTypeBLDto;
import uo.ri.cws.application.business.workorder.WorkOrderService;
import uo.ri.cws.application.business.workorder.WorkOrderService.WorkOrderBLDto;
import uo.ri.cws.application.persistence.certificate.CertificateGateway.CertificateDALDto;
import uo.ri.cws.application.persistence.vehicleType.VehicleTypeGateway.VehicleTypeDALDto;
import uo.ri.cws.application.service.common.TestContext;
import uo.ri.cws.application.service.common.TestContext.Key;
import uo.ri.cws.application.service.util.CertificateUtil;
import uo.ri.cws.application.service.util.WorkOrderUtil;
import uo.ri.cws.application.service.util.sql.FindWorkOrderSqlUnitOfWork;

public class AssignWorkorderSteps {

    private TestContext ctx;

    private WorkOrderService service = BusinessFactory.forWorkOrderService();

    public AssignWorkorderSteps(TestContext ctx) {
	this.ctx = ctx;
    }

    @When("I try to assign a workorder with null id")
    public void iTryToAssignAWorkorderWithNullId() throws BusinessException {
	tryAssignAndKeepException(null, "no null");

    }

    @When("I try to assign a workorder with null mechanic dni")
    public void iTryToAssignAWorkorderWithNullMechanicDni() {
	tryAssignAndKeepException("no null", null);

    }

    @When("I try to assign a workorder with id {string}")
    public void iTryToAssignAWorkorderWithId(String arg) {
	tryAssignAndKeepException(arg, "mechanic-id");
    }

    @When("I try to assign a workorder with dni {string}")
    public void iTryToAssignAWorkorderWithDni(String arg) {
	tryAssignAndKeepException("workorder id", arg);
    }

    @When("I try to assign a workorder to a non existent mechanic")
    public void iTryToAssignAWorkorderToANonExistentMechanic() {
	WorkOrderBLDto wo = (WorkOrderBLDto) ctx.get(Key.WORKORDER);
	tryAssignAndKeepException(wo.id, "non existent mechanic dni");
    }

    @Given("a workorder {string} registered for the vehicle")
    public void aWorkorderRegisteredForTheVehicle(String status) {
	VehicleBLDto v = (VehicleBLDto) ctx.get(Key.VEHICLE);
	WorkOrderBLDto wo = new WorkOrderUtil().forVehicle(v.id)
					       .withState("STATUS")
					       .register()
					       .get();
	ctx.put(Key.WORKORDER, wo);
	MechanicBLDto m = (MechanicBLDto) ctx.get(Key.REGISTEREDMECHANIC);

	tryAssignAndKeepException(wo.id, m.dni);
    }

    @When("I try to assign a workorder to the mechanic")
    public void iTryToAssignAWorkorderToTheMechanic() {
	WorkOrderBLDto wo = (WorkOrderBLDto) ctx.get(Key.WORKORDER);
	MechanicBLDto m = (MechanicBLDto) ctx.get(Key.REGISTEREDMECHANIC);
	tryAssignAndKeepException(wo.id, m.dni);

    }

    @When("I try to assign a workorder to a mechanic no certified")
    public void iTryToAssignAWorkorderToAMechanicNoCertified() {
	WorkOrderBLDto wo = (WorkOrderBLDto) ctx.get(Key.WORKORDER);
	MechanicBLDto m = (MechanicBLDto) ctx.get(Key.REGISTEREDMECHANIC);
	tryAssignAndKeepException(wo.id, m.dni);

    }

    @Given("a certificate for the mechanic {string} and the vehicle type {string}")
    public void aCertificationForTheMechanicAndTheVehicleType(String dni,
	    String vtId) throws BusinessException {
	String id = BusinessFactory.forMechanicService()
				   .findMechanicByDni(dni)
				   .get().id;
	CertificateUtil util = new CertificateUtil().withId(
		UUID.randomUUID().toString())
						    .withDate(LocalDate.now())
						    .withMechanicId(id)
						    .withvehicletype(vtId)
						    .register();
	CertificateDALDto certificate = util.get();
	CertificateBLDto c = new CertificateBLDto();
	c.id = certificate.id;
	c.obtainedAt = certificate.date;
	c.mechanic = (MechanicBLDto) ctx.get(Key.REGISTEREDMECHANIC);
	VehicleTypeDALDto vtype = (VehicleTypeDALDto) ctx.get(Key.VEHICLETYPE);

	c.vehicleType = new VehicleTypeBLDto();
	c.vehicleType.id = vtype.id;
	c.vehicleType.name = vtype.name;
	c.vehicleType.minTrainigHours = vtype.minTrainigHours;
    }

    @When("I assign the workorder to the mechanic")
    public void iAssignTheWorkorderToTheMechanic() throws BusinessException {
	WorkOrderBLDto wodto = (WorkOrderBLDto) ctx.get(Key.WORKORDER);
	MechanicBLDto mdto = (MechanicBLDto) ctx.get(Key.REGISTEREDMECHANIC);
	service.assignWorkOrderToMechanic(wodto.id, mdto.dni);
    }

    @Then("workorder becomes assigned")
    public void workorderBecomesAssigned() {
	String mechId = ((MechanicBLDto) ctx.get(Key.REGISTEREDMECHANIC)).id;
	String woId = (String) ((WorkOrderBLDto) ctx.get(Key.WORKORDER)).id;
	String vehId = ((VehicleBLDto) ctx.get(Key.VEHICLE)).id;
	FindWorkOrderSqlUnitOfWork unit = new FindWorkOrderSqlUnitOfWork(woId);
	unit.execute();
	WorkOrderBLDto wo = unit.get();
	assertTrue(wo.status.equals("ASSIGNED"));
	assertTrue(wo.mechanicId.equals(mechId));
	assertTrue(wo.vehicleId.equals(vehId));
    }

    private void tryAssignAndKeepException(String wo, String mech) {
	try {
	    service.assignWorkOrderToMechanic(wo, mech);
	    fail();
	} catch (BusinessException ex) {
	    ctx.setException(ex);
	} catch (IllegalArgumentException ex) {
	    ctx.setException(ex);
	}

    }

}

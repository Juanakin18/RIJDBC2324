package uo.ri.cws.application.service;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.junit.CucumberOptions.SnippetType;
import uo.ri.conf.BusinessFactoryAdapter;
import uo.ri.conf.Factory;

@RunWith(Cucumber.class)
@CucumberOptions(features = {

	"test/uo/ri/cws/application/service/mechanic",
	"test/uo/ri/cws/application/service/invoice",
	"test/uo/ri/cws/application/service/enrollment",
	"test/uo/ri/cws/application/service/certificate/GenerateSteps.java",
	"test/uo/ri/cws/application/service/reports/AllTrainingHoursSteps.java",
	"test/uo/ri/cws/application/service/workorder/RegisterNewWorkorderSteps.java",
	"test/uo/ri/cws/application/service/workorder/UpdateWorkorderSteps.java",
	"test/uo/ri/cws/application/service/workorder/DeleteWorkorderSteps.java", }, plugin = {
		"pretty",
		"html:target/cucumber-results.html" }, snippets = SnippetType.CAMELCASE)
public class RunCucumberTests_1 {

    static {
	Factory.service = new BusinessFactoryAdapter();
    }

}

package uo.ri.cws.application.service.util.sql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import uo.ri.cws.application.persistence.vehicleType.VehicleTypeGateway.VehicleTypeDALDto;

public class AddVehicleTypesSqlUnitOfWork {

    private List<VehicleTypeDALDto> dtos;
    private ConnectionData connectionData;
    private PreparedStatement insertIntoVehicleType;

    public AddVehicleTypesSqlUnitOfWork(List<VehicleTypeDALDto> dtos) {
	this.connectionData = PersistenceXmlScanner.scan();
	this.dtos = dtos;
    }

    public void execute() {
	JdbcTransaction trx = new JdbcTransaction(connectionData);
	trx.execute((con) -> {
	    prepareStatements(con);
	    insertVehicleTypes();
	});
    }

    private static final String INSERT_INTO_TVEHICLETYPES = "INSERT INTO TVEHICLETYPES"
	    + " ( ID, MINTRAININGHOURS, NAME, PRICEPERHOUR, VERSION )"
	    + " VALUES ( ?, ?, ?, ?, ?)";

    private void insertVehicleTypes() throws SQLException {
	PreparedStatement st = insertIntoVehicleType;
	for (VehicleTypeDALDto dto : dtos) {
	    int i = 1;
	    st.setString(i++, dto.id);
	    st.setInt(i++, dto.minTrainigHours);
	    st.setString(i++, dto.name);
	    st.setDouble(i++, dto.pricePerHour);
	    st.setLong(i++, dto.version);
	    st.executeUpdate();
	}

    }

    private void prepareStatements(Connection con) throws SQLException {
	insertIntoVehicleType = con.prepareStatement(INSERT_INTO_TVEHICLETYPES);
    }

}

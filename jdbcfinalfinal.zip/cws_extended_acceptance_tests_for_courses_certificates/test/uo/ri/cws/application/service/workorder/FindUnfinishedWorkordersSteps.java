package uo.ri.cws.application.service.workorder;

import static org.junit.Assert.assertTrue;

import java.util.List;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.BusinessFactory;
import uo.ri.cws.application.business.vehicle.VehicleService.VehicleBLDto;
import uo.ri.cws.application.business.workorder.WorkOrderService;
import uo.ri.cws.application.business.workorder.WorkOrderService.WorkOrderBLDto;
import uo.ri.cws.application.service.common.TestContext;
import uo.ri.cws.application.service.common.TestContext.Key;
import uo.ri.cws.application.service.util.WorkOrderUtil;

public class FindUnfinishedWorkordersSteps {

    private TestContext ctx;
    private List<WorkOrderBLDto> saved = null;
    private List<WorkOrderBLDto> found = null;

    private WorkOrderService service = BusinessFactory.forWorkOrderService();

    public FindUnfinishedWorkordersSteps(TestContext ctx) {
	this.ctx = ctx;
    }

    @Given("some UNFINISHED workorders registered for the vehicle")
    public void someUNFINISHEDWorkordersRegisteredForTheVehicle() {
	VehicleBLDto vehicle = (VehicleBLDto) ctx.get(Key.VEHICLE);
	WorkOrderUtil util = new WorkOrderUtil();
	util.createUnfinishedWorkOrdersForVehicle(vehicle.id);
	saved = util.getUnfinished();
    }

    @Given("some FINISHED workorders registered for the vehicle")
    public void someFINISHEDWorkordersRegisteredForTheVehicle() {
	VehicleBLDto vehicle = (VehicleBLDto) ctx.get(Key.VEHICLE);
	WorkOrderUtil util = new WorkOrderUtil();
	util.createFinishedWorkOrderForVehicle(vehicle.id);
    }

    @When("I find unfinished workorders")
    public void iFindUnfinishedWorkorders() throws BusinessException {
	found = service.findUnfinishedWorkOrders();
    }

    @Then("Unfinished workorders are returned")
    public void unfinishedWorkordersAreReturned() {
	assertTrue(found.size() == saved.size());
	assertTrue(WorkOrderUtil.match(found, saved));
    }

}

package uo.ri.cws.application.service.util.sql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import uo.ri.cws.application.persistence.enrollment.EnrollmentGateway.EnrollmentDALDto;

public class FindEnrollmentSqlUnitOfWork {

    private String id;
    private EnrollmentDALDto result = null;

    private ConnectionData connectionData;
    private PreparedStatement find;

    public FindEnrollmentSqlUnitOfWork(String id) {
	this.connectionData = PersistenceXmlScanner.scan();
	this.id = id;
    }

    public void execute() {
	JdbcTransaction trx = new JdbcTransaction(connectionData);
	trx.execute((con) -> {
	    prepareStatements(con);
	    findEnrollment();
	});
    }

    public EnrollmentDALDto get() {
	return result;
    }

    private static final String FIND_BY_ID = "SELECT * FROM TENROLLMENTS "
	    + " WHERE iD = ?";

    private void findEnrollment() throws SQLException {
	PreparedStatement st = find;

	int i = 1;
	st.setString(i++, id);

	ResultSet rs = st.executeQuery();

	if (rs.next()) {
	    result = new EnrollmentDALDto();
	    result.id = rs.getString("id");
	    result.attendance = rs.getInt("attendance");
	    result.passed = rs.getBoolean("passed");
	    result.mechanicId = rs.getString("mechanic_id");
	    result.courseId = rs.getString("course_id");
	}
    }

    private void prepareStatements(Connection con) throws SQLException {
	find = con.prepareStatement(FIND_BY_ID);
    }

}

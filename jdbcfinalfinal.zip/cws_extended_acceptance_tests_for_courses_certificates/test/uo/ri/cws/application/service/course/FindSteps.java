package uo.ri.cws.application.service.course;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.BusinessFactory;
import uo.ri.cws.application.business.course.CourseService;
import uo.ri.cws.application.business.course.CourseService.CourseBLDto;
import uo.ri.cws.application.service.common.TestContext;
import uo.ri.cws.application.service.common.TestContext.Key;
import uo.ri.cws.application.service.util.CourseUtil;

public class FindSteps {

    private CourseService service = BusinessFactory.forCourseService();
    private List<CourseBLDto> coursesFound = null;
    private TestContext ctx;
    private String courseId;
    private Optional<CourseBLDto> courseFound;

    public FindSteps(TestContext ctx) {
	this.ctx = ctx;
    }

    @When("I find all courses")
    public void iFindAllCourses() throws BusinessException {
	coursesFound = service.findAllCourses();
    }

    @Then("the following courses are returned")
    public void theFollowingCoursesAreReturned(DataTable dataTable) {
	List<CourseBLDto> courses = new ArrayList<>();

	List<Map<String, String>> table = dataTable.asMaps();
	for (Map<String, String> row : table) {
	    courses.add(processRow(row));
	}
	CourseUtil.matchCourses(courses, coursesFound);

    }

    @Then("the following course is returned")
    public void theFollowingCourseIsReturned(DataTable dataTable) {
	List<CourseBLDto> courses = new ArrayList<>();

	List<Map<String, String>> table = dataTable.asMaps();
	for (Map<String, String> row : table) {
	    courses.add(processRow(row));
	}
	assertTrue(courseFound.isPresent());
	CourseBLDto expected = courses.get(0);
	CourseUtil.matchCourse(courseFound.get(), expected);

    }

    private CourseBLDto processRow(Map<String, String> row) {
	LocalDate sd = null, ed = null;
	String state = row.get("state");

	switch (state) {
	case "future":
	    sd = LocalDate.now().plusMonths(1);
	    ed = sd.plusMonths(3);
	    break;
	case "finished":
	    sd = LocalDate.now().minusMonths(10);
	    ed = sd.plusMonths(3);
	    break;
	case "active":
	    sd = LocalDate.now().minusMonths(1);
	    ed = sd.plusMonths(3);
	}
	CourseBLDto m = new CourseUtil().withId(row.get("id"))
					.withCode(row.get("code"))
					.withName(row.get("name"))
					.withDescription(row.get("description"))
					.withHours(Integer.parseInt(
						row.get("hours")))
					.withStartDate(sd)
					.withEndDate(ed)
					.get();
	return m;
    }

    @Then("the registered course is returned")
    public void theRegisteredCourseIsReturned() {
	assertTrue(coursesFound.size() == 1);
	CourseBLDto expected = (CourseBLDto) ctx.get(Key.REGISTEREDCOURSE);
	CourseUtil.matchCourse(expected, coursesFound.get(0));
	CourseUtil.matchDedications(expected.percentages,
		coursesFound.get(0).percentages);

    }

    @When("I find the course by id")
    public void iFindTheCourseById() throws BusinessException {
	List<CourseBLDto> courses = (List<CourseBLDto>) ctx.get(
		Key.REGISTEREDCOURSES);
	courseFound = service.findCourseById(courses.get(0).id);
    }

    @Then("the registered courses are returned")
    public void theRegisteredCoursesAreReturned() {
	List<CourseBLDto> expected = (List<CourseBLDto>) ctx.get(
		Key.REGISTEREDCOURSES);
	assertTrue(coursesFound.size() == expected.size());
	CourseUtil.matchCourses(expected, coursesFound);

    }

    @When("I try to find a course with null argument")
    public void iTryToFindACourseWithNullArgument() {
	this.courseId = null;
	tryFindAndKeepException();
    }

    @When("I try to find a course with {string}")
    public void iTryToFindACourseWith(String arg) {
	this.courseId = arg;
	tryFindAndKeepException();
    }

    @When("I find course with one of the registered id")
    public void iFindCourseWithIdId(DataTable dataTable) {

    }

    @When("I find active courses")
    public void iFindActiveCourses() throws BusinessException {
	this.coursesFound = service.findAllActiveCourses();
    }

    private void tryFindAndKeepException() {
	try {
	    service.deleteCourse(courseId);
	    fail();
	} catch (BusinessException ex) {
	    ctx.setException(ex);
	} catch (IllegalArgumentException ex) {
	    ctx.setException(ex);
	}

    }
}

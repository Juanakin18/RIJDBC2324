package uo.ri.cws.application.service.workorder;

import static org.junit.Assert.fail;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.BusinessFactory;
import uo.ri.cws.application.business.workorder.WorkOrderService;
import uo.ri.cws.application.service.common.TestContext;

public class FindWorkordersSteps {

    private TestContext ctx;

    private WorkOrderService service = BusinessFactory.forWorkOrderService();

    public FindWorkordersSteps(TestContext ctx) {
	this.ctx = ctx;
    }

    private void tryFindUnfinishedAndKeepException() {
	try {
	    service.findUnfinishedWorkOrders();
	    fail();
	} catch (BusinessException ex) {
	    ctx.setException(ex);
	} catch (IllegalArgumentException ex) {
	    ctx.setException(ex);
	}

    }

    private void tryFindByPlateAndKeepException(String plate) {
	try {
	    service.findWorkOrdersByPlateNumber(plate);
	    fail();
	} catch (BusinessException ex) {
	    ctx.setException(ex);
	} catch (IllegalArgumentException ex) {
	    ctx.setException(ex);
	}

    }

    private void tryFindByIdAndKeepException(String id) {
	try {
	    service.findWorkOrderById(id);
	    fail();
	} catch (BusinessException ex) {
	    ctx.setException(ex);
	} catch (IllegalArgumentException ex) {
	    ctx.setException(ex);
	}

    }

}

package uo.ri.cws.application.service.workorder;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.List;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.BusinessFactory;
import uo.ri.cws.application.business.vehicle.VehicleService.VehicleBLDto;
import uo.ri.cws.application.business.workorder.WorkOrderService;
import uo.ri.cws.application.business.workorder.WorkOrderService.WorkOrderBLDto;
import uo.ri.cws.application.service.common.TestContext;
import uo.ri.cws.application.service.common.TestContext.Key;
import uo.ri.cws.application.service.util.WorkOrderUtil;

public class FindWorkorderByPlateSteps {

    private TestContext ctx;
    private List<WorkOrderBLDto> workorders = null;
    private List<WorkOrderBLDto> saved = null;
    private WorkOrderService service = BusinessFactory.forWorkOrderService();

    public FindWorkorderByPlateSteps(TestContext ctx) {
	this.ctx = ctx;
    }

    @When("I try to find workorder by plate with null argument")
    public void iTryToFindWorkorderByPlateWithNullArgument() {
	tryFindByPlateAndKeepException(null);
    }

    @When("I find workorders for a non existent plate")
    public void iFindWorkordersForANonExistentPlate() throws BusinessException {
	workorders = service.findWorkOrdersByPlateNumber("non existent");

    }

    @When("I find workorders by plate for the vehicle")
    public void iFindWorkordersByPlateForTheVehicle() throws BusinessException {
	VehicleBLDto v = (VehicleBLDto) ctx.get(Key.VEHICLE);
	workorders = service.findWorkOrdersByPlateNumber(v.plateNumber);

    }

    @Given("some workorders registered for the vehicle")
    public void someWorkordersRegisteredForTheVehicle() {
	VehicleBLDto v = (VehicleBLDto) ctx.get(Key.VEHICLE);
	WorkOrderUtil util = new WorkOrderUtil();
	util.createUnfinishedWorkOrdersForVehicle(v.id);
	saved = util.gets();
    }

    @Then("workorders are found")
    public void workordersAreFound() {
	assertTrue(workorders.size() == saved.size());
	assertTrue(WorkOrderUtil.match(workorders, saved));

    }

    private void tryFindByPlateAndKeepException(String plate) {
	try {
	    service.findWorkOrdersByPlateNumber(plate);
	    fail();
	} catch (BusinessException ex) {
	    ctx.setException(ex);
	} catch (IllegalArgumentException ex) {
	    ctx.setException(ex);
	}

    }

}

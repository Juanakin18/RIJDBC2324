package uo.ri.cws.application.service.vehicleType;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.persistence.vehicleType.VehicleTypeGateway.VehicleTypeDALDto;
import uo.ri.cws.application.service.common.TestContext;
import uo.ri.cws.application.service.common.TestContext.Key;
import uo.ri.cws.application.service.util.VehicleTypeUtil;

public class VehicleTypeSteps {

    private TestContext ctx;

    public VehicleTypeSteps(TestContext ctx) {
	this.ctx = ctx;
    }

    @Given("the following vehicle types")
    public void theFollowingVehicleTypes(DataTable dataTable)
	    throws BusinessException {
	List<Map<String, String>> table = dataTable.asMaps();
	for (Map<String, String> row : table) {
	    processRow(row);
	}
    }

    @Given("a vehicle type {string} {string} {int}")
    public void aVehicleType(String id, String name, Integer trainHours) {
	VehicleTypeDALDto vt = new VehicleTypeUtil().withId(id)
						    .withName(name)
						    .withMinTrainingHours(
							    trainHours)
						    .register()
						    .get();

	ctx.put(Key.VEHICLETYPE, vt);

    }

    private void processRow(Map<String, String> row) throws BusinessException {
	VehicleTypeDALDto m = new VehicleTypeUtil().withId(row.get("id"))
						   .withName(row.get("name"))
						   .withMinTrainingHours(
							   row.get("minTrainingHours"))
						   .register()
						   .get();
	List<VehicleTypeDALDto> vehicleTypes = (List<VehicleTypeDALDto>) ctx.get(
		Key.VEHICLETYPES);
	if (vehicleTypes == null)
	    vehicleTypes = new ArrayList<>();
	vehicleTypes.add(m);
	ctx.put(Key.VEHICLETYPES, vehicleTypes);

    }

}

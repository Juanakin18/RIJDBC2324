package uo.ri.cws.application.persistence.course.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import jdbc.Jdbc;
import uo.ri.cws.application.persistence.PersistenceException;
import uo.ri.cws.application.persistence.course.CourseGateway;
import uo.ri.cws.application.persistence.course.assembler.CourseAssembler;
import uo.ri.cws.application.persistence.util.Conf;

public class CourseGatewayImpl implements CourseGateway {

	@Override
	public void add(CourseDALDto t) {
		Connection c = null;
		PreparedStatement pst = null;

		try {
			c = Jdbc.createThreadConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TCOURSES_ADD"));
			pst.setString(1, t.id);
			pst.setString(2, t.code);
			pst.setDate(4, java.sql.Date.valueOf(t.endDate));
			pst.setInt(5, t.hours);
			pst.setString(3, t.description);
			pst.setString(6, t.name);
			pst.setDate(7, java.sql.Date.valueOf(t.startDate));
			pst.setLong(8, 1l);
			pst.executeUpdate();

		} catch (SQLException e) {
			throw new PersistenceException(e);
		} finally {
			if (pst != null) try { pst.close(); } catch(SQLException e) { /* ignore */ }
		}

	}

	@Override
	public void remove(String id) {
		PreparedStatement pst = null;
		Connection c = Jdbc.getCurrentConnection();
		try {
			pst = c.prepareStatement(Conf.getInstance().getProperty("TCOURSES_REMOVE"));
			pst.setString(1, id);
			pst.executeUpdate();
		}catch(SQLException e) {
			throw new PersistenceException();
		}

	}

	@Override
	public void update(CourseDALDto t) {
		Connection c = null;
		PreparedStatement pst = null;

		try {
			c = Jdbc.createThreadConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TCOURSES_UPDATE"));
			pst.setString(1, t.id);
			pst.setString(2, t.code);
			pst.setDate(4, java.sql.Date.valueOf(t.endDate));
			pst.setInt(5, t.hours);
			pst.setString(3, t.description);
			pst.setString(6, t.name);
			pst.setDate(7, java.sql.Date.valueOf(t.startDate));
			pst.setLong(8, 1l);
			pst.executeUpdate();

		} catch (SQLException e) {
			throw new PersistenceException(e);
		} finally {
			if (pst != null) try { pst.close(); } catch(SQLException e) { /* ignore */ }
		}
	}

	@Override
	public Optional<CourseDALDto> findById(String id) {
		PreparedStatement pst = null;
		Connection c = null;
		ResultSet rs = null;
		try {
			c=Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TCOURSES_FINDBYID"));
			pst.setString(1, id);
			rs = pst.executeQuery();
			
			return CourseAssembler.toDALDto(rs);
		}catch(SQLException e) {
			throw new PersistenceException(e);
		}finally {
			Jdbc.close(rs,pst);
		}
	}

	@Override
	public List<CourseDALDto> findAll() {
		PreparedStatement pst = null;
		Connection c = null;
		ResultSet rs = null;
		try {
			c=Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TCOURSES_FINDALL"));
			rs = pst.executeQuery();
			
			return CourseAssembler.toDALDtoList(rs);
		}catch(SQLException e) {
			throw new PersistenceException(e);
		}finally {
			Jdbc.close(rs,pst);
		}
	}

	@Override
	public Optional<CourseDALDto> findByCode(String code) {
		PreparedStatement pst = null;
		Connection c = null;
		ResultSet rs = null;
		try {
			c=Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TCOURSES_FINDBYCODE"));
			pst.setString(1, code);
			rs = pst.executeQuery();
			
			return CourseAssembler.toDALDto(rs);
		}catch(SQLException e) {
			throw new PersistenceException(e);
		}finally {
			Jdbc.close(rs,pst);
		}
	}

	@Override
	public Optional<CourseDALDto> findByName(String name) {
		PreparedStatement pst = null;
		Connection c = null;
		ResultSet rs = null;
		try {
			c=Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TCOURSES_FINDBYNAME"));
			pst.setString(1, name);
			rs = pst.executeQuery();
			
			return CourseAssembler.toDALDto(rs);
		}catch(SQLException e) {
			throw new PersistenceException(e);
		}finally {
			Jdbc.close(rs,pst);
		}
	}
	
	
	@Override
	public List<CourseDALDto> findBeforeEndDate(LocalDate date) {
		PreparedStatement pst = null;
		Connection c = null;
		ResultSet rs = null;
		try {
			c=Jdbc.getCurrentConnection();
			pst = c.prepareStatement(Conf.getInstance().getProperty("TCOURSES_FINDENDDATEBEFORE"));
			pst.setDate(1, java.sql.Date.valueOf(date));
			rs = pst.executeQuery();
			
			return CourseAssembler.toDALDtoList(rs);
		}catch(SQLException e) {
			throw new PersistenceException(e);
		}finally {
			Jdbc.close(rs,pst);
		}
	}

}

package uo.ri.cws.application.persistence.certificate;

import java.time.LocalDate;
import java.util.List;
import uo.ri.cws.application.persistence.Gateway;

public interface CertificateGateway extends Gateway<uo.ri.cws.application.persistence.certificate.CertificateGateway.CertificateDALDto> {

	public List<CertificateDALDto> findByVehicleType(String vehicleType);
	public List<CertificateDALDto> findByMechanic(String mechanic);
	
	public class CertificateDALDto {

		public String id;
		public Long version;

		public String mechanicId;
		public String vehicleTypeId;
		public LocalDate date;

	  }
}

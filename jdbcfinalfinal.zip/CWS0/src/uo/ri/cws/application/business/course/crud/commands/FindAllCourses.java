package uo.ri.cws.application.business.course.crud.commands;

import java.util.List;

import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.course.CourseService.CourseBLDto;
import uo.ri.cws.application.business.course.assembler.CourseAssembler;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.course.CourseGateway;

public class FindAllCourses implements Command<List<CourseBLDto>> {

	private CourseGateway gtw = PersistenceFactory.forCourse();
	
	@Override
	public List<CourseBLDto> execute() throws BusinessException {
		return CourseAssembler.toBLDtoList(gtw.findAll());
	}

}

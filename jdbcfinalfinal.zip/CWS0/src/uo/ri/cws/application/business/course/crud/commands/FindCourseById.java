package uo.ri.cws.application.business.course.crud.commands;

import java.util.Optional;

import assertion.Argument;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.course.CourseService.CourseBLDto;
import uo.ri.cws.application.business.course.assembler.CourseAssembler;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.course.CourseGateway;

public class FindCourseById implements Command<Optional<CourseBLDto>> {

	private String id;
	private CourseGateway cgtw = PersistenceFactory.forCourse();
	public FindCourseById(String cId) {
		Argument.isNotNull(cId);
		Argument.isNotEmpty(cId);
		this.id = cId;
	}

	@Override
	public Optional<CourseBLDto> execute() throws BusinessException {
		return CourseAssembler.toBLDto(cgtw.findById(id));
	}

}

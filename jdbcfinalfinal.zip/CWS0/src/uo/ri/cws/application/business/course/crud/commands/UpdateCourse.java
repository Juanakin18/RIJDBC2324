package uo.ri.cws.application.business.course.crud.commands;

import java.time.LocalDate;
import java.util.Optional;

import assertion.Argument;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.course.CourseService.CourseBLDto;
import uo.ri.cws.application.business.course.assembler.CourseAssembler;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.course.CourseGateway;
import uo.ri.cws.application.persistence.course.CourseGateway.CourseDALDto;

public class UpdateCourse implements Command<Void> {

	  /**
     * Updates the course specified by the id with the new data. A course an
     * only be modified if it has not yet started. If the start date is wrong
     * then remove the course and start again... The dedications of the course
     * to the vehicle types are not modified by this operation.
     *
     * @param dto. Must specify all the fields. The id and version fields must
     *             match the current state of the course. All the rest of fields
     *             must be filled, even if there is no change in the data. So it
     *             must pass the same validation as for new courses.
     *
     * @throws
     * 		IllegalArgumentException, if 
     * 			- argument is null, or 
     * 			- any field other than id and version is null, or 
     *          - any field type String is empty 
     * 		BusinessException if: 
     * 			- it does not exist the course with the specified id, or 
     * 			- the current version of the course does not match the version of the dto, or 
     * 			- the course has its start date in the past, or 
     * 			- the new data does not pass the validation specified in @see registerNew
     *
     */
	private CourseBLDto dto;
	private CourseGateway gtw = PersistenceFactory.forCourse();
	public UpdateCourse(CourseBLDto dto) {
		Argument.isNotNull(dto);
		Argument.isNotNull(dto.code);
		Argument.isNotEmpty(dto.code);
		Argument.isNotNull(dto.description);
		Argument.isNotEmpty(dto.description);
		Argument.isNotNull(dto.id);
		Argument.isNotEmpty(dto.id);
		Argument.isNotNull(dto.name);
		Argument.isNotEmpty(dto.name);
		Argument.isNotNull(dto.startDate);
		Argument.isNotNull(dto.endDate);
		this.dto = dto;
	}

	@Override
	public Void execute() throws BusinessException {
		checkExists();
		checkDates();
		dto.version++;
		gtw.update(CourseAssembler.toDALDto(dto));
		return null;
	}

	private void checkDates() throws BusinessException {
		if(dto.startDate.isBefore(LocalDate.now()))
			throw new BusinessException("La fecha es anterior a hoy");
		if(dto.endDate.isBefore(LocalDate.now()))
			throw new BusinessException("La fecha es anterior a hoy");
	}

	private void checkExists() throws BusinessException {
		Optional<CourseDALDto> dto1 = gtw.findById(dto.id);
		if(dto1.isEmpty()) {
			throw new BusinessException("No existe");
		}
		if(dto1.get().version!=dto.version)
			throw new BusinessException("La versi�n no coincide");
	}

}

package uo.ri.cws.application.business.course.crud.commands;

import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import assertion.Argument;
import uo.ri.cws.application.business.BusinessException;
import uo.ri.cws.application.business.course.CourseService.CourseBLDto;
import uo.ri.cws.application.business.course.assembler.CourseAssembler;
import uo.ri.cws.application.business.util.command.Command;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.course.CourseGateway;
import uo.ri.cws.application.persistence.course.CourseGateway.CourseDALDto;
import uo.ri.cws.application.persistence.dedication.DedicationGateway;
import uo.ri.cws.application.persistence.dedication.DedicationGateway.DedicationDALDto;
import uo.ri.cws.application.persistence.vehicleType.VehicleTypeGateway;

public class RegisterCourse implements Command<CourseBLDto> {

	/**
     * Registers a new course in the system
     *
     * @param dto, it must specify: name, description, startDate, endDate, hours
     *             and the table of percentages. The id and the version fields
     *             must be null (will be assigned by the system).
     *
     * @return the same Dto with the id field assigned to the created UUID
     *
     * @throws 
     * 		IllegalArgumentException, if 
     * 			- argument is null, or 
     * 			- any field other than id and version is null, or 
     *          - any field type String is empty 
     *          
     * 		BusinessException, if: 
     * 			- there already exists a course with the same name or the same code, or 
     * 			- there is percentage devoted to a non existing vehicle type, or 
     * 			- the initial and final dates are in the past or inverted, or 
     * 			- the number of hours are zero or negative, or 
     * 			- the sum of devoted percentages does not equals 100%, or 
     * 			- the are any dedication with an invalid percentage (empty, zero, negative)
     */
	private CourseBLDto dto;
	private CourseGateway gtw = PersistenceFactory.forCourse();
	private VehicleTypeGateway vtgtw = PersistenceFactory.forVehicleType();
	private DedicationGateway dgtw = PersistenceFactory.forDedication();
	public RegisterCourse(CourseBLDto dto) {
		Argument.isNotNull(dto);
		Argument.isNotNull(dto.code);
		Argument.isNotEmpty(dto.code);
		Argument.isNotNull(dto.description);
		Argument.isNotEmpty(dto.description);
		Argument.isNotNull(dto.name);
		Argument.isNotEmpty(dto.name);
		Argument.isNotNull(dto.startDate);
		Argument.isNotNull(dto.endDate);
		this.dto = dto;
	}

	@Override
	public CourseBLDto execute() throws BusinessException {
		checkDoesNotExist();
		checkDates();
		checkHours();
		checkPercentages();
		checkTotalPercentages();
		addToDatabase();
		return dto;
	}

	
	private void checkTotalPercentages() throws BusinessException {
		Map<String, Integer> percentages = dto.percentages;
		int total =0;
		for(String type : percentages.keySet()) {
			int porcentaje = percentages.get(type);
			if(porcentaje<=0)
				throw new BusinessException("Porcentaje no v�lido");
			total+=porcentaje;
		}
		if(total>100)
			throw new BusinessException("Los porcentajes suman m�s de 100");
	}

	private void checkPercentages() throws BusinessException {
		Map<String, Integer> percentages = dto.percentages;
		if(percentages==null)
			throw new BusinessException();
		for(String type : percentages.keySet()) {
			if(vtgtw.findById(type).isEmpty())
				throw new BusinessException("No existe el tipo: "+type);
		}
	}

	private void checkHours() throws BusinessException {
		if(dto.hours<=0)
			throw new BusinessException("Las horas son negativas");
	}

	private void checkDates() throws BusinessException {
		if(dto.endDate.isBefore(dto.startDate))
			throw new BusinessException("La fecha final es anterior a la inicial");
	}

	

	private void checkDoesNotExist() throws BusinessException {
		Optional<CourseDALDto> daldto = gtw.findByName(dto.name);
		Optional<CourseDALDto> daldto1 = gtw.findByCode(dto.code);
		if(daldto.isPresent())
			throw new BusinessException("Ya existe un curso con ese nombre");
		if(daldto1.isPresent())
			throw new BusinessException("Ya existe un curso con ese c�digo");
	}
	
	private void addToDatabase() {
		dto.id = UUID.randomUUID().toString();
		dto.version = 1l;
		Map<String, Integer> percentages = dto.percentages;
		for(String type : percentages.keySet()) {
			DedicationDALDto ddto = new DedicationDALDto();
			ddto.id = UUID.randomUUID().toString();
			ddto.version = 1l;
			ddto.courseId = dto.id;
			ddto.vehicleTypeId = vtgtw.findById(type).get().id;
			ddto.percentage = percentages.get(type);
			dgtw.add(ddto);
		}
		gtw.add(CourseAssembler.toDALDto(dto));
	}

}

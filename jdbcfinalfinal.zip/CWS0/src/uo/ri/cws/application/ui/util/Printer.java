package uo.ri.cws.application.ui.util;

import java.util.List;

import console.Console;
import uo.ri.cws.application.business.certificate.CertificateService.CertificateBLDto;
import uo.ri.cws.application.business.course.CourseService.CourseBLDto;
import uo.ri.cws.application.business.course.CourseService.TrainingForMechanicRow;
import uo.ri.cws.application.business.course.CourseService.TrainingHoursRow;
import uo.ri.cws.application.business.enrollment.EnrollmentService.EnrollmentBLDto;
//import uo.ri.cws.application.business.client.ClientService.ClientBLDto;
import uo.ri.cws.application.business.invoice.InvoiceService.InvoiceBLDto;
import uo.ri.cws.application.business.invoice.InvoiceService.WorkOrderForInvoicingBLDto;
import uo.ri.cws.application.business.mechanic.MechanicService.MechanicBLDto;
import uo.ri.cws.application.business.paymentmean.PaymentMeanService.PaymentMeanBLDto;
import uo.ri.cws.application.business.vehicle.VehicleService.VehicleBLDto;
import uo.ri.cws.application.business.vehicletype.VehicleTypeService.VehicleTypeBLDto;
import uo.ri.cws.application.business.workorder.WorkOrderService;
import uo.ri.cws.application.business.workorder.WorkOrderService.WorkOrderBLDto;

public class Printer {

	 /*
     * MECHANICS
     */
    public static void printMechanic(MechanicBLDto m) {
	Console.printf("\t%-36.36s %-9s %-10.10s %-25.25s %-10.2s\n", m.id,
		m.dni, m.name, m.surname, m.version);
    }

    public static void printMechanics(List<MechanicBLDto> list) {

	Console.printf("\t%-36s %-9s %-10s %-25s %-10s\n",
		"Mechanic identifier", "DNI", "Name", "Surname", "Version");
	for (MechanicBLDto m : list)
	    printMechanic(m);
    }

    /*
     * INVOICES
     */

    public static void printInvoices(List<InvoiceBLDto> list) {

	for (InvoiceBLDto m : list)
	    printInvoice(m);
    }

    public static void printInvoice(InvoiceBLDto invoice) {

	double importeConIVa = invoice.total;
	double iva = invoice.vat;
	double importeSinIva = importeConIVa / (1 + iva / 100);

	Console.printf("Invoice number: %d%n", invoice.number);
	Console.printf("\tDate: %1$td/%1$tm/%1$tY%n", invoice.date);
	Console.printf("\tAmount: %.2f %n", importeSinIva);
	Console.printf("\tVat: %.1f %% %n", invoice.vat);
	Console.printf("\tTotal (vat included): %.2f %n", invoice.total);
	Console.printf("\tState: %s%n", invoice.status);
    }

    public static void printInvoicingWorkOrder(WorkOrderForInvoicingBLDto arg) {

	Console.printf("\t%s \t%-40.40s \t%s \t%-12.12s \t%.2f\n", arg.id,
		arg.description, arg.date, arg.status, arg.total);
    }

    public static void printInvoicingWorkOrders(
	    List<WorkOrderForInvoicingBLDto> arg) {
	Console.printf("\t%s \t%-40.40s \t%s \t%-12.12s \t%.2f\n", "Identifier",
		"description", "state", "total");
	for (WorkOrderForInvoicingBLDto inv : arg)
	    printInvoicingWorkOrder(inv);
    }

    /*
     * WORKORDERS
     */

    public static void printWorkOrder(WorkOrderService.WorkOrderBLDto arg) {

	Console.printf("\t%s \t%-40.40s \t%s \t%-12.12s \t%.2f\n", arg.id,
		arg.description, arg.date, arg.status, arg.amount);
    }

    public static void printWorkOrders(
	    List<WorkOrderService.WorkOrderBLDto> arg) {
	Console.printf("\t%s \t%-40.40s \t%s \t%-12.12s \t%s\n", "Identifier",
		"description", "date", "state", "total");
	for (WorkOrderService.WorkOrderBLDto inv : arg)
	    printWorkOrder(inv);
    }

    public static void printWorkOrderDetail(WorkOrderBLDto wo) {

	Console.printf("%s for vehicle %s\n\t%-25.25s\n\t%tm/%<td/%<tY\n\t%s\n",
		wo.id, wo.vehicleId, wo.description, wo.date, wo.status);
    }
    /*
     * PAYMENTMEANS
     */

    public static void printPaymentMeans(List<PaymentMeanBLDto> medios) {
	Console.println();
	Console.println("Available payment means");

	Console.printf("\t%s \t%-8.8s \t%s \n", "Id", "Type", "Acummulated");
	for (PaymentMeanBLDto medio : medios) {
	    printPaymentMean(medio);
	}
    }

    private static void printPaymentMean(PaymentMeanBLDto medio) {
	Console.printf("\t%d \t%-8.8s \t%s \n", medio.id,
		medio.getClass().getName() // not the best...
		, medio.accumulated);
    }

    /*
     * VEHICLE TYPE
     */

    public static void printVehicleType(VehicleTypeBLDto vt) {

	Console.printf("\t%s %-10.10s %5.2f %d\n", vt.id, vt.name,
		vt.pricePerHour, vt.minTrainigHours);
    }

    public static void printVehicleTypes(List<VehicleTypeBLDto> lvt) {
	for (VehicleTypeBLDto vt : lvt) {
	    printVehicleType(vt);
	}

    }

    /*
     * VEHICLE
     */

    public static void printVehicleDetail(VehicleBLDto v) {

	Console.printf("%s\t%-8.8s\t%s\t%s\n", v.id, v.plateNumber, v.make,
		v.model);
    }

    /*
     * COURSE
     */

    public static void printCourse(CourseBLDto c) {

	Console.printf("%s\t%s %s %-35.35s %td/%<tm/%<tY %td/%<tm/%<tY %d\n",
		c.id, c.code, c.name, c.description, c.startDate, c.endDate,
		c.hours);
	c.percentages.forEach((id,
		percent) -> Console.printf("\t %d %d percent\n", id, percent));
    }

    public static void printAttendingMechanic(EnrollmentBLDto att) {
	Console.printf("%-30.30s\t%d\t%s\n",
		att.mechanic.surname + ", " + att.mechanic.name, att.attendance,
		att.passed ? "passed" : "failed");
    }

    public static void printTrainingForMechanic(TrainingForMechanicRow row) {

	Console.printf("\t%-20.20s\t%d\t%d\n", row.vehicleTypeName,
		row.enrolledHours, row.attendedHours);

    }

    public static void printTrainingHoursRow(TrainingHoursRow r) {

	Console.printf("%-20.20s\t%-30.30s\t%d hours\n", r.vehicleTypeName,
		r.mechanicFullName, r.enrolledHours);
    }

    /*
     * CERTIFICATES
     */

    public static void printCertificateRow(CertificateBLDto r) {

	Console.printf("%-20.20s\t%-30.30s\t from %td/%<tm/%<tY\n",
		r.vehicleType.name, r.mechanic.surname + ", " + r.mechanic.name,
		r.obtainedAt);
    }

    public static void printCertifiedMechanic(CertificateBLDto c) {

	Console.printf("%s\t%-10.10s %-25.25s %-25.25s\n", c.mechanic.id,
		c.mechanic.dni, c.mechanic.name, c.vehicleType.name);
    }
	
	
}
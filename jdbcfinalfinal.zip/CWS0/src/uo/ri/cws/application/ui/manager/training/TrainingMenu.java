package uo.ri.cws.application.ui.manager.training;

import menu.BaseMenu;
import uo.ri.cws.application.ui.manager.training.certificates.GenerateCertificatesAction;
import uo.ri.cws.application.ui.manager.training.course.CourseCrudMenu;
import uo.ri.cws.application.ui.manager.training.enrollment.EnrollmentMenu;
import uo.ri.cws.application.ui.manager.training.reports.ReportsMenu;

public class TrainingMenu extends BaseMenu {

    public TrainingMenu() {
	menuOptions = new Object[][] {
		{ "Manager > Training management", null },

		{ "Course management", CourseCrudMenu.class },
		{ "Attendance registration", EnrollmentMenu.class },
		{ "Reports", ReportsMenu.class }, { "", null },
		{ "Certificate generation", GenerateCertificatesAction.class },

	};
    }

}

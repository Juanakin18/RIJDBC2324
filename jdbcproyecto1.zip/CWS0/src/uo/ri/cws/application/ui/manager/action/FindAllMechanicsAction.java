package uo.ri.cws.application.ui.manager.action;


import console.Console;
import menu.Action;
import uo.ri.cws.application.BusinessException;
import uo.ri.cws.application.business.mechanic.MechanicBLDto;
import uo.ri.cws.application.business.mechanic.crud.FindAllMechanics;

public class FindAllMechanicsAction implements Action {

	@Override
	public void execute() throws BusinessException {

		Console.println("\nList of mechanics \n");  

		FindAllMechanics find = new FindAllMechanics();
		
		for(MechanicBLDto dto : find.execute()) {
			Console.printf("\t%s %s %s %s %d\n",  
					dto.id
					, dto.dni
					,  dto.name
					,  dto.surname
					,  dto.version
				);
		}
		
	}
}

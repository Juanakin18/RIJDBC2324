package uo.ri.cws.application.ui.manager.action;

import console.Console;
import menu.Action;
import uo.ri.cws.application.business.mechanic.MechanicBLDto;
import uo.ri.cws.application.business.mechanic.crud.FindMechanicById;

public class ListMechanicByIDAction implements Action {

	@Override
	public void execute() throws Exception {

		String id = Console.readString("Type mechahic id to update"); 
		
		FindMechanicById find = new FindMechanicById(id);
		
		MechanicBLDto dto = find.execute();
		
			Console.printf("\t%s %s %s %s %d\n",  
					dto.id
					, dto.dni
					,  dto.name
					,  dto.surname
					,  dto.version
				);
		
	}

}

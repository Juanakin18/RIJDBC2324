package uo.ri.cws.application.business.invoice.create.commands;

import java.util.List;

import assertion.Argument;
import uo.ri.cws.application.business.invoice.InvoiceService.InvoiceBLDto;

public class CreateInvoice {

	private List<String> workOrderIds;
	public CreateInvoice(List<String> workOrderIds) {
		Argument.isNotNull(workOrderIds);
		Argument.isTrue(workOrderIds.size()>0);
		this.workOrderIds = workOrderIds;
	}

	public InvoiceBLDto execute() {
		// TODO Auto-generated method stub
		return null;
	}

}

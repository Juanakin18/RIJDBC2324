package uo.ri.cws.application.business.invoice.create.commands;

import java.util.List;

import assertion.Argument;
import uo.ri.cws.application.business.invoice.InvoiceService.WorkOrderForInvoicingBLDto;

public class FindNotInvoicedWorkOrders {

	private String dni;
	public FindNotInvoicedWorkOrders(String dni) {
		Argument.isNotNull(dni);
		Argument.isNotEmpty(dni);
		this.dni = dni;
	}

	public List<WorkOrderForInvoicingBLDto> execute() {
		// TODO Auto-generated method stub
		return null;
	}

}

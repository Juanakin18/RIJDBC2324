package uo.ri.cws.application.business.mechanic;

public class MechanicBLDto {

	public String id;
	public long version;

	public String dni;
	public String name;
	public String surname;

  }

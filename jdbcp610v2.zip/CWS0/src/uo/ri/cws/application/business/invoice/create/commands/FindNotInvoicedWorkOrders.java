package uo.ri.cws.application.business.invoice.create.commands;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import assertion.Argument;
import console.Console;
import uo.ri.cws.application.business.invoice.InvoiceService.WorkOrderForInvoicingBLDto;

public class FindNotInvoicedWorkOrders {

	private static final String URL = "jdbc:hsqldb:hsql://localhost";
	private static final String USER = "sa";
	private static final String PASS = "";
	
	private static final String SQL =
			"select a.id, a.description, a.date, a.status, a.amount " +
			"from TWorkOrders as a, TVehicles as v, TClients as c " +
			"where a.vehicle_id = v.id " +
			"	and v.client_id = c.id " +
			"	and status <> 'INVOICED'" +
			"	and dni like ?";
	private String dni;
	public FindNotInvoicedWorkOrders(String dni) {
		Argument.isNotNull(dni);
		Argument.isNotEmpty(dni);
		this.dni = dni;
	}

	public List<WorkOrderForInvoicingBLDto> execute() {

		List<WorkOrderForInvoicingBLDto> dtos = new ArrayList<>();
		Connection c = null;
		PreparedStatement pst = null;
		ResultSet rs = null;

		try {
			c = DriverManager.getConnection(URL, USER, PASS);
			
			pst = c.prepareStatement(SQL);
			pst.setString(1, dni);
			
			rs = pst.executeQuery();
			while(rs.next()) {
				WorkOrderForInvoicingBLDto dto = new WorkOrderForInvoicingBLDto();
				dto.id = rs.getString(1);
				dto.description =rs.getString(2);
				dto.date = rs.getDate(3).toLocalDate().atStartOfDay();
				dto.status = rs.getString(4);
				dto.total = rs.getDouble(5);
				Console.printf("\t%s \t%-40.40s \t%s \t%-12.12s \t%.2f\n",  
					rs.getString(1)
					, rs.getString(2) 
					, rs.getDate(3)
					, rs.getString(4)
					, rs.getDouble(5)
				);
				dtos.add(dto);
			}
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
		finally {
			if (rs != null) try { rs.close(); } catch(SQLException e) { /* ignore */ }
			if (pst != null) try { pst.close(); } catch(SQLException e) { /* ignore */ }
			if (c != null) try { c.close(); } catch(SQLException e) { /* ignore */ }
		}
		return dtos;
	}

}

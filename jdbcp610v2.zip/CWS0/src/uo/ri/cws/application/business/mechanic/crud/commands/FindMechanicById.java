package uo.ri.cws.application.business.mechanic.crud.commands;

import java.util.Optional;

import assertion.Argument;
import uo.ri.cws.application.business.mechanic.MechanicService.MechanicBLDto;
import uo.ri.cws.application.business.mechanic.assembler.MechanicAssembler;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.mechanic.MechanicGateway;
import uo.ri.cws.application.persistence.mechanic.MechanicGateway.MechanicDALDto;

public class FindMechanicById {
	
	private String idMechanic;
	private MechanicGateway mg = PersistenceFactory.forMechanic();
	
	public FindMechanicById(String idMechanic) {
		Argument.isNotNull(idMechanic);
		Argument.isNotEmpty(idMechanic);
		this.idMechanic = idMechanic;
	}
	public Optional<MechanicBLDto> execute(){
		Optional<MechanicDALDto> dto = mg.findById(idMechanic);
		return (MechanicAssembler.toBLDto(dto));
		
	}

}

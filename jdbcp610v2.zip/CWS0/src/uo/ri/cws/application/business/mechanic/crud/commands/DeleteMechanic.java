package uo.ri.cws.application.business.mechanic.crud.commands;

import assertion.Argument;
import uo.ri.cws.application.BusinessException;
import uo.ri.cws.application.persistence.PersistenceFactory;
import uo.ri.cws.application.persistence.mechanic.MechanicGateway;

public class DeleteMechanic {

	
	private String idMechanic;
	private MechanicGateway mg = PersistenceFactory.forMechanic();
	
	public DeleteMechanic(String idMechanic) {
		Argument.isNotNull(idMechanic);
		Argument.isNotEmpty(idMechanic);
		this.idMechanic = idMechanic;
	}
	
	public void execute() throws BusinessException {
		if(!existMechanic(idMechanic))
			throw new BusinessException("Mechanic doesn't Exist");
		mg.remove(idMechanic);
	}
	
	
	private boolean existMechanic(String dni) {
		
		return mg.findByDni(dni).isPresent();
	}
}

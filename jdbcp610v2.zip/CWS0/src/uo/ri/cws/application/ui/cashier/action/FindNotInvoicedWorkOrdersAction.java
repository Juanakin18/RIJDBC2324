package uo.ri.cws.application.ui.cashier.action;


import console.Console;
import menu.Action;
import uo.ri.cws.application.BusinessException;
import uo.ri.cws.application.business.BusinessFactory;
import uo.ri.cws.application.ui.util.Printer;

public class FindNotInvoicedWorkOrdersAction implements Action {
	


	/**
	 * Process:
	 * 
	 *   - Ask customer dni
	 *    
	 *   - Display all uncharged workorder  
	 *   		(status <> 'INVOICED'). For each workorder, display 
	 *   		id, vehicle id, date, status, amount and description
	 */

	

	@Override
	public void execute() throws BusinessException {
		String dni = Console.readString("Client DNI ");
		
		Console.println("\nClient's not invoiced work orders\n"); 
		Printer.printInvoicingWorkOrders(BusinessFactory.forInvoicingService()
				.findNotInvoicedWorkOrdersByClientDni(dni));
	}

}
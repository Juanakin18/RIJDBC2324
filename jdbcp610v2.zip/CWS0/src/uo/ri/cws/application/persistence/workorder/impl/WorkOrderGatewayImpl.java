package uo.ri.cws.application.persistence.workorder.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import jdbc.Jdbc;
import uo.ri.cws.application.persistence.PersistenceException;
import uo.ri.cws.application.persistence.workorder.WorkOrderGateway;
import uo.ri.cws.application.persistence.workorder.assembler.WorkOrderAssembler;

public class WorkOrderGatewayImpl implements WorkOrderGateway {

	private static final String SQL_CHECK_WORKORDER_STATE = 
			"select status from TWorkOrders where id = ?";
	private static final String SQL_FIND_WORKORDER_AMOUNT = 
			"select amount from TWorkOrders where id = ?";
	private static final String SQL_LINK_WORKORDER_TO_INVOICE = 
			"update TWorkOrders set invoice_id = ? where id = ?";

	private static final String SQL_MARK_WORKORDER_AS_INVOICED = 
			"update TWorkOrders set status = 'INVOICED' where id = ?";

	private static final String SQL_FIND_WORKORDERS = 
			"select * from TWorkOrders where id = ?";
	
	private static final String SQL_UPDATEVERSION_WORKORDERS = 
			"update TWorkOrders set version=version+1 where id = ?";
	@Override
	public void add(WorkOrderDALDto t) {
		// TODO Auto-generated method stub

	}

	@Override
	public void remove(String id) {
		// TODO Auto-generated method stub

	}

	@Override
	public void update(WorkOrderDALDto t) {
		// TODO Auto-generated method stub

	}

	@Override
	public Optional<WorkOrderDALDto> findById(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<WorkOrderDALDto> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<WorkOrderDALDto> findByMechanic(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<WorkOrderDALDto> findNotInvoicedForVehicles(List<String> vehicleIds) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<WorkOrderDALDto> findByVehicleId(String vehicleId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<WorkOrderDALDto> findByIds(List<String> arg) {
		Connection c = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			 c = Jdbc.createThreadConnection();
			 pst = null;
			 rs = null;
			List<WorkOrderDALDto> dtos = new ArrayList<WorkOrderDALDto>();

			pst = c.prepareStatement(SQL_CHECK_WORKORDER_STATE);

			for (String workOrderID : arg) {
				pst.setString(1, workOrderID);

				rs = pst.executeQuery();
				Optional<WorkOrderDALDto> dto = WorkOrderAssembler.toWorkOrderDALDto(rs);
				dtos.add(dto.get());
				rs.next();
				

			}
			return dtos;
		} catch (SQLException e) {
			throw new PersistenceException(e);
		} finally {
			if (rs != null) try { rs.close(); } catch(SQLException e) { /* ignore */ }
			if (pst != null) try { pst.close(); } catch(SQLException e) { /* ignore */ }
		}
	}

	@Override
	public List<WorkOrderDALDto> findByInvoice(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<WorkOrderDALDto> findInvoiced() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<WorkOrderDALDto> findInvoicedByMechanic(String mechanicId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<WorkOrderDALDto> findUnfinished() {
		// TODO Auto-generated method stub
		return null;
	}

}

package uo.ri.cws.application.persistence.vehicle.impl;

import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.persistence.vehicle.VehicleGateway;

public class VehicleGatewayImpl implements VehicleGateway {

	@Override
	public void add(VehicleDALDto t) {
		// TODO Auto-generated method stub

	}

	@Override
	public void remove(String id) {
		// TODO Auto-generated method stub

	}

	@Override
	public void update(VehicleDALDto t) {
		// TODO Auto-generated method stub

	}

	@Override
	public Optional<VehicleDALDto> findById(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<VehicleDALDto> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<VehicleDALDto> findByPlate(String plate) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<VehicleDALDto> findByMake(String make) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<VehicleDALDto> findByClient(String arg) {
		// TODO Auto-generated method stub
		return null;
	}

}
